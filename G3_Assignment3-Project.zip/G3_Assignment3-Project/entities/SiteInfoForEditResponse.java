package entities;

import java.io.Serializable;

public class SiteInfoForEditResponse implements Serializable {
    
    private String name;
    private String location;
    private String type;
    private String disabeled;
    private String description;
    
    public SiteInfoForEditResponse(String name,String location,String type,String description,String disabeled) {
   	 this.name=name;
   	 this.location=location;
   	 this.type=type;
   	 this.disabeled=disabeled;
   	 this.description=description;
    }

    public String getName() {
   	 return name;
    }

    public String getLocation() {
   	 return location;
    }

    public String getType() {
   	 return type;
    }

    public String getDisabeled() {
   	 return disabeled;
    }

    public String getDescription() {
   	 return description;
    }
    
    
}


