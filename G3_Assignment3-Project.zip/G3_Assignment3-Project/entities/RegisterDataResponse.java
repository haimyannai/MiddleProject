package entities;

import java.io.Serializable;

public class RegisterDataResponse implements Serializable {
	private Boolean registerRes ;
	
	public RegisterDataResponse(Boolean registerRes) {
		this.registerRes=registerRes;
	
	}

	public Boolean getRegisterRes() {
		return registerRes;
	}
	
}
