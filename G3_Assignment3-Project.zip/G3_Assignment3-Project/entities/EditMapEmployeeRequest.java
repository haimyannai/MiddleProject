package entities;

import java.io.Serializable;

/** this class responsible to save the updates of the employee request edit */
public class EditMapEmployeeRequest implements Serializable {

	private int id;
	private double locationX;
	private double locationY;
	private String mapname;
	private String sitename;

	public EditMapEmployeeRequest(String mapname, String sitename, double locationX, double locationY, int id) {
		this.mapname = mapname;
		this.sitename = sitename;
		this.locationX = locationX;
		this.locationY = locationY;

		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
		
	}

	public double getLocationX() {
		return locationX;
	}

	public double getLocationY() {
		return locationY;
	}

	public String getMapname() {
		return mapname;
	}

	public String getSitename() {
		return sitename;
	}

	public void setLocationX(double locationX) {
		this.locationX = locationX;
	}

	public void setLocationY(double locationY) {
		this.locationY = locationY;
	}

	public void setMapname(String mapname) {
		this.mapname = mapname;
	}

	public void setSitename(String sitename) {
		this.sitename = sitename;
	}

}


