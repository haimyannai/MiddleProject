package entities;

import java.io.Serializable;

public class EditMapRequest implements Serializable {

	private String mapname,description,version;
	private byte[] img;


	public EditMapRequest(String mapname,String version,String description,byte[] img) {
		this.version = version;
		this.mapname = mapname;
		this.description = description;
		this.img=img;
	}

	public byte[] getImg() {
		return img;
	}

	public String getDescription() {
		return description;
	}

	public String getMapname() {
		return mapname;
	}

	public String getVersion() {
		return version;
	}
	
}
