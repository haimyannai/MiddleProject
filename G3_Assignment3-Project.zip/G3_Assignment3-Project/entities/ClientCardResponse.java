package entities;

import java.io.Serializable;

public class ClientCardResponse implements Serializable{
	
private Boolean clientCardRes ;
private String name;
private String ID;
private String phoneNumber;
private String sex;
private String userName;
private String Email;
	
	public ClientCardResponse(Boolean clientCardRes,String name,String ID,String phoneNumber,String sex,String userName,String Email) {
		this.clientCardRes=clientCardRes;
		this.name=name;
		this.ID=ID;
		this.phoneNumber=phoneNumber;
		this.sex=sex;
		this.userName=userName;
		this.Email=Email;
	}

	public Boolean getClientCardRes() {
		return clientCardRes;
	}

	public String getName() {
		return name;
	}

	public String getID() {
		return ID;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public String getSex() {
		return sex;
	}

	public String getUserName() {
		return userName;
	}

	public String getEmail() {
		return Email;
	}


}



