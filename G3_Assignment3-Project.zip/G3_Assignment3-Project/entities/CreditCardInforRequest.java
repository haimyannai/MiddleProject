package entities;

import java.io.Serializable;

public class CreditCardInforRequest implements Serializable {

    private String CreditCardCompany;
    private int CardNumber;
    private int SecurityCode;
    private String CardExpritionDate;
    private String ClientID;

    public CreditCardInforRequest(String CreditCardCompany, int CardNumber, int SecurityCode, String CardExpritionDate,
    		String ClientID)
    {
   	 this.CreditCardCompany = CreditCardCompany;
   	 this.CardNumber =CardNumber;
   	 this.SecurityCode = SecurityCode;
   	 this.CardExpritionDate = CardExpritionDate;
   	 this.ClientID = ClientID;
    }

    public String getCreditCardCompany() {
   	 return CreditCardCompany;
    }

    public int getCardNumber() {
   	 return CardNumber;
    }

    public int getSecurityCode() {
   	 return SecurityCode;
    }

    public String getCardExpritionDate() {
   	 return CardExpritionDate;
    }

    public String getClientID() {
   	 return ClientID;
    }

}



