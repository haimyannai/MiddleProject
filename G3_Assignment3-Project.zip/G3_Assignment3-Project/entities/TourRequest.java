package entities;

import java.io.Serializable;
import java.util.ArrayList;

public class TourRequest implements Serializable {

    private int tourID;
    private String tourName,tourDescription,tourCity,isRecommended,isAccessible;
    private ArrayList<ArrayList<Object>> sitesInTour = new ArrayList<>();
    
    public int getTourID() {
   	 return tourID;
    }
    public void setTourID(int tourID) {
   	 this.tourID = tourID;
    }
    public String getTourName() {
   	 return tourName;
    }
    public void setTourName(String tourName) {
   	 this.tourName = tourName;
    }
    public String getTourDescription() {
   	 return tourDescription;
    }
    public void setTourDescription(String tourDescription) {
   	 this.tourDescription = tourDescription;
    }
    public String getTourCity() {
   	 return tourCity;
    }
    public void setTourCity(String tourCity) {
   	 this.tourCity = tourCity;
    }
    public String getIsRecommended() {
   	 return isRecommended;
    }
    public void setIsRecommended(String isRecommended) {
   	 this.isRecommended = isRecommended;
    }
    public String getIsAccessible() {
   	 return isAccessible;
    }
    public void setIsAccessible(String isAccessible) {
   	 this.isAccessible = isAccessible;
    }
    public ArrayList<ArrayList<Object>> getSitesInTour() {
   	 return sitesInTour;
    }
    public void setSitesInTour(ArrayList<ArrayList<Object>> sitesInTour) {
   	 this.sitesInTour = sitesInTour;
    }
}


