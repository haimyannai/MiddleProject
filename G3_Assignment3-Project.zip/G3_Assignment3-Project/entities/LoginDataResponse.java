package entities;

import java.io.Serializable;

import entities.DataTypes.UserType;

public class LoginDataResponse implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private String username;
	private String ifconected;
	private Boolean loginRes ;
	private UserType userType;
	private String id;
	
	
	public LoginDataResponse (Boolean loginRes,String ifconected, UserType userType,String username,String id ) {
		this.loginRes = loginRes;
		this.ifconected =ifconected;
		this.userType = userType;
		this.username =username;
		this.id=id;
	}

	public String getId() {
		return id;
	}

	public String getIfconected() {
		return ifconected;
	}

	public Boolean getLoginRes() {
		return loginRes;
	}

	public String getUsername() {
		return username;
	}

	public UserType getUserType() {
		return userType;
	}

}
