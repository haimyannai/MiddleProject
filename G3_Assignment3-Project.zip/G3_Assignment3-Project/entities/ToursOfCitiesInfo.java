package entities;

import java.io.Serializable;

public class ToursOfCitiesInfo implements Serializable{
    
    private int id;
    private String sitename;
    private String cityname;
    private String recommended;
    private String description;
    
    public ToursOfCitiesInfo(int id,String sitename,String cityname,String recommended,String description) {
   	 this.id=id;
   	 this.sitename=sitename;
   	 this.cityname=cityname;
   	 this.recommended=recommended;
   	 this.description=description;
    }
    public String getDescription() {
		return description;
	}
	public ToursOfCitiesInfo() {
    
    }

    public int getId() {
   	 return id;
    }

    public void setId(int id) {
   	 this.id = id;
    }

    public String getSitename() {
   	 return sitename;
    }

    public void setSitename(String sitename) {
   	 this.sitename = sitename;
    }

    public String getCityname() {
   	 return cityname;
    }

    public void setCityname(String cityname) {
   	 this.cityname = cityname;
    }

    public String getRecommended() {
   	 return recommended;
    }

    public void setRecommended(String recommended) {
   	 this.recommended = recommended;
    }
    
}


