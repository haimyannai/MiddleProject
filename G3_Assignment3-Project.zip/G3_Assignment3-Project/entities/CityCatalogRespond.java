package entities;

import java.io.Serializable;

public class CityCatalogRespond implements Serializable{

	private  String name, version, price, views;
	private  String maps, sits, tours,description,CattalodID;

	public CityCatalogRespond(String name, String version, String price, String views, String maps, String sits,
			String tours,String description,String ID) {
		this.name = name;
		this.version =version;
		this.price =price;
		this.views =views;
		this.maps =maps;
		this.sits =sits;
		this.tours = tours;
		this.description=description;
		this.CattalodID=ID;
	}

	public String getCattalodID() {
		return CattalodID;
	}

	public String getDescription() {
		return description;
	}

	public String getName() {
		return name;
	}

	public String getVersion() {
		return version;
	}

	public String getPrice() {
		return price;
	}

	public String getViews() {
		return views;
	}

	public String getMaps() {
		return maps;
	}

	public String getSits() {
		return sits;
	}

	public String getTours() {
		return tours;
	}



}
