package entities;

import java.io.Serializable;
import java.time.LocalDate;

public class RegisterDataRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	private String fullname;
	private String id;
	private String phone;
	private String sex;
	private String email;
	private String username;
	private String password;
	private String cluePassword;
	private String birthday;
	private String address;

	public RegisterDataRequest(String fullname, String id, String phone, String sex, String email, String username,
			String password,String cluePassword, String birthday, String address) {
		this.fullname = fullname;
		this.id = id;
		this.phone = phone;
		this.sex = sex;
		this.email = email;
		this.username = username;
		this.password = password;
		this.cluePassword = cluePassword;
		this.birthday = birthday;
		this.address = address;
	}

	public String getFullname() {
		return fullname;
	}

	public String getId() {
		return id;
	}

	public String getPhone() {
		return phone;
	}

	public String getSex() {
		return sex;
	}

	public String getEmail() {
		return email;
	}

	public String getBirthday() {
		return birthday;
	}

	public String getAddress() {
		return address;
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	public String getCluePassword() {
		return cluePassword;
	}
}
