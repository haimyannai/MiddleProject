package entities;

import java.io.Serializable;
import java.util.ArrayList;


public class CityWithToursAndSitesNames implements Serializable{
	private String cityName;
	private ArrayList<String> siteNames;
	private ArrayList<String> tourNames;
	
	public CityWithToursAndSitesNames(String cityName,ArrayList<String> siteNames,ArrayList<String> tourNames) {
		this.cityName = cityName;
		this.siteNames = siteNames;
		this.tourNames = tourNames;
	}

	public String getCityName() {
		return cityName;
	}

	public ArrayList<String> getSiteNames() {
		return siteNames;
	}

	public ArrayList<String> getTourNames() {
		return tourNames;
	}
}


