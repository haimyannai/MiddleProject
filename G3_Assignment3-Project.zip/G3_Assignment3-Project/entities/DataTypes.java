package entities;
public class DataTypes {
    public enum UserType {
   	 CLIENT,
   	 EMPLOYEE,
   	 CONTENTEMPLOYEE,
   	 CONTENTMANAGER,
   	 COMPANYMANAGER,
    }

}
