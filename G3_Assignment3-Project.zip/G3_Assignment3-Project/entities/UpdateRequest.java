package entities;

import java.io.Serializable;

public class UpdateRequest implements Serializable {

	private String employee, permission, description, collectionID, date, amount,id;

	public UpdateRequest(String date, String collectionID, String employee, String permission, String description,
			String amount,String id) {
		this.date = date;
		this.collectionID = collectionID;
		this.employee = employee;
		this.permission = permission;
		this.description = description;
		this.amount = amount;
		this.id=id;
	}

	public String getId() {
		return id;
	}

	public String getCollectionID() {
		return collectionID;
	}

	public String getAmount() {
		return amount;
	}

	public String getEmployee() {
		return employee;
	}

	public String getPermission() {
		return permission;
	}

	public String getDescription() {
		return description;
	}

	public String getDate() {
		return date;
	}
}
