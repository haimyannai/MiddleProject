package entities;

import java.io.Serializable;

public class CreditCardInfo implements Serializable {

	private String CreditCardCompany;
	private String CardNumber;
	private int SecurityCode;
	private String CardExpritionDate;
	private int ClientID;

	public CreditCardInfo(String CreditCardCompany, String CardNumber, int SecurityCode, String CardExpritionDate,
			int ClientID) 
	{
		setCardExpritionDate(CreditCardCompany);
		setCardNumber(CardNumber);
		setClientID(ClientID);
		setCreditCardCompany(CreditCardCompany);
		setSecurityCode(SecurityCode);
	}

	public String getCreditCardCompany() {
		return CreditCardCompany;
	}

	public void setCreditCardCompany(String creditCardCompany) {
		CreditCardCompany = creditCardCompany;
	}

	public String getCardNumber() {
		return CardNumber;
	}

	public void setCardNumber(String cardNumber) {
		CardNumber = cardNumber;
	}

	public int getSecurityCode() {
		return SecurityCode;
	}

	public void setSecurityCode(int securityCode) {
		SecurityCode = securityCode;
	}

	public String getCardExpritionDate() {
		return CardExpritionDate;
	}

	public void setCardExpritionDate(String cardExpritionDate) {
		CardExpritionDate = cardExpritionDate;
	}

	public int getClientID() {
		return ClientID;
	}

	public void setClientID(int clientID) {
		ClientID = clientID;
	}

}


