package entities;

import java.io.Serializable;

public class mapCollectionImg implements Serializable{
	
	private byte[] img;
	private String mapName;
	private double mapVersion;
	private String mapIDCollection;
	
	public mapCollectionImg (byte[] img,String mapName, double mapVersion, String mapIDCollection ) {
		this.img=img;
		this.mapName=mapName;
		this.mapVersion=mapVersion;
		this.mapIDCollection=mapIDCollection;
	}

	public byte[] getImg() {
		return img;
	}

	public String getMapName() {
		return mapName;
	}

	public double getMapVersion() {
		return mapVersion;
	}

	public String getMapIDCollection() {
		return mapIDCollection;
	}
	
	

}



