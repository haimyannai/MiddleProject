package entities;

import java.io.Serializable;
import java.sql.ResultSet;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class BasicReportResponse implements Serializable {
	private String city;
	private String maps;
	private String purchases;
	private String subscriptions;
	private String renewals;
	private String views;
	private String downloads;
	
	public BasicReportResponse(String city,String maps, String purchases, String subscriptions, String renewals, String views, String downloads) {
		this.city=city;
		this.maps=maps;
		this.purchases= purchases;
		this.subscriptions= subscriptions;
		this.renewals = renewals;
		this.views = views;
		this.downloads = downloads;
	}

	

	@Override
	public String toString() {
		return city + " " + maps + " " + purchases + " " + subscriptions + " " + renewals + " "
				+ views + " " + downloads;
	}



	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public String getMaps() {
		return maps;
	}



	public void setMaps(String maps) {
		this.maps = maps;
	}



	public String getPurchases() {
		return purchases;
	}



	public void setPurchases(String purchases) {
		this.purchases = purchases;
	}



	public String getSubscriptions() {
		return subscriptions;
	}



	public void setSubscriptions(String subscriptions) {
		this.subscriptions = subscriptions;
	}



	public String getRenewals() {
		return renewals;
	}



	public void setRenewals(String renewals) {
		this.renewals = renewals;
	}



	public String getViews() {
		return views;
	}



	public void setViews(String views) {
		this.views = views;
	}



	public String getDownloads() {
		return downloads;
	}



	public void setDownloads(String downloads) {
		this.downloads = downloads;
	}
}


