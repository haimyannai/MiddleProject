package entities;

import java.io.Serializable;

public class HistoryPurchaseResponse implements Serializable{

	private String ID;
	private String price;
	private String city;
	private String version;
	
	public HistoryPurchaseResponse(String ID, String price, String city, String version)
	{
		this.ID=ID;
		this.price=price;
		this.city=city;
		this.version=version;
	}

	public String getID() {
		return ID;
	}

	public String getPrice() {
		return price;
	}

	public String getCity() {
		return city;
	}

	public String getVersion() {
		return version;
	}
	
	
}

