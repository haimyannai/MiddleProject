package entities;

import java.io.Serializable;
import java.time.LocalDate;

public class BasicReportRequest implements Serializable{
	private LocalDate toDate;
	private LocalDate fromDate;
	
	public BasicReportRequest(LocalDate fromDate, LocalDate toDate) {
		this.fromDate=fromDate;
		this.toDate=toDate;
	}
	
	public LocalDate getTo() {return toDate;}
	public LocalDate getFrom() {return fromDate;}
}


