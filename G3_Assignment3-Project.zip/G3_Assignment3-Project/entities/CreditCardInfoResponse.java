package entities;

import java.io.Serializable;

public class CreditCardInfoResponse implements Serializable {

	private Boolean creditCardInfoRes;

	public CreditCardInfoResponse(boolean creditCardInfoRes) {
		this.creditCardInfoRes = creditCardInfoRes;
	}

	public Boolean getCreditCardInfoRes() {
		return creditCardInfoRes;
	}

}
