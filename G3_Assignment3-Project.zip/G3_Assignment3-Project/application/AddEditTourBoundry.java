package application;

import java.io.IOException;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import Controllers.CityController;
import Controllers.UserController;
import Controllers.tourController;
import client.ChatClient;
import entities.TourRequest;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * This class is the boundary of the add/edit page it enables the user to add a
 * new tour tour to the data base or edit an existing one updates the
 * site_in_tour table in the data base according to the checked sites at the
 * sites menu
 * 
 * @author gilad 
 *
 */
public class AddEditTourBoundry extends ServerEvent {

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private TextField tourNameText;
	@FXML
	private TextField siteTimeSetText;

	@FXML
	private CheckBox accessibleCheck;
	@FXML
	private CheckBox recommndedCheck;

	@FXML
	private ComboBox<String> chooseCityCombo;
	@FXML
	private ComboBox<String> siteInTourCombo;

	@FXML
	private MenuButton sitesMenu;

	@FXML
	private TextArea descriptionText;

	@FXML
	private Button addEditBtn;

	@FXML
	private Label addEditTourText;
	@FXML
	private Label tourLengthText;

	private String loadPage;

	private Parent root = null;
	private String id;
	private String userName;
	private String position;
	private int tourID;
	private String tourName = "";
	private String tourDescription;
	private String tourCity = "";
	private String tourIsRecommended;
	private String tourIsAccessible;
	private ArrayList<ArrayList<Object>> citySites;
	private ArrayList<ArrayList<Object>> tourSites;
	private TourRequest tour = new TourRequest();
	private Scene prevPage;

	@FXML
	void initialize() {
		assert tourLengthText != null : "fx:id=\"tourLengthText\" was not injected: check your FXML file 'AddEditTourInterface.fxml'.";
		assert tourNameText != null : "fx:id=\"tourNameText\" was not injected: check your FXML file 'AddEditTourInterface.fxml'.";
		assert accessibleCheck != null : "fx:id=\"accessibleCheck\" was not injected: check your FXML file 'AddEditTourInterface.fxml'.";
		assert recommndedCheck != null : "fx:id=\"recommndedCheck\" was not injected: check your FXML file 'AddEditTourInterface.fxml'.";
		assert chooseCityCombo != null : "fx:id=\"chooseCityCombo\" was not injected: check your FXML file 'AddEditTourInterface.fxml'.";
		assert sitesMenu != null : "fx:id=\"sitesMenu\" was not injected: check your FXML file 'AddEditTourInterface.fxml'.";
		assert descriptionText != null : "fx:id=\"descriptionText\" was not injected: check your FXML file 'AddEditTourInterface.fxml'.";
		assert addEditBtn != null : "fx:id=\"addEditBtn\" was not injected: check your FXML file 'AddEditTourInterface.fxml'.";

		setAddEditTour();
	}

	/**
	 * When the user clicks on the ADD or EDIT button, this method collects the data
	 * of the tour and the sites in the tour. After the data is collected the method
	 * makes sure there are no mistakes with the sites and city name and notify the
	 * user if there are any problems. After making sure the data is valid this
	 * method uses the tour controller to add/edit tours to the data base. Returns
	 * the user to employee's work space.
	 * 
	 * @throws IOException
	 */
	@FXML
	void AddEditBtnClick(ActionEvent event) throws IOException {
		tour.setTourName(tourNameText.getText());// set tour name
		tour.setTourDescription(descriptionText.getText());// set tour description
		if (accessibleCheck.isSelected())// set tour is accessible
			tour.setIsAccessible("1");
		else
			tour.setIsAccessible("0");
		if (recommndedCheck.isSelected())// set tour is recommended
			tour.setIsRecommended("1");
		else
			tour.setIsRecommended("0");
		// checks if the tour sites are the ones checked in the menu
		removeUnselectedSites();
		if (checkSitesTime()) {// checks if the user input of sites is correctly implemented
			if (addEditBtn.getText().equals("ADD")) {// if user pressed add button , a new tour ID will be generated in
														// the query
				if (prevPage == null) {// if the user entered this page from employee main area
					if (chooseCityCombo.getSelectionModel().getSelectedItem() == null) {// the user forgot to choose a
																						// city for the tour
						HomepageBoundry.messageWindow(AlertType.CONFIRMATION, "notice",
								"You must choose a city for your tour!", "Please try again");
						return;
					} else {
						tour.setTourCity(chooseCityCombo.getSelectionModel().getSelectedItem());// sets tour city
						tourController.addTour(tour);// call mySql query and send the tour to the data base
						HomepageBoundry.messageWindow(AlertType.CONFIRMATION, "notice",
								"New tour has been added to the data base!",
								"You are now redirected to your home page ");
					}
				} else {
					tour.setTourCity(tourCity);// sets tour city
					tourController.addTour(tour);// call mySql query and send the tour to the data base
					HomepageBoundry.messageWindow(AlertType.CONFIRMATION, "notice",
							"New tour has been added to the data base!", "You are now redirected to your home page ");
				}

			} else {// if user pressed edit button
				tour.setTourID(tourID);// sets tour ID
				if (chooseCityCombo.getSelectionModel().getSelectedItem() == null)// if the user didn't change the
																					// tour's city, keep it
					tour.setTourCity(tourCity);
				else// else, the user changed the city of the tour by using the city combo box
					tour.setTourCity(chooseCityCombo.getSelectionModel().getSelectedItem());
				tourController.editTour(tour);// call mySql query and update the tour in the data base
				HomepageBoundry.messageWindow(AlertType.CONFIRMATION, "notice",
						"Tour has been updated in the data base!", "You are now redirected to your home page ");
			}
			backBtnClick(event);// after add or editing the site, the user is returned to the main working space
		}
	}

	/**
	 * This method finds any sites that the user set time for, yet eventually
	 * unchecked them from the sites menu, and so removes them from the tour's
	 * actual site list.
	 * 
	 * @param selecteItems   - a list of items that are currently checked in the
	 *                       sites menu.
	 * @param inSelectedList - a flag to determine if the site is selected on the
	 *                       menu.
	 * @param tourSites      - an ArrayList of sites that in the tour according to
	 *                       the database at the moment the page reloaded.
	 */
	public void removeUnselectedSites() {
		List<String> selectedItems = sitesMenu.getItems().stream()
				.filter(item -> CheckMenuItem.class.isInstance(item) && CheckMenuItem.class.cast(item).isSelected())
				.map(MenuItem::getText).collect(Collectors.toList());
		int inSelectedList = 0;
		ArrayList<ArrayList<Object>> tourSites = tour.getSitesInTour();
		for (int i = 0; i < tourSites.size(); i++) {
			for (int j = 0; j < selectedItems.size(); j++) {
				if (tourSites.get(i).get(0).equals(selectedItems.get(j))) {
					inSelectedList = 1;
				}
			}
			if (inSelectedList == 0)
				tourSites.remove(i);
			inSelectedList = 0;
		}
		tour.setSitesInTour(tourSites);// set the tour new sites array
	}

	/**
	 * This method checks if the sites are properly inserted to the sites list.
	 * 
	 * @param selecteItems        - a list of items that are currently checked in
	 *                            the sites menu.
	 * @param tourSites           - an ArrayList of sites that in the tour according
	 *                            to the database at the moment the page reloaded.
	 * @param selectedSitesInTour - a flag to determine if the site is in the tour's
	 *                            sites array.
	 * @return true if site data is valid, else false.
	 */
	public boolean checkSitesTime() {
		List<String> selectedItems = sitesMenu.getItems().stream()
				.filter(item -> CheckMenuItem.class.isInstance(item) && CheckMenuItem.class.cast(item).isSelected())
				.map(MenuItem::getText).collect(Collectors.toList());
		ArrayList<ArrayList<Object>> tourSites = tour.getSitesInTour();
		int selectedSiteIsInTour = 0;
		for (int i = 0; i < selectedItems.size(); i++) {
			for (int j = 0; j < tourSites.size(); j++) {
				if (selectedItems.get(i).equals(tourSites.get(j).get(0))) {// for each selected item that is in the menu
					if (tourSites.get(j).get(1).equals("")) {// if no time has been inserted
						HomepageBoundry.messageWindow(AlertType.CONFIRMATION, "notice",
								"Please make sure you set each site in the tour it's recommended time",
								"please try again");
						return false;
					}
				}

				if (Integer.valueOf((String) tourSites.get(j).get(1)) <= 0) {// if the time inserted is negative or zero
					HomepageBoundry.messageWindow(AlertType.CONFIRMATION, "notice",
							"Please make sure you set valid times for each site in the tour", "please try again");
					return false;
				}
				selectedSiteIsInTour = 1;
			}
		}
		if (selectedSiteIsInTour == 0) {// the site selected in the menu is not on the tour's sites array
			HomepageBoundry.messageWindow(AlertType.CONFIRMATION, "notice",
					"Please make sure you set each site in the tour it's recommended time", "please try again");
			return false;
		}
		selectedSiteIsInTour = 0;

		return true;
	}

	/**
	 * This method returns to the previous page and remove this page listeners
	 * 
	 * @throws IOException
	 */
	@FXML
	void backBtnClick(ActionEvent event) throws IOException {
		if (ChatClient.getCitiesListener.contains(this))
			ChatClient.getCitiesListener.remove(ChatClient.getCitiesListener.size() - 1);
		if (ChatClient.getCitySitesListener.contains(this))
			ChatClient.getCitySitesListener.remove(ChatClient.getCitySitesListener.size() - 1);
		if (prevPage == null) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/EmployeeMainAreaInterface.fxml"));
			root = loader.load();
			EmployeeMainAreaBoundry employeeMainAreaBoundry = loader.getController();
			employeeMainAreaBoundry.setEmployeeInfo(userName, position, String.valueOf(id));
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(new Scene(root));
			window.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
				public void handle(WindowEvent e) {
					try {
						UserController.logout(String.valueOf(id));
					} catch (SQLException ex) {
						ex.printStackTrace();
					}
				}
			});
			window.show();
		} else {
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(prevPage);
			window.show();
		}
	}

	/**
	 * When the user chooses a city to his tour, this method generates the sites
	 * that belongs to this city.
	 */
	@FXML
	void chooseCityClick(ActionEvent event) {
		sitesMenu.getItems().clear();
		if (ChatClient.getCitySitesListener.contains(this))
			ChatClient.getCitySitesListener.remove(ChatClient.getCitySitesListener.size() - 1);
		ChatClient.getCitySitesListener.add(this);
		CityController.getCitySites(chooseCityCombo.getSelectionModel().getSelectedItem(), tourName);// uses the city
																										// name from
																										// combo box to
																										// get all the
																										// sites of the
																										// chosen city

	}

	/**
	 * This method returns the user to its home page
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void homeBtnClick(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/EmployeeMainAreaInterface.fxml"));
		root = loader.load();
		EmployeeMainAreaBoundry employeeMainAreaBoundry = loader.getController();
		employeeMainAreaBoundry.setEmployeeInfo(userName, position, String.valueOf(id));
		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene(new Scene(root));
		window.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent e) {
				try {
					UserController.logout(String.valueOf(id));
				} catch (SQLException ex) {
					ex.printStackTrace();
				}
			}
		});
		window.show();
	}

	/**
	 * keeps the parameters from the previous page in order to load it again
	 * properly when needed.
	 * 
	 * @param userName - previous page user name
	 * @param userType - previous page permission
	 * @param id       - previous page id
	 * @param prevPage - previous scene
	 */
	void setEmployeeInfo(String userName, String userType, String id, Scene prevPage) {
		this.id = id;
		this.userName = userName;
		position = userType;
		this.prevPage = prevPage;
	}

	/**
	 * When the user click "edit tour" this methods loads all the tour's
	 * information.
	 * 
	 * @param tourOption - the tour that is currently in the data base and the user
	 *                   wants to edit.
	 */
	void setEditTour(ArrayList<Object> tourOption) {
		addEditTourText.setText("Edit Tour");
		addEditBtn.setText("Update");
		tourID = (int) tourOption.get(0);
		tourName = (String) tourOption.get(1);
		tourNameText.setText(tourName);
		tourDescription = (String) tourOption.get(2);
		descriptionText.setText(tourDescription);
		tourCity = (String) tourOption.get(3);
		chooseCityCombo.setPromptText(tourCity);
		tourIsRecommended = (String) tourOption.get(4);
		if (tourIsRecommended.equals("1")) {
			recommndedCheck.setSelected(true);
		}
		tourIsAccessible = (String) tourOption.get(5);
		if (tourIsAccessible.equals("1")) {
			accessibleCheck.setSelected(true);
		}

		// get all the cities, get the sites of the tour's city and check sites that
		// already in the tour
		ChatClient.getCitySitesListener.add(this);
		CityController.getCitySites(tourCity, tourName);
	}

	/**
	 * Starts at page initialization. fills the city combo box with cities
	 */
	void setAddEditTour() {
		ChatClient.getCitiesListener.add(this);
		CityController.getCities();
		System.out.println("thats it for add  tour button");
	}

	/**
	 * If the user comes from "AddEditMap" page, this method fills the combo box with cities
	 * set the city name from the "AddEditMap" page
	 * disables the option to edit the city for the tour
	 * @param cityName
	 */
	void setAddEditTourFromPlus(String cityName) {
		chooseCityCombo.setPromptText(cityName);
		chooseCityCombo.setDisable(true);
		tourCity = cityName;
		ChatClient.getCitySitesListener.add(this);
		CityController.getCitySites(tourCity, tourName);
	}

	/**
	 * When the user click on a site that he wants to set time to, this method
	 * brings the recommended time for this site which is currently in the data base
	 * 
	 * @param site - the site that the user has chosen to set time to.
	 */
	@FXML
	void siteComboClick(ActionEvent event) {
		String site = siteInTourCombo.getSelectionModel().getSelectedItem();
		siteTimeSetText.setText("");// if the recommended time is not in the database, clears the text
		for (int i = 0; i < tourSites.size(); i++) {// for each site in the tour
			try {
				if (site.equals(tourSites.get(i).get(0))) {
					siteTimeSetText.setText((String) tourSites.get(i).get(4));// set the site recommended time in the
																				// text field
					break;
				}
			} catch (Exception e) {
			}
			;
		}
	}

	/**
	 * Clears and refresh the sites that in the combo list. using the method
	 * "refreshSites".
	 * 
	 * @param event
	 */
	@FXML
	void refreshSiteBtn(ActionEvent event) {
		siteInTourCombo.getItems().clear();
		refreshSites();
	}
	/**
	 * Clears and refresh the sites that in the combo list. using the method
	 * "refreshSites".
	 * 
	 * @param event
	 */
	@FXML
	void refreshSitecmb(MouseEvent event) {

		siteInTourCombo.getItems().clear();
		refreshSites();
	}

	/**
	 * Sets the time user has set to the selected site in the combo box.
	 * 
	 * @param sites   - the sites that are currently added to the tour by the user.
	 * @param newSite - a new site that the user wants to add to the tour's sites
	 *                list.
	 */
	@FXML
	void setTimeBtnClick(ActionEvent event) {
		try {
			Integer.valueOf(siteTimeSetText.getText());
		} catch (Exception e) {
			HomepageBoundry.messageWindow(AlertType.CONFIRMATION, "notice",
					"Please make sure you set valid times for each site in the tour", "please try again");
			return;
		}
		
		ArrayList<ArrayList<Object>> sites;
		sites = tour.getSitesInTour();
		for (int i = 0; i < sites.size(); i++) {// for each site in the new tour
			if (sites.get(i) != null) {// if there is a site on the site list
				if (siteInTourCombo.getSelectionModel().getSelectedItem().equals(sites.get(i).get(0))) {// if the site
																										// is already in
																										// the tour and
																										// we want to
																										// change its
																										// time
					sites.get(i).set(1, siteTimeSetText.getText());
					tour.setSitesInTour(sites);
					HomepageBoundry.messageWindow(AlertType.INFORMATION, "Success!", "Time has been set to this site!", "");
					return;
				}
			}
		}
		// the site is not in the tour yet and we want to add him and his time
		ArrayList<Object> newSite = new ArrayList<>();
		newSite.add(siteInTourCombo.getSelectionModel().getSelectedItem());// adds the site name
		newSite.add(siteTimeSetText.getText());// adds the site recommended time
		for (ArrayList<Object> site : citySites) {// find the site id in city sites list
			if (site.get(0).equals(siteInTourCombo.getSelectionModel().getSelectedItem()))// if the names are equal
				newSite.add(site.get(1));// adds the site ID
		}
		sites.add(newSite);// adds the new site to the tour's sites
		tour.setSitesInTour(sites); // updates the tour's sites list
		HomepageBoundry.messageWindow(AlertType.INFORMATION, "Success!", "Time has been set to this site!", "");
	}

	/**
	 * Refresh the selected sites combo box so the user would know which sites needs
	 * to be set time to.
	 * 
	 * @param selecteItems - a list of items that are currently checked in the sites
	 *                     menu.
	 */
	public void refreshSites() {
		List<String> selectedItems = sitesMenu.getItems().stream()
				.filter(item -> CheckMenuItem.class.isInstance(item) && CheckMenuItem.class.cast(item).isSelected())
				.map(MenuItem::getText).collect(Collectors.toList());
		for (int i = 0; i < selectedItems.size(); i++) {
			siteInTourCombo.getItems().add(selectedItems.get(i));// putting the sites in the sites combo box
		}
	}

	/**
	 * This method fills the cities combo box.
	 */
	@Override
	public void someoneGetCities(ArrayList<Object> result) {
		int i = 0;
		result.remove(0);
		while (i < result.size()) {// find the tour's city
			chooseCityCombo.getItems().add((String) result.get(i++));// fill the combo box with sites of the tour's city
		}
	}

	/**
	 * This method fills the sites menu and checks the ones that already in the
	 * tour. Set citySites - all the sites that in the city, and tourSites - all the
	 * sites that in the tour, for further use. Calculates the total time of the
	 * tour
	 */
	@Override
	public void someoneGetCitySites(ArrayList<Object> result) {
		CheckMenuItem site;
		System.out.println("its the sites listener");
		citySites = (ArrayList<ArrayList<Object>>) result.get(1);
		tourSites = (ArrayList<ArrayList<Object>>) result.get(2);
		for (int i = 0; i < citySites.size(); i++) {
			site = new CheckMenuItem((String) citySites.get(i).get(0));
			sitesMenu.getItems().add(site);// putting the sites in the menu
			for (int j = 0; j < tourSites.size(); j++) {// add checkers to them depends on tourName
				if (citySites.get(i).get(1).equals(tourSites.get(j).get(1))) {
					site.setSelected(true);
				}
			}
		}
		setTourSites();
		refreshSites();// sets sites in combo box
		int totalTime = 0;
		for (ArrayList<Object> a : tourSites) {// gets the total time of the tour
			totalTime = totalTime + Integer.valueOf((String) a.get(4));
		}
		tourLengthText.setText(String.valueOf(totalTime));
	}
	
	/**
	 * This method sets the tour sites in the tour object that will be uploaded to the data base
	 */
	public void setTourSites() {
		
		for(ArrayList<Object> site : tourSites) {//for each site
			ArrayList<Object> sitesInTour= new ArrayList<>();
			sitesInTour.add((String) site.get(0));//set site name
			sitesInTour.add((String) site.get(4));//set site time
			sitesInTour.add((int) site.get(1));//set site id
			tour.getSitesInTour().add(sitesInTour);
			
		}
	}

}