package application;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

import entities.CityCatalogRespond;
import entities.ClientCardResponse;
import entities.CreditCardInfoResponse;
import entities.EditMapEmployeeRequest;
import entities.HistoryPurchaseResponse;
import entities.LoginDataResponse;
import entities.RegisterDataRequest;
import entities.RegisterDataResponse;
import entities.SiteInfoForEditResponse;
import entities.ToursOfCitiesInfo;
import entities.mapCollectionImg;

public class ServerEvent implements Serializable {

	public void getMapSiteDetails(ArrayList<Object> rs) {

	}

	public void getMapTourDetails(ArrayList<Object> result) {

	}

	public void closeServer() throws IOException {

	}

	public void getMapDetails(ArrayList<Object> arr) {

	}

	public void nextConfirmation(String respond) {

	}

	public void saveNewConfirmation(String respond) {

	}

	/**
	 * This method allows to update the details of the user.
	 * @param res
	 */
	public void someoneUpdateHisInfo(boolean res) {
	}

	/**
	 * This method allows to get client personal details
	 * @param registerDataRequest
	 */
	public void getUpdateClientInfo(RegisterDataRequest registerDataRequest) {

	}

	/**
	 * this method gets an Array of images that needed to be sent to the client as a
	 * respond to his/hers purchase, and download it to the client computer to
	 * designated address.
	 * 
	 * @param arr
	 */
	public void someoneGetMapCollectionCleint(ArrayList<mapCollectionImg> arr) {
	}

	/**
	 * present to the client all the messages that the system sent him in varies
	 * cases.
	 * 
	 * @param respond: list of messages.
	 */
	public void SetClientMessagesList(ArrayList<Object> respond) {

	}

	/**
	 * present a massage after the manager of any kind reject the request.
	 * 
	 * @param respond: boolean answer
	 */
	public void SetDeniedNewMapVersionRespond(boolean respond) {

	}

	/**
	 * present a massage that indicate whether the server set the new map collection
	 * price.
	 * 
	 * @param respond: string that specify the outcome.
	 */
	public void SetNewMapUpdateRespond(String respond) {

	}

	public void getSiteInfoBackForEdit(ArrayList<SiteInfoForEditResponse> arr) {

	}

	public void getSiteInfoBackForEdit(boolean bool) {

	}

	public void getSiteInfoFowardForAddRes(boolean bool) {

	}

	public void someoneWantToUpdateTheSiteEditList(ArrayList<ToursOfCitiesInfo> arr, String desc) {

	}

	public void getTourNamesBackToWin(boolean bool) {

	}

	public void getNewCitiesInfoResToWin(boolean bool) {

	}

    /**
     * this method get the relavent details from the server and init the page as the
     * user expected
     * @param mapImage,arr
     */
	public void someoneGetmapImagelisteners(Object mapImage, ArrayList<EditMapEmployeeRequest> arr) {

	}
    /**
     * this method allows to get the maps name collection 
     * for the showing maps page to the employees
     * @param arrMap,arrSite
     */
	public void someoneGetMapsNameCollectoin(ArrayList<String> arrMap, ArrayList<EditMapEmployeeRequest> arrSite) {

	}
    /**
     * this method allows to send the edit changes from the content employee to the manager
     * by sending it to the db 
     * @param update1,update2
     */
	public void someoneWantToUpdateTheSiteEditList(boolean update1, boolean update2) {

	}

    /**
     * this method allows to set the map the chosed by the employee for showing
     * @param mapImage
     */
	public void RegullarEmployeeWantPhoto(Object mapImage) {

	}

	public void someoneGetCities(ArrayList<Object> result) {
	}

	public void someoneGetCitySites(ArrayList<Object> result) {
	}

	/**
	 * the boundary get as a message all the edit requests from the server and
	 * insert it to the designated tableview.
	 * 
	 * @param result: get all the request in the form of ArrayList
	 */
	public void setEditMapRequests(ArrayList<Object> result) {
	}

	public ServerEvent() {
	}

	/**
	 * present a pop up messages with all the clients expiring subscriptions.
	 * 
	 * @param exCity
	 */
	public void presentexpSubscriptions(ArrayList<Object> exCity) {
	}

	/**
	 * presented the city catalog with the cites that answered the search values.
	 * 
	 * @param cityList
	 */
	public void CityListAfterSearch(ArrayList<Object> cityList) {
	}

	/**
	 * this method get from the server all the request of change the collection
	 * price and loads it to the table.
	 * 
	 * @param respond: all the price change request from DB in ArrayList
	 */
	public void SetCollectionPriceUpdateRequestTable(ArrayList<Object> respond) {
	}

	/**
	 * present a message after the server updated the new map collection price.
	 * 
	 * @param result: answer from the server
	 */
	public void returnSetNewPriceResult(boolean result) {
	}

	/**
	 * this methods gets the message from the server after the content manager
	 * reject the editing request a presented it.
	 * 
	 * @param respond: an answer fromm the server.
	 */
	public void DeinedRequestAnswer(boolean respond) {
	}

	/** 
     * this method get the answer from the server, and load the next page by the kind of the user
     * @param loginResponse
     */
	public void someoneLoggedin(LoginDataResponse loginRes) {
	}

    /**this method allows to get registration answer from the db
     * @param registerDataResponse
     */
	public void someoneRegistered(RegisterDataResponse registerDataResponse) {
	}

	/**
	 * present a respond to the user whether the client card details were successfully entered the DB.
	 * @param creditCardInfoResponse
	 */
	public void someoneSetCreditInfo(CreditCardInfoResponse creditCardInfoResponse) {
	}

    /** 
     * this method get the client card information from the DB
     * and display it to the user
     * @param clientCardResponse
     */
	public void someoneGetClientCard(ClientCardResponse clientCardResponse) {
	}

    /**
     * this method get the history purchase information from the DB
     * and display it to the user
     * @param HPR
     */
	public void someoneGetHistoryPurchase(ArrayList<HistoryPurchaseResponse> historyPurchaseResponse) {
	}

	/**
	 * present to the user the payment methods in the case it wishes to change any of them.
	 * @param payment
	 */
	public void returnPaymentInfo(ArrayList<Object> payment) {
	}

	/**
     * gets the result of sending a new price change at map and present a proper message.
     * @param result
     */
	public void SetNewPaymentInfoResult(boolean result) {
	}

	public void someoneAskedForBasicReport(ArrayList<Object> basicReportResponse) {
	}

	/**
	 * fill the Observable List with the answer from the quarry insert the
	 * Observable List to table view
	 * 
	 * @param catalogRespond: get list of detail about all the citys in the DB.
	 */
	public void setCityCatalog(ArrayList<CityCatalogRespond> catalogRespond) {
	}

	public void passMapInfo(ArrayList<Object> arr) {
	}

	/**
	 * this methods returns to the client the respond from the DB regarding the
	 * purchase. if the subscription still active it allowed the user to download to
	 * current version of each map in the collection. if the user don't have payment
	 * method record or he has expiring credit card it ask the user if his wishes to
	 * move to a different page to resolve the issue.
	 * 
	 * @param Respond
	 */
	public void setOneTimePurchaseRespond(String Respond) {
	}

	/**
	 * the method return an answer from the server for the action of purchase
	 * subscription. if there is shortage of client card record or the card is
	 * expiring,this method present a proper message that asked if the user wishes
	 * to move to different boundary to resolve the issue. if the client owns this
	 * subscription, no action will be taken while sending the maps to the clients
	 * computer.
	 * 
	 * @param respond
	 */
	public void setSubscriptionRespond(String respond) {
	}

	/**
	 * returns the renewal message from the server, if the process was successful it
	 * present a message and removes the city from the expiring list, and increase
	 * the renewal counter.
	 * 
	 * @param Renewal
	 */
	public void Renewalmsg(String Renewal) {
	}

	public void someoneGetData(ArrayList<Object> result) {
	}

	public void someoneAskedForMapName(ArrayList<Object> mapsArray) {
	}

}
