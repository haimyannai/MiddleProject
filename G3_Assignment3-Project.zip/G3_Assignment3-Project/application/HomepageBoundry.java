package application;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Optional;

import Controllers.UserController;
import client.ChatClient;
import entities.LoginDataResponse;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

 /**
  * this class allows to login to the system
  */
public class HomepageBoundry extends ServerEvent {

	@FXML
	private RadioButton radioBtn;

	@FXML
	private Label txtEnterIP;

	@FXML
	private Label txtConnected;

	@FXML
	private TextField ServerIPtext;

	@FXML
	private TextField UserNameTEXT;

	@FXML
	private TextField PasswordTEXT;

	@FXML
	private Button LoggInButton;

	@FXML
	private Button RegistrationButton;

	@FXML
	private Button CitycatalogButton;

	@FXML
	private Hyperlink ForgotPasswordLink;

	@FXML
	private Hyperlink ContectUsLink;

	@FXML
	private Hyperlink PrivacyTermLink;

	@FXML
	private AnchorPane homepageAncor;

	private ActionEvent event;

	private Parent root = null;

	private int flagWindow = 0;

	private Stage window = null;

	private ArrayList<String> info = new ArrayList<String>();

	@FXML
	void initialize() {
		assert ServerIPtext != null : "fx:id=\"ServerIPtext\" was not injected: check your FXML file 'HomePageInterface.fxml'.";
		assert radioBtn != null : "fx:id=\"radioBtn\" was not injected: check your FXML file 'HomePageInterface.fxml'.";
		assert txtEnterIP != null : "fx:id=\"txtEnterIP\" was not injected: check your FXML file 'HomePageInterface.fxml'.";
		assert txtConnected != null : "fx:id=\"txtConnected\" was not injected: check your FXML file 'HomePageInterface.fxml'.";
		assert UserNameTEXT != null : "fx:id=\"UserNameTEXT\" was not injected: check your FXML file 'HomePageInterface.fxml'.";
		assert LoggInButton != null : "fx:id=\"LoggInButton\" was not injected: check your FXML file 'HomePageInterface.fxml'.";
		assert RegistrationButton != null : "fx:id=\"RegistrationButton\" was not injected: check your FXML file 'HomePageInterface.fxml'.";
		assert CitycatalogButton != null : "fx:id=\"CitycatalogButton\" was not injected: check your FXML file 'HomePageInterface.fxml'.";
		assert ForgotPasswordLink != null : "fx:id=\"ForgotPasswordLink\" was not injected: check your FXML file 'HomePageInterface.fxml'.";
		assert ContectUsLink != null : "fx:id=\"ContectUsLink\" was not injected: check your FXML file 'HomePageInterface.fxml'.";
		assert PrivacyTermLink != null : "fx:id=\"PrivacyTermLink\" was not injected: check your FXML file 'HomePageInterface.fxml'.";
		assert PasswordTEXT != null : "fx:id=\"PasswordTEXT\" was not injected: check your FXML file 'HomePageInterface.fxml'.";
		if (ChatClient.setCreditInfolisteners.contains(this))
			ChatClient.setCreditInfolisteners.remove(ChatClient.setCreditInfolisteners.size() - 1);
	}

    /**
     *  this method load the next page by name page that recieved
     * @param page
     * */
	public void Loadpage(String page) throws IOException {

		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/" + page + "Interface.fxml"));
		root = loader.load();
		try {
			switch (page) {
			case "CityCatalog":
				CityCatalogBoundry citycatalog = loader.getController();
				citycatalog.setClientInfo("", "guest", "", null);
				// one more row to active the catalog
				break;
			case "Registration":

				break;
			case "Homepage":
				/// ***//
				break;

			}
			info.removeAll(info);
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(new Scene(root));
			window.show();
		} catch (Exception e) {e.printStackTrace();}
	}

	/**
     *  this method load the registration page while pressing on registration btn
     * @param event
     * @throws IOException
     */
	@FXML
	void ClickbtnRegistration(ActionEvent event) throws IOException {
		this.event = event;
		Loadpage("Registration");

	}

	/**
     * this method load the city catalog page while pressing on city catalog btn
     * @param event
     * @throws IOException
     */
	@FXML
	void ClickbtnCitycatalog(ActionEvent event) throws IOException {
		this.event = event;
		Loadpage("CityCatalog");
	}

    /**
     * this method load the city home page while pressing on home page btn
     * @param event
     * @throws IOException
     */
	@FXML
	void ClickBtnHomePage(ActionEvent event) throws IOException {
		this.event = event;
		Loadpage("HomePage");
	}
    /**
     * this method load the privacy terms page while pressing on privacy terms btn
     * @param event
     * @throws IOException
     */
	@FXML
	void ClickbtnPrivacyTerms(ActionEvent event) throws IOException {
		this.event = event;
		Loadpage("PrivacyTerms");
	}

    /** 
     * this method load the contect us page while pressing on contect us btn
     * @param event
     * @throws IOException
     */
	@FXML
	void ClickbtnContactus(ActionEvent event) throws IOException {
		this.event = event;
		Loadpage("ContectUs");
	}

    /**
     * this method load the forgot pass window while pressing on forgot password link
     * @param event
     */
	@FXML
	void ClickbtnForgotPass(ActionEvent event) {
		messageWindow(AlertType.INFORMATION, "Notify", "Dont worry!",
				"Call this number 0544385766 or send email to gcm_serviceControl@gmail.com");
	}

    /**
     * this method allows to user who exist in the system to get in it
     * @param event
     * @throws SQLException
     * @throws IOException
     */
	@FXML
	void ClickBtnLogIn(ActionEvent event) throws SQLException, IOException {
		this.event = event;
		String username = UserNameTEXT.getText();
		String password = PasswordTEXT.getText();
		if (username.equals("") || password.equals(""))
			messageWindow(AlertType.ERROR, "Error", "please fill all the the missing fileds", "try again!");
		else {
			ChatClient.addLoginListener(this);
			UserController.checkuserinDB(username, password);
		}

	}

    /**
     * auxiliary method for pop up window
     * @param alertType
     * @param win
     * @param mes
     * @param mes1
     * @return
     */
	public static Optional<ButtonType> messageWindow(AlertType alertType, String win, String mes, String mes1) {
		Alert alert = new Alert(alertType);
		alert.setTitle(win);
		alert.setHeaderText(mes);
		alert.setContentText(mes1);
		return alert.showAndWait();
	}

	/** 
     * this method get the answer from the server, and load the next page by the kind of the user
     * @param loginResponse
     */
	@Override
	public void someoneLoggedin(LoginDataResponse loginResponse) {
		Platform.runLater(()->{
		if (loginResponse.getLoginRes()) {
			FXMLLoader loader = null;
			Parent root = null;
			try {
				switch (loginResponse.getUserType().toString().toLowerCase()) {
				case "client":
					loader = new FXMLLoader(getClass().getResource("/application/ClientMainAreaInterface.fxml"));
					root = loader.load();
					ClientMainAreaBoundry Client = loader.getController();
					Client.setClientInfo(loginResponse.getUsername(), "client", loginResponse.getId());
					break;
				case "employee":
					loader = new FXMLLoader(getClass().getResource("/application/EmployeeMainAreaInterface.fxml"));
					root = loader.load();
					EmployeeMainAreaBoundry Employee = loader.getController();
					Employee.setEmployeeInfo(loginResponse.getUsername(), "employee", loginResponse.getId());
					break;
				case "contentemployee":
					loader = new FXMLLoader(getClass().getResource("/application/EmployeeMainAreaInterface.fxml"));
					root = loader.load();
					EmployeeMainAreaBoundry contentEmployee = loader.getController();
					contentEmployee.setEmployeeInfo(loginResponse.getUsername(), "content employee",
							loginResponse.getId());
					break;
				case "contentmanager":
					loader = new FXMLLoader(getClass().getResource("/application/EmployeeMainAreaInterface.fxml"));
					root = loader.load();
					EmployeeMainAreaBoundry contentManager = loader.getController();
					contentManager.setEmployeeInfo(loginResponse.getUsername(), "content manager",
							loginResponse.getId());
					break;
				case "companymanager":
					loader = new FXMLLoader(getClass().getResource("/application/EmployeeMainAreaInterface.fxml"));
					root = loader.load();
					EmployeeMainAreaBoundry globalManager = loader.getController();
					globalManager.setEmployeeInfo(loginResponse.getUsername(), "company manager",
							loginResponse.getId());
					break;
				}
				if (flagWindow == 0) {
					this.window = (Stage) ((Node) event.getSource()).getScene().getWindow();
					window.setScene(new Scene(root));
					flagWindow = 1;
				}
				window.show();
				window.setOnCloseRequest(new EventHandler<WindowEvent>() {
					@Override
					public void handle(WindowEvent e) {
						try {
							UserController.logout(loginResponse.getId());
						} catch (SQLException ex) {
							ex.printStackTrace();
						}
					}
				});
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else if (loginResponse.getIfconected().equals("connected")) {
			messageWindow(AlertType.ERROR, "OOPS!", "already connected", "");
//			Platform.runLater(() -> {
//				if (ChatClient.Loginlisteners.contains(this))
//					ChatClient.Loginlisteners.remove(ChatClient.Loginlisteners.size() - 1);
//			});
		} else {
			messageWindow(AlertType.ERROR, "Error", "NOT exist in the system", "please register!");
		}
		if (ChatClient.Loginlisteners.contains(this))
			ChatClient.Loginlisteners.remove(ChatClient.Loginlisteners.size() - 1);
		});
	}

}