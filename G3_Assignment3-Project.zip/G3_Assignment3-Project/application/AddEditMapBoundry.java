package application;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import Controllers.MapController;
import Controllers.UserController;
import client.ChatClient;
import entities.CityWithToursAndSitesNames;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * connects the javafx scene with the program. users can add a new map or edit
 * the details in an existing one choosing an image, city and tours and sites
 * from the city as well as editing the name and description.
 * 
 * @author dor
 *
 */
public class AddEditMapBoundry extends ServerEvent {
	/*
	 * @FXML private ResourceBundle resources;
	 * 
	 * @FXML private URL location;
	 */

	private Scene currentPage;

	@FXML
	private Label addEditMapText;

	@FXML
	private Label lblAddMap;

	@FXML
	private Label lblAddMap2;

	@FXML
	private ComboBox<String> mapCombo;

	@FXML
	private TextField mapNameText;

	@FXML
	private ComboBox<String> cityComboBox;

	@FXML
	private MenuButton addSiteMenu;

	@FXML
	private MenuButton addTourMenu;

	@FXML
	private TextArea descriptionText;

	@FXML
	private Button saveButton;

	@FXML
	private Button backButton;

	@FXML
	private Button nextButton;

	@FXML
	private Button createNewSiteButton;

	@FXML
	private Button xMapNameSymbol;

	@FXML
	private Button createNewTourButton;

	private Stage window;

	private String userName;

	private String permission;

	private String ID;

	private String cityName;

	private String originalCityName = "";

	private String originalMapName = "";

	private boolean isNewMap;

	private ArrayList<Object> array;

	private ActionEvent event = null;

	private int flagSitePlus = 0;

	private int flagTourPlus = 0;

	private String cityNameCmb;

	private String cityNameCmbTour;

	@FXML
	void initialize() {
		assert addEditMapText != null : "fx:id=\"addEditMapText\" was not injected: check your FXML file 'AddEditMapInterface.fxml'.";
		assert mapNameText != null : "fx:id=\"mapNameText\" was not injected: check your FXML file 'AddEditMapInterface.fxml'.";
		assert cityComboBox != null : "fx:id=\"cityComboBox\" was not injected: check your FXML file 'AddEditMapInterface.fxml'.";
		assert lblAddMap != null : "fx:id=\"lblAddMap\" was not injected: check your FXML file 'AddEditMapInterface.fxml'.";
		assert addSiteMenu != null : "fx:id=\"addSiteMenu\" was not injected: check your FXML file 'AddEditMapInterface.fxml'.";
		assert addTourMenu != null : "fx:id=\"addTourMenu\" was not injected: check your FXML file 'AddEditMapInterface.fxml'.";
		assert lblAddMap2 != null : "fx:id=\"lblAddMap2\" was not injected: check your FXML file 'AddEditMapInterface.fxml'.";
		assert mapCombo != null : "fx:id=\"mapCombo\" was not injected: check your FXML file 'AddEditMapInterface.fxml'.";
		assert descriptionText != null : "fx:id=\"descriptionText\" was not injected: check your FXML file 'AddEditMapInterface.fxml'.";
		assert saveButton != null : "fx:id=\"saveButton\" was not injected: check your FXML file 'AddEditMapInterface.fxml'.";
		assert backButton != null : "fx:id=\"backButton\" was not injected: check your FXML file 'AddEditMapInterface.fxml'.";
		assert nextButton != null : "fx:id=\"nextButton\" was not injected: check your FXML file 'AddEditMapInterface.fxml'.";
		assert createNewSiteButton != null : "fx:id=\"createNewSiteButton\" was not injected: check your FXML file 'AddEditMapInterface.fxml'.";
		assert xMapNameSymbol != null : "fx:id=\"xMapNameSymbol\" was not injected: check your FXML file 'AddEditMapInterface.fxml'.";
		assert createNewTourButton != null : "fx:id=\"createNewTourButton\" was not injected: check your FXML file 'AddEditMapInterface.fxml'.";

	}

	/**
	 * sets the basic user info from previous page parametars of the logged in user
	 * include:
	 * 
	 * @param userName   (String)
	 * @param permission (String)
	 * @param ID         (String)
	 * @param prevPage   (Stage)
	 */
	public void setEmployeeInfo(String userName, String permission, String ID, Stage prevPage) {
		this.userName = userName;
		this.permission = permission;
		this.ID = ID;
		this.window = prevPage;
	}

	/**
	 * calls to the server in order to import relevant data according to a map name.
	 * in case of a new map, will recieve a string "".
	 * 
	 * @param mapName (String)
	 */
	public void setMapInfo(String mapName) {
		xMapNameSymbol.setVisible(false);
		ChatClient.AddgetMapInfolistener(this);
		MapController.getMapInfo(mapName);
	}

	@Override
	/**
	 * Receives a full array of information from the server in order to set up the
	 * map page in the GUI
	 */
	public void getMapDetails(ArrayList<Object> arr) {
		Platform.runLater(() -> {

			if (((ArrayList<String>) arr.get(1)).get(0).equals("under edit")) {
				back();
				HomepageBoundry.messageWindow(AlertType.INFORMATION, "Failed",
						"This map is currently under edit by someone else", "please try again later");
				return;
			}
			if (((ArrayList<String>) arr.get(1)).get(0).equals("error no map found")) {
				back();
				HomepageBoundry.messageWindow(AlertType.INFORMATION, "Failed", "Error loading map", "contact admin");
				return;
			}
			array = arr;
			for (CityWithToursAndSitesNames city : (ArrayList<CityWithToursAndSitesNames>) arr.get(2)) {
				cityComboBox.getItems().add(city.getCityName());
			}
			if (((ArrayList<String>) arr.get(1)).get(0).equals("")) {
				loadNewMap(arr);
			} else {
				loadMap(arr);
			}
			// set on close method
			// window = (Stage) addEditMapText.getScene().getWindow();
			this.originalMapName = ((ArrayList<String>) arr.get(1)).get(0);
			window.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
				public void handle(WindowEvent e) {
					try {
						UserController.logout(ID);
					} catch (SQLException ex) {
						ex.printStackTrace();
					}
					try {
						MapController mapController = new MapController();
						mapController.getMapCollectionExit(new String(originalMapName));
					} catch (SQLException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
				}
			});

		});
	}

	/**
	 * in case map name was empty ("") uses the information in order to load new map
	 * for editing
	 * 
	 * @param arr
	 */
	private void loadNewMap(ArrayList<Object> arr) {
		/*
		 * createNewSiteButton.setVisible(false); createNewTourButton.setVisible(false);
		 */
		lblAddMap.setVisible(true);
		mapCombo.setVisible(true);
		lblAddMap2.setVisible(true);
		nextButton.setVisible(false);
		addEditMapText.setText("New Map");
		ChatClient.addMapNamesListener(this);
		MapController.getMapsNames();
		cityName = "";
	}

	/**
	 * sets up the GUI according to data recieved in "getMapDetails" method
	 * 
	 * @param arr
	 */
	private void loadMap(ArrayList<Object> arr) {
		saveButton.setVisible(false);
		int relevantCity = 0;

		originalMapName = ((ArrayList<String>) arr.get(1)).get(0);
		originalCityName = ((ArrayList<String>) arr.get(1)).get(3);
		// set basic map info
		mapNameText.setText(((ArrayList<String>) arr.get(1)).get(0));
		descriptionText.setText(((ArrayList<String>) arr.get(1)).get(1));
		cityName = ((ArrayList<String>) arr.get(1)).get(3);

		for (String city : cityComboBox.getItems()) {
			if (city.equals(originalCityName))
				break;
			relevantCity++;
		}
		cityComboBox.getSelectionModel().clearAndSelect(relevantCity);

		ArrayList<String> selectedSites = (ArrayList<String>) arr.get(3);// added selected cities
		// get(4) is an array of sites in map

		// set sites and tours for city
		for (CityWithToursAndSitesNames city : (ArrayList<CityWithToursAndSitesNames>) arr.get(2)) {
			if (city.getCityName().equals(cityName)) {
				setSitesAndToursForACity(city, selectedSites);// changed the methood
				break;
			}
		}
	}

	/**
	 * 
	 * @param city          (CityWithToursAndSitesNames) the chosen city in order to
	 *                      load other combo boxs
	 * @param selectedSites (ArrayList<String>) the list of sites to load in case
	 *                      it's relavant origianl city
	 */
	public void setSitesAndToursForACity(CityWithToursAndSitesNames city, ArrayList<String> selectedSites) {

		addSiteMenu.getItems().removeAll(addSiteMenu.getItems());
		addTourMenu.getItems().removeAll(addTourMenu.getItems());
		CheckMenuItem item;
		// add all sites in map to site menu button
		for (String name : city.getSiteNames()) {
			item = new CheckMenuItem(name);
			if (originalCityName.equals(cityComboBox.getSelectionModel().getSelectedItem())
					&& originalMapName.equals(mapNameText.getText())) {// added this
				if (selectedSites == null)
					break;
				for (String site : selectedSites) {
					if (name.equals(site))
						item.setSelected(true);
				}
			}
			addSiteMenu.getItems().add(item);
		}
		// add all sites in map to tours menu button
		for (String name : city.getTourNames()) {
			item = new CheckMenuItem(name);
			if (originalCityName.equals(cityComboBox.getSelectionModel().getSelectedItem())
					&& originalMapName.equals(mapNameText.getText()))
				item.setSelected(true);
			addTourMenu.getItems().add(item);
		}
	}

	/**
	 * used when chosen a city in the city combo box. loads tours and sites
	 * accordingly
	 * 
	 * @param event
	 */
	@FXML
	void citySwitched(ActionEvent event) {
		createNewSiteButton.setVisible(true);
		createNewTourButton.setVisible(true);
		if (originalCityName.equals(cityComboBox.getSelectionModel().getSelectedItem())
				&& originalMapName.equals(mapNameText.getText())) {
			addEditMapText.setText("Edit Map");
			saveButton.setVisible(false);
			nextButton.setVisible(true);
		} else {
			addEditMapText.setText("New Map");
			saveButton.setVisible(true);
			nextButton.setVisible(false);
		}
		for (CityWithToursAndSitesNames city : (ArrayList<CityWithToursAndSitesNames>) array.get(2)) {
			if (city.getCityName().equals(cityComboBox.getSelectionModel().getSelectedItem())) {
				setSitesAndToursForACity(city, null);
				break;
			}
		}
		cityName = cityComboBox.getSelectionModel().getSelectedItem();
	}

	/**
	 * when pressed the back button in the GUI uses inner methods for: returning to
	 * the previous page (employee working area/ home page)
	 * 
	 * @param event
	 */
	@FXML
	void backButtonClicked(ActionEvent event) {
		try {
			(new MapController()).getMapCollectionExit(mapNameText.getText());
		} catch (SQLException e) {
			e.printStackTrace();
		}
		back();
	}

	/**
	 * returns to previous page
	 */
	private void back() {
		if (ChatClient.getMapInfoListener.contains(this))
			ChatClient.getMapInfoListener.remove(ChatClient.getMapInfoListener.size() - 1);
		if (ChatClient.saveNewMapInfoToDBListener.contains(this))
			ChatClient.saveNewMapInfoToDBListener.remove(ChatClient.saveNewMapInfoToDBListener.size() - 1);
		if (ChatClient.saveNewMapListener.contains(this))
			ChatClient.saveNewMapListener.remove(ChatClient.saveNewMapListener.size() - 1);
		if (ChatClient.getMapTourInfoListener.contains(this))
			ChatClient.getMapTourInfoListener.remove(ChatClient.getMapTourInfoListener.size() - 1);
		if (ChatClient.getMapSitesInfoListener.contains(this))
			ChatClient.getMapSitesInfoListener.remove(ChatClient.getMapSitesInfoListener.size() - 1);

		FXMLLoader loader = null;
		Parent root = null;
		loader = new FXMLLoader(getClass().getResource("EmployeeMainAreaInterface.fxml"));
		try {
			root = loader.load();
		} catch (IOException e) {
			e.printStackTrace();
		}

		EmployeeMainAreaBoundry Employee = loader.getController();
		Employee.setEmployeeInfo(userName, permission, ID);
		// Stage window = (Stage) backButton.getScene().getWindow();
		window.setScene(new Scene(root));
		window.show();
		window.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent e) {
				try {
					UserController.logout(ID);
				} catch (SQLException ex) {
					ex.printStackTrace();
				}
			}

		});
	}

	/**
	 * relevant only when editing map when "next" button is clicked in GUI uses
	 * sends message to server to update sites ready for location. when answer
	 * returns goes to confirmation stage in another method.
	 * 
	 * @param event
	 */
	@FXML
	void nextButtonClicked(ActionEvent event) {
		if (mapNameText.getText().contains(" image")) {
			HomepageBoundry.messageWindow(AlertType.INFORMATION, "OOPS", "can not save this map",
					"map name cannot contain the word \"image\"");
		}
		currentPage = ((Node) event.getSource()).getScene();
		window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		ArrayList<String> sitesToAdd = new ArrayList<>();
		ArrayList<String> ToursToAdd = new ArrayList<>();
		for (MenuItem site : addSiteMenu.getItems()) {
			if (((CheckMenuItem) site).isSelected()) {
				sitesToAdd.add(((CheckMenuItem) site).getText());
			}
		}
		for (MenuItem tour : addTourMenu.getItems()) {
			if (((CheckMenuItem) tour).isSelected()) {
				ToursToAdd.add(((CheckMenuItem) tour).getText());
			}
		}

		if (!(mapNameText.getText().equals("") || descriptionText.getText().equals(""))) {
			ChatClient.AddSaveNewMapInfolistener(this);
			MapController.saveMapInfoToDB(mapNameText.getText(), originalMapName, descriptionText.getText(),
					cityComboBox.getSelectionModel().getSelectedItem(), sitesToAdd, ToursToAdd);
		} else
			HomepageBoundry.messageWindow(AlertType.INFORMATION, "", "Pay attention!",
					"Please make sure you entered valid name and description!");

	}

	/**
	 * opens the new site GUI page in order to add another site to a city.
	 * 
	 * @param event
	 */
	@FXML
	void goToAddSite(ActionEvent event) {
		flagSitePlus = 1;
		cityNameCmb = cityComboBox.getSelectionModel().getSelectedItem();
		currentPage = ((Node) event.getSource()).getScene();
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/AddEditSiteInterface.fxml"));
		;
		try {
			Parent root = loader.load();
			AddEditSiteBoundry site = loader.getController();
			site.setSiteInfo("Add site", userName, Integer.parseInt(ID), permission,
					cityComboBox.getSelectionModel().getSelectedItem(), -1, currentPage);
			Stage window = (Stage) currentPage.getWindow();
			window.setScene(new Scene(root));
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("could not load site editor");
		}
	}

	/**
	 * opens the new tour GUI page in order to add another tour to a city.
	 * 
	 * @param event
	 */
	@FXML
	void goToAddTour(ActionEvent event) {
		flagTourPlus = 1;
		cityNameCmbTour = cityComboBox.getSelectionModel().getSelectedItem();
		currentPage = ((Node) event.getSource()).getScene();
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/AddEditTourInterface.fxml"));
		;
		try {
			Parent root = loader.load();
			AddEditTourBoundry tour = loader.getController();
			tour.setEmployeeInfo(userName, permission, ID, currentPage);
			tour.setAddEditTourFromPlus(cityComboBox.getSelectionModel().getSelectedItem());
			window.setScene(new Scene(root));
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("could not load tour editor");
		}
	}

	/**
	 * only when adding a new map. sends data to server will await strong user for
	 * confirmation of the map later on
	 * 
	 * @param event
	 */
	@FXML
	void saveButtonClicked(ActionEvent event) {
		if (mapNameText.getText().contains(" image")) {
			HomepageBoundry.messageWindow(AlertType.INFORMATION, "OOPS", "can not save this map",
					"map name cannot contain the word \"image\"");
		}
		ArrayList<String> sitesToAdd = new ArrayList<>();
		ArrayList<String> ToursToAdd = new ArrayList<>();
		for (MenuItem site : addSiteMenu.getItems()) {
			if (((CheckMenuItem) site).isSelected()) {
				sitesToAdd.add(((CheckMenuItem) site).getText());
			}
		}
		for (MenuItem tour : addTourMenu.getItems()) {
			if (((CheckMenuItem) tour).isSelected()) {
				ToursToAdd.add(((CheckMenuItem) tour).getText());
			}
		}
		if (!(mapNameText.getText().equals("") || descriptionText.getText().equals(""))) {
			ChatClient.AddSaveNewMaplistener(this);
			MapController.insertNewMap(mapNameText.getText(), descriptionText.getText(),
					cityComboBox.getSelectionModel().getSelectedItem(), sitesToAdd, ToursToAdd,
					mapCombo.getSelectionModel().getSelectedItem());
			this.event = event;

		} else
			HomepageBoundry.messageWindow(AlertType.INFORMATION, "", "Pay attention!",
					"Please make sure you entered valid name and description!");
	}

	/**
	 * moves to sites location page in the GUI if data recieved well in server
	 */
	@Override
	public void nextConfirmation(String respond) {
		
		if (respond.equals("info inserted in DB")) {
			HomepageBoundry.messageWindow(AlertType.INFORMATION, "success", "info inserted in DB successfuly",
					"now edit sites locations on map");
			// load site locations page
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/MapsInterface.fxml"));
			;
			Parent root = null;
			try {
				
					Platform.runLater(() -> 
					{
						if (ChatClient.saveNewMapInfoToDBListener.contains(this))
							ChatClient.saveNewMapInfoToDBListener
									.remove(ChatClient.saveNewMapInfoToDBListener.size() - 1);
					});
				
				
				root = loader.load();
				MapsBoundry mpb = loader.getController();
				mpb.setMapInfoForContent(currentPage, userName, permission, ID, cityName, mapNameText.getText(),
						originalMapName);
				window.setScene(new Scene(root));
				window.show();
			} catch (IOException e) {
				e.printStackTrace();
				System.out.println("could not load site location editor");
			}
			window.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
				public void handle(WindowEvent e) {
					try {
						UserController.logout(ID);
					} catch (SQLException ex) {
						ex.printStackTrace();
					}
					try {
						MapController.getMapCollectionExit(new String(originalMapName));
					} catch (SQLException e2) {
						e2.printStackTrace();
					}
				}
			});

		}

	}

	/**
	 * reply and going back to main page when message is recieved from server
	 */
	@Override
	public void saveNewConfirmation(String respond) {
		Platform.runLater(() -> {

			if (respond.equals("new map awaiting picture from outside source")) {
				HomepageBoundry.messageWindow(AlertType.INFORMATION, "success", "inserted in DB successfuly",
						"new map awaiting picture from outside source");
			} else if (respond.equals("map already exists")) {
				HomepageBoundry.messageWindow(AlertType.INFORMATION, "Failed", "map name already exists",
						"change map name");
				xMapNameSymbol.setVisible(true);
			}
			backButtonClicked(event);
			window.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
				public void handle(WindowEvent e) {
					try {
						UserController.logout(ID);
					} catch (SQLException ex) {
						ex.printStackTrace();
					}
				}
			});
		});
	}

	/**
	 * for adding map image
	 */
	@Override
	public void someoneAskedForMapName(ArrayList<Object> mapsArray) {
		for (int i = 0; i < mapsArray.size(); i++) {
			if ((boolean) ((String) mapsArray.get(i)).contains(" image"))
				mapCombo.getItems().add((String) mapsArray.get(i));
		}
	}

	/**
	 * refresh combobox of sites
	 * 
	 * @param event
	 */
	@FXML
	void clkrefreshcmbSite(MouseEvent event) {
		if (flagSitePlus == 1) {
			if (cityComboBox.getSelectionModel().getSelectedItem().equals(cityNameCmb)) {
				flagSitePlus = 0;
				addSiteMenu.getItems().removeAll(addSiteMenu.getItems());
				ChatClient.AddgetMapSitesInfo(this);
				MapController.getsitesNames(cityNameCmb);
			}
		}

	}
	
	/**
	 * refresh combobox of tours
	 * 
	 * @param event
	 */
	@FXML
	void clkrefreshcmbTour(MouseEvent event) {
		if (flagTourPlus == 1) {
			if (cityComboBox.getSelectionModel().getSelectedItem().equals(cityNameCmbTour)) {
				flagTourPlus = 0;
				addTourMenu.getItems().removeAll(addTourMenu.getItems());
				ChatClient.AddgetMapTourtsInfo(this);
				MapController.getToursNames(cityNameCmbTour);
			}
		}
	}

	/**
	 * setting sites checked/unchecked 
	 */
	public void getMapSiteDetails(ArrayList<Object> rs) {
		CheckMenuItem item;
		// add all sites in map to site menu button
		for (int i = 0; i < rs.size(); i++) {
			item = new CheckMenuItem((String) rs.get(i));
			if (originalCityName.equals(cityComboBox.getSelectionModel().getSelectedItem())
					&& originalMapName.equals(mapNameText.getText()))
				item.setSelected(true);
			System.out.println("filling like crqsy!@@#$");
			addSiteMenu.getItems().add(item);

		}
	}

	/**
	 * setting tours checked/unchecked 
	 */
	public void getMapTourDetails(ArrayList<Object> result) {
		CheckMenuItem item;
		// add all sites in map to site menu button
		for (int i = 0; i < result.size(); i++) {
			item = new CheckMenuItem((String) result.get(i));
			if (originalCityName.equals(cityComboBox.getSelectionModel().getSelectedItem())
					&& originalMapName.equals(mapNameText.getText()))
				item.setSelected(true);
			addTourMenu.getItems().add(item);

		}
	};

	/**
	 * in case existed before finished editing
	 * relevant only after coming back from site location editing
	 */
	public void removeUpdate() {
		MapController.removeUpdate(mapNameText.getText());
	}

}
