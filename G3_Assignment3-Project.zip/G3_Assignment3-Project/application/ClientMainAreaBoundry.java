
package application;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import Controllers.PurchaseController;
import Controllers.UserController;
import client.ChatClient;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;


/**
 * this boundary is the area that collects all the actions that the client is capable of performing.
 * the user getting to this page from the log-in page, after successful log in action.
 * @author maor asis
 *
 */
public class ClientMainAreaBoundry extends ServerEvent {

	@FXML
	private Label Title;

	@FXML
	private Button LogOutButton;

	@FXML
	private Button CityCAtalogButton;

	@FXML
	private Button UpdatePaymentBtn;

	@FXML
	private Button ClientCard;

	@FXML
	private Button updateversion;

	@FXML
	private Button MessageButton;

	@FXML
	private ListView<String> ClientMessages = new ListView<String>();

	ObservableList<String> Messages = FXCollections.observableArrayList();

	private String id;

	private String ClientName = "";

	private String Permission;

	private ActionEvent event;

	private static boolean isNoted = false;

	private static int NewMessages = 0;

	private Parent root = null;

	private ArrayList<String> info = new ArrayList<String>();

	private ArrayList<String> ExpCity = new ArrayList<String>();

	
	@FXML
	void initialize() {
		assert Title != null : "fx:id=\"Title\" was not injected: check your FXML file 'ClientMainAreaInterface.fxml'.";
		assert LogOutButton != null : "fx:id=\"LogOutButton\" was not injected: check your FXML file 'ClientMainAreaInterface.fxml'.";
		assert CityCAtalogButton != null : "fx:id=\"CityCAtalogButton\" was not injected: check your FXML file 'ClientMainAreaInterface.fxml'.";
		assert UpdatePaymentBtn != null : "fx:id=\"UpdatePaymentBtn\" was not injected: check your FXML file 'ClientMainAreaInterface.fxml'.";
		assert ClientCard != null : "fx:id=\"ClientCard\" was not injected: check your FXML file 'ClientMainAreaInterface.fxml'.";
		assert ClientMessages != null : "fx:id=\"ClientMessages\" was not injected: check your FXML file 'ClientMainAreaInterface.fxml'.";
		assert MessageButton != null : "fx:id=\"MessageButton\" was not injected: check your FXML file 'ClientMainAreaInterface.fxml'.";

		MessageButton.setVisible(false);
		if (ChatClient.Loginlisteners.contains(this))
			ChatClient.Loginlisteners.remove(ChatClient.Loginlisteners.size() - 1);
	}

	/**
	 * this methods sends the client to the designated boundary is wishing to move to.
	 * @param page: getting from the the function how called this methods, contains the wanted page to turn to.
	 * @throws IOException
	 */
	public void Loadpage(String page) throws IOException {

		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/" + page + "Interface.fxml"));
		root = loader.load();
		try {
			switch (page) {
			case "registration":
				RegistrationBoundry registration = loader.getController();
				registration.setPersonalUpdateInfo("ClientMainAreaBoundry", info.get(0), info.get(1), info.get(2));
				break;
			case "CityCatalog":
				CityCatalogBoundry citycatalog = loader.getController();
				citycatalog.setClientInfo(info.get(0), info.get(1), info.get(2), ExpCity);
				break;
			case "ClientCard":
				ClientCardBoundry Client = loader.getController();
				Client.setClientInfo(info.get(0), info.get(1), info.get(2));
				Client.getClientCardInfo();
				break;
			case "PurchaseSubscription":
				PurchaseSubscriptionBoundry payment = loader.getController();
				payment.setUserInfo(info.get(0), info.get(1), info.get(2),this.ExpCity);
				payment.setPageInfo("ClientMainArea");
				break;
			}
			info.removeAll(info);
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(new Scene(root));
			window.show();
			window.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
				public void handle(WindowEvent e) {
					try {
						UserController.logout(id);
					} catch (SQLException ex) {ex.printStackTrace();}
				}
			});
		} catch (Exception e) {e.printStackTrace();}
	}

	
	/**
	 * take the clients to the city catalog page.
	 * and loads the page in the manner he/she should see it.
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void ClickbtnCityCatalog(ActionEvent event) throws IOException {
		this.event = event;
		info.add(ClientName);
		info.add(Permission);
		info.add(id);
		Loadpage("CityCatalog");
	}

	/**
	 * methods that logs out the client and sends it to the Home page.
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void ClickbtnLoggOut(ActionEvent event) throws IOException {
		this.event = event;
		HomepageBoundry control = new HomepageBoundry();
		control.ClickBtnHomePage(event);
		try {
			UserController.logout(id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	
	/**
	 * takes the client to the client card boundary.
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void ClickbtnClientCard(ActionEvent event) throws IOException {
		this.event = event;
		info.add(ClientName);
		info.add(Permission);
		info.add(id);
		Loadpage("ClientCard");
	}

	
	/**
	 * this methods been active when ever the client wishes to load the 'client main area'.
	 * @param name; the client's user name.
	 * @param permission: 'client'
	 * @param id: the client's id.
	 */
	public void setClientInfo(String name, String permission, String id) {
		this.id = id;
		ClientName = name;
		Permission = permission;
		Title.setText("Welcome to GCM: " + " " + name);
		if (isNoted == false) {
			isNoted = true;
			ChatClient.AddExpListener(this);
			PurchaseController.CheckForExpiringSubscription(this.id);
		}
		try {
			ChatClient.addMessageslisner(this);
			UserController.getClientMessages(this.id);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * the different between this function and 'setClientInfo' is that if the client renewal
	 * any expiring subscription, the new list of expiring cites been updated in this boundary.
	 * @param name; the client's user name.
	 * @param permission: 'client'
	 * @param id: the client's id.
	 * @param exp: list of cities names that expired.
	 */
	public void setClientInfoFromCityCatalog(String name, String permission, String id, ArrayList<String> exp) {
		this.id = id;
		ClientName = name;
		Permission = permission;
		this.ExpCity = exp;
		Title.setText("Welcome to GCM: " + " " + name);
		try {
			ChatClient.addMessageslisner(this);
			UserController.getClientMessages(this.id);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void SetClientMessagesList(ArrayList<Object> respond) {

		if (NewMessages != respond.size() && respond.size()>1) {
			MessageButton.setVisible(true);
			NewMessages = respond.size();
		} else
			MessageButton.setVisible(false);
		Messages.removeAll(Messages);
		for (int i = 1; i < respond.size(); i++)
			Messages.add((i) + ".) " + (String) respond.get(respond.size() - i));
		ClientMessages.setItems(Messages);
	}

	/**
	 * takes the client to the boundary that allowed the user to change his payment methods details.
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void UpdatePaymentMethod(ActionEvent event) throws IOException {
		this.event = event;
		info.add(id);
		info.add(ClientName);
		info.add(Permission);
		Loadpage("PurchaseSubscription");
	}

	public void presentexpSubscriptions(ArrayList<Object> exCity) {
		if (exCity.size() > 1) {
			exCity.remove(0);
			String citylist = "";
			for (Object collection : exCity) {
				citylist += (String) collection + ",";
				ExpCity.add((String) collection);//// take this to city catalog and if client buys it give his discount
													//// and update renewal.
			}
			HomepageBoundry.messageWindow(AlertType.INFORMATION, "Please pay attention....",
					"The next map collection subscriptions are about to expire!! ..." + citylist + "'",
					"you can renewal your subscription with 10% discount at the city catalog");
		}
	}

	/**
	 * take the client to an area where he can update his personal details.
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void UpdatePersonalInfo(ActionEvent event) throws IOException {
		this.event = event;
		info.add(id);
		info.add(ClientName);
		info.add(Permission);
		Loadpage("registration");
	}

}
