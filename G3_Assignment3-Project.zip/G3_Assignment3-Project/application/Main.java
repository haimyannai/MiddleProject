package application;
import java.io.IOException;
import java.net.URL;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Main extends Application {
	
	public static Stage mainStage;
	
	@Override
	public void start(Stage primaryStage) throws IOException {
		// constructing our scene
		mainStage = primaryStage;
		URL url = getClass().getResource("HomePageInterface.fxml");
		Parent pane = FXMLLoader.load( url );
		Scene scene = new Scene( pane );
		//setting the stage
		primaryStage.setScene( scene );
		primaryStage.setTitle( "Welcome to JavaFX" );
		primaryStage.show();
	
	}
	public static void main(String[] args) {
	launch(args);
			
	}
}
