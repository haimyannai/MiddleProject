package application;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.imageio.ImageIO;

import Controllers.CityController;
import Controllers.ManagerController;
import Controllers.MapController;
import Controllers.PurchaseController;
import Controllers.UserController;
import client.ChatClient;
import entities.CityCatalogRespond;
import entities.mapCollectionImg;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * this class presents the boundary of the city catalog and all the clients
 * interface regarding the actions of purchasing,searching and observing maps
 * the collection included.
 * 
 * @author maor asis
 *
 */
public class CityCatalogBoundry extends ServerEvent {

	@FXML
	private Button Homebtn;

	@FXML
	private TextField CitySearchBox;

	@FXML
	private TextField TourSearchBox;

	@FXML
	private TextField SiteSearchBox;

	@FXML
	private Button Searchbtn;

	@FXML
	private Button Backbtn;

	@FXML
	private Button SetPricebutton;

	@FXML
	private TextField NewPriceTXET;

	@FXML
	private Label setnewpriceLabel;

	@FXML
	private TableView<CityCatalogRespond> CityCatalogTable = new TableView<>();

	@FXML
	private TableColumn<CityCatalogRespond, String> NameCol;

	@FXML
	private TableColumn<CityCatalogRespond, String> MapsCol;

	@FXML
	private TableColumn<CityCatalogRespond, String> ViewsCol;

	@FXML
	private TableColumn<CityCatalogRespond, String> TourCol;

	@FXML
	private TableColumn<CityCatalogRespond, String> SitsCol;

	@FXML
	private TableColumn<CityCatalogRespond, String> VersionCol;

	@FXML
	private TableColumn<CityCatalogRespond, String> PriceCol;

	@FXML
	private TextArea descriptionBox;

	@FXML
	private Button OneTimeBuybtn;

	@FXML
	private Button ButSubscriptionbtn;

	@FXML
	private MenuButton SubscriptionLength;

	@FXML
	private Button RefreshButton;

	private ActionEvent event;

	private Parent root = null;

	private String id = "";

	private String Username = "";

	private String Permission = "";

	Optional<ButtonType> option = null;

	private ArrayList<String> info = new ArrayList<String>();

	private ArrayList<String> NewExpSub = new ArrayList<String>();

	ObservableList<CityCatalogRespond> list = FXCollections.observableArrayList();

	ObservableList<CityCatalogRespond> AfterSearch = FXCollections.observableArrayList();

	@FXML
	void initialize() {
		assert Homebtn != null : "fx:id=\"Homebtn\" was not injected: check your FXML file 'CityCatalogInterface.fxml'.";
		assert CitySearchBox != null : "fx:id=\"CitySearchBox\" was not injected: check your FXML file 'CityCatalogInterface.fxml'.";
		assert TourSearchBox != null : "fx:id=\"TourSearchBox\" was not injected: check your FXML file 'CityCatalogInterface.fxml'.";
		assert SiteSearchBox != null : "fx:id=\"SiteSearchBox\" was not injected: check your FXML file 'CityCatalogInterface.fxml'.";
		assert Searchbtn != null : "fx:id=\"Searchbtn\" was not injected: check your FXML file 'CityCatalogInterface.fxml'.";
		assert Backbtn != null : "fx:id=\"Backbtn\" was not injected: check your FXML file 'CityCatalogInterface.fxml'.";
		assert SetPricebutton != null : "fx:id=\"SetPricebutton\" was not injected: check your FXML file 'CityCatalogInterface.fxml'.";
		assert NewPriceTXET != null : "fx:id=\"NewPriceTXET\" was not injected: check your FXML file 'CityCatalogInterface.fxml'.";
		assert setnewpriceLabel != null : "fx:id=\"setnewpriceLabel\" was not injected: check your FXML file 'CityCatalogInterface.fxml'.";
		assert CityCatalogTable != null : "fx:id=\"CityCatalogTable\" was not injected: check your FXML file 'CityCatalogInterface.fxml'.";
		assert NameCol != null : "fx:id=\"NameCol\" was not injected: check your FXML file 'CityCatalogInterface.fxml'.";
		assert MapsCol != null : "fx:id=\"MapsCol\" was not injected: check your FXML file 'CityCatalogInterface.fxml'.";
		assert ViewsCol != null : "fx:id=\"ViewsCol\" was not injected: check your FXML file 'CityCatalogInterface.fxml'.";
		assert TourCol != null : "fx:id=\"TourCol\" was not injected: check your FXML file 'CityCatalogInterface.fxml'.";
		assert SitsCol != null : "fx:id=\"SitsCol\" was not injected: check your FXML file 'CityCatalogInterface.fxml'.";
		assert VersionCol != null : "fx:id=\"VersionCol\" was not injected: check your FXML file 'CityCatalogInterface.fxml'.";
		assert PriceCol != null : "fx:id=\"PriceCol\" was not injected: check your FXML file 'CityCatalogInterface.fxml'.";
		assert descriptionBox != null : "fx:id=\"descriptionBox\" was not injected: check your FXML file 'CityCatalogInterface.fxml'.";
		assert OneTimeBuybtn != null : "fx:id=\"OneTimeBuybtn\" was not injected: check your FXML file 'CityCatalogInterface.fxml'.";
		assert ButSubscriptionbtn != null : "fx:id=\"ButSubscriptionbtn\" was not injected: check your FXML file 'CityCatalogInterface.fxml'.";
		assert RefreshButton != null : "fx:id=\"RefreshButton\" was not injected: check your FXML file 'CityCatalogInterface.fxml'.";

		NameCol.setCellValueFactory(new PropertyValueFactory<CityCatalogRespond, String>("name"));
		MapsCol.setCellValueFactory(new PropertyValueFactory<CityCatalogRespond, String>("maps"));
		ViewsCol.setCellValueFactory(new PropertyValueFactory<CityCatalogRespond, String>("views"));
		TourCol.setCellValueFactory(new PropertyValueFactory<CityCatalogRespond, String>("tours"));
		SitsCol.setCellValueFactory(new PropertyValueFactory<CityCatalogRespond, String>("sits"));
		VersionCol.setCellValueFactory(new PropertyValueFactory<CityCatalogRespond, String>("version"));
		PriceCol.setCellValueFactory(new PropertyValueFactory<CityCatalogRespond, String>("price"));

		for (int i = 1; i < 7; i++) {
			CheckMenuItem item = new CheckMenuItem(i + " month");
			item.setSelected(false);
			SubscriptionLength.getItems().add(item);
		}
		try {
			CityCatalogTable.getSelectionModel().selectedIndexProperty().addListener(new rowSelectListener());
		} catch (Exception e) {
			e.printStackTrace();
		}
		UploadCityList();
	}

	/**
	 * sets the details to rows in the table of search results
	 * 
	 * @author maor asis
	 */
	private class rowSelectListener implements ChangeListener {
		public void changed(ObservableValue arg0, Object arg1, Object arg2) {
			CityCatalogRespond temp = CityCatalogTable.getSelectionModel().getSelectedItem();
		}
	}

	/**
	 * this methods allowed the user to move to other boundary while passing
	 * information with it.
	 * 
	 * @param page: this string describes the wanted page to move to. while exiting
	 * the system remove the user from all listeners lists.
	 * @throws IOException
	 */
	public void Loadpage(String page) throws IOException {

		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/" + page + "Interface.fxml"));
		root = loader.load();
		try {
			switch (page) {
			case "ClientMainArea":
				ClientMainAreaBoundry ClientMainArea = loader.getController();
				ClientMainArea.setClientInfoFromCityCatalog(info.get(0), info.get(1), info.get(2), NewExpSub);
				break;
			case "PurchaseSubscription":
				PurchaseSubscriptionBoundry payment = loader.getController();
				payment.setUserInfo(info.get(0), info.get(1), info.get(2),this.NewExpSub);
				payment.setPageInfo("CityCatalog");
				break;
			case "EmployeeMainArea":
				EmployeeMainAreaBoundry employee = loader.getController();
				employee.setEmployeeInfo(info.get(0), info.get(1), info.get(2));
				break;
			}
			if (ChatClient.Cataloglisteners.contains(this))
				ChatClient.Cataloglisteners.remove(ChatClient.Cataloglisteners.size() - 1);
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(new Scene(root));
			window.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
				public void handle(WindowEvent e) {
					try {
						UserController.logout(id);
					} catch (SQLException ex) {
						ex.printStackTrace();
					}
				}
			});
			info.removeAll(info);
			if (ChatClient.CatalogAfterSearchlistener.contains(this))
				ChatClient.CatalogAfterSearchlistener.remove(ChatClient.CatalogAfterSearchlistener.size() - 1);
			if (ChatClient.Cataloglisteners.contains(this))
				ChatClient.Cataloglisteners.remove(ChatClient.Cataloglisteners.size() - 1);
			if (ChatClient.SetNewPricelistener.contains(this))
				ChatClient.SetNewPricelistener.remove(ChatClient.SetNewPricelistener.size() - 1);
			if (ChatClient.Purchaselistener.contains(this))
				ChatClient.Purchaselistener.remove(ChatClient.Purchaselistener.size() - 1);
			if (ChatClient.clientGetImagesCollectionListener.contains(this))
				ChatClient.clientGetImagesCollectionListener
						.remove(ChatClient.clientGetImagesCollectionListener.size() - 1);
			if (ChatClient.RenewalListener.contains(this))
				ChatClient.RenewalListener.remove(ChatClient.RenewalListener.size() - 1);
			window.show();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * returns the user to the last boundary he came from with data that describes
	 * him.
	 * 
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void ClickBackbtn(ActionEvent event) throws IOException {
		this.event = event;
		info.removeAll(info);
		info.add(Username);
		info.add(Permission);
		info.add(id);

		switch (Permission) {
		case "guest":
			Loadpage("HomePage");
			break;
		case "client":
			Loadpage("ClientMainArea");
			break;
		default:
			Loadpage("EmployeeMainArea");
		}
	}

	/**
	 * sends the user to his/hers main area.
	 * 
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void ClickbtnHome(ActionEvent event) throws IOException {
		ClickBackbtn(event);
	}

	/**
	 * methods that sends all the search values to the DB, when the user presses the
	 * search button.
	 * 
	 * @param event
	 */
	@FXML
	void clickSearchbtn(ActionEvent event) {
		info.removeAll(info);
		info.add(CitySearchBox.getText());
		info.add(TourSearchBox.getText());
		info.add(SiteSearchBox.getText());
		try {
			ChatClient.CatalogAfterSearchlistener.add(this);
			CityController.getCityCatalogAfterSearch(info);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * methods that gets the updated values from DB to the City Catalog tableview.
	 * 
	 * @param event
	 */
	@FXML
	void ReloadOriginalList(ActionEvent event) {
		UploadCityList();
	}

	/**
	 * presents the description of the specifics catalog the user presses on. when
	 * the user presses any collection the amount of views for this collection goes
	 * up.
	 * 
	 * @param event
	 */
	@FXML
	void displayDescription(MouseEvent event) {
		descriptionBox.selectPositionCaret(descriptionBox.getLength());
		descriptionBox.deselect();
		CityCatalogRespond CatalogItem = CityCatalogTable.getSelectionModel().getSelectedItem();
		if (CatalogItem != null) {
			descriptionBox.setText(CatalogItem.getDescription());
			try {
				CityController.UpdateColectionViews(CatalogItem.getName());
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * methods that gets the city catalog from the DB.
	 */
	public void UploadCityList() {
		try {
			ChatClient.addCatalogListener(this);
			CityController.getCityCatalogDetails();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * this method sets the user info and hides some of the features he/she should
	 * not see.
	 * 
	 * @param name: user's user name
	 * @param premission: user's position in the company
	 * @param id: user's id
	 * @param expSub: specify the expired subscriptions.
	 */
	public void setClientInfo(String name, String premission, String id, ArrayList<String> expSub) {
		this.NewExpSub = expSub;
		Username = name;
		Permission = premission;
		this.id = id;
		if (Permission.equals("guest")) {
			OneTimeBuybtn.setVisible(false);
			OneTimeBuybtn.disabledProperty();
			ButSubscriptionbtn.setVisible(false);
			ButSubscriptionbtn.disabledProperty();
			SubscriptionLength.setVisible(false);
			SubscriptionLength.disabledProperty();
		}
		if (Permission.equals("guest") || Permission.equals("client")) {
			this.NewExpSub = expSub;
			SetPricebutton.setVisible(false);
			SetPricebutton.disabledProperty();
			NewPriceTXET.setVisible(false);
			NewPriceTXET.disabledProperty();
			setnewpriceLabel.setVisible(false);
			setnewpriceLabel.disabledProperty();
		}
		if (Permission.equals("employee") || Permission.equals("content employee")
				|| Permission.equals("company manager")) {
			SetPricebutton.setVisible(false);
			SetPricebutton.disableProperty();
			NewPriceTXET.setVisible(false);
			NewPriceTXET.disabledProperty();
			setnewpriceLabel.setVisible(false);
			setnewpriceLabel.disabledProperty();
		}

	}

	/**
	 * this methods allowed the user with the permission 'content manager' to sends
	 * a request to change the price of the collection. this methods throws an
	 * exception when ever the content manager does not enter valid integer, then
	 * catch the exception and present a proper message.
	 * 
	 * @param event
	 */
	@FXML
	void SetNewCollectionPricerequest(ActionEvent event) {
		this.event = event;
		CityCatalogRespond CatalogItem = CityCatalogTable.getSelectionModel().getSelectedItem();
		if (CatalogItem != null) {
			try {
				Integer.valueOf(NewPriceTXET.getText());
				ChatClient.AddSetNewPricelistener(this);
				ManagerController.SetNewPriceChangeRequest(CatalogItem.getCattalodID(), NewPriceTXET.getText(),
						this.Username);
			} catch (Exception e) {
				HomepageBoundry.messageWindow(AlertType.ERROR, "Error!!", "Couldn't commit this action",
						"Please enter a valid price number");
			}
		} else {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error!!", "Couldn't commit this action",
					"Please first select a collection");
		}
	}

	// explained in the class: 'ServerEvent'
	@Override
	public void setCityCatalog(ArrayList<CityCatalogRespond> DBCatalog) {
		list.removeAll(list);
		for (CityCatalogRespond city : DBCatalog) {
			if (!city.getMaps().equals("0"))
				list.add(city);
		}
		CityCatalogTable.setItems(list);
	}

	/**
	 * this methods checks if the user already owns a subscription for this city, if
	 * it does and the subscription doesn't included in the expiration subscription
	 * list ('NewExpSub'), it allowed the user to sends the purchase request to the
	 * server.
	 * 
	 * @param event
	 */
	@FXML
	void clickOneTimePurchasebtn(ActionEvent event) {
		this.event = event;
		CityCatalogRespond CatalogItem = CityCatalogTable.getSelectionModel().getSelectedItem();
		if (CatalogItem == null) {
			HomepageBoundry.messageWindow(AlertType.ERROR, " Error in One Time Purchases",
					"please choose collection before you want to buy", "Try again");
		}
		if (CatalogItem != null && !(NewExpSub.contains(CatalogItem.getName()))) {
			Optional<ButtonType> option = HomepageBoundry.messageWindow(AlertType.CONFIRMATION, "One Time Purchases",
					"Are you sure you wish to buy " + CatalogItem.getName() + "'s Maps collection?",
					"If you are please press 'ok'");
			if (option.get() == ButtonType.OK) {
				ChatClient.addPurchaselistener(this);
				PurchaseController.setOneTimePurchaseRecord(CatalogItem.getCattalodID(), this.id);
			}
		} else if (CatalogItem != null && NewExpSub.contains(CatalogItem.getName()))
			HomepageBoundry.messageWindow(AlertType.INFORMATION, "Please pay attention",
					"You allready own an active subscription to this collection!!!",
					"You were not charged for this purchase");
	}

	@Override
	public void setOneTimePurchaseRespond(String Respond) {
		Platform.runLater(() -> {

			CityCatalogRespond CatalogItem = CityCatalogTable.getSelectionModel().getSelectedItem();
			if (Respond.equals("success")) {
				HomepageBoundry.messageWindow(AlertType.INFORMATION, "Success",
						this.Username + ", Your purchase has been completed!!", "Now you can enjoy YOUR maps");
				// adding the client to getimage listener
				ChatClient.addclientGetImagesCollection(this);
				try {
					MapController.getMapCollectionForClient(CatalogItem.getCattalodID());
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (Respond.equals("SubscriptionStillActive")) {
				HomepageBoundry.messageWindow(AlertType.INFORMATION, "Pay attention!",
						this.Username + ", You have an active subscription!!",
						"You were not charge for this action, the maps been download to your subscription");
				try {
					ChatClient.addclientGetImagesCollection(this);
					MapController.getMapCollectionForClient(CatalogItem.getCattalodID());
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (Respond.equals("Nopaymentmethodsfound")) {
				Optional<ButtonType> option = HomepageBoundry.messageWindow(AlertType.CONFIRMATION, "OOps...",
						"You haven't Registerd yours payment method",
						"Would you like to to submmit  your payment method now?");
				if (option.get() == ButtonType.OK) {
					this.option = option;
					info.add(id);
					info.add(Username);
					info.add(Permission);
					try {
						Loadpage("PurchaseSubscription");
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			if (Respond.equals("Paymentmethodisexpired"))
				HomepageBoundry.messageWindow(AlertType.ERROR, "OOps...", "You payment method is expired!!",
						"Please update your card detail");
		});
	}

	/**
	 * this an assisting-method that checks if the client selected only one
	 * subscription length, it returns the the string in case it is single, else it
	 * returns "NotOne".
	 * 
	 * @param SubscriptionLength: the MenuButton subscription length.
	 * @return a string with the answer.
	 */
	public String SubscriptionLength(MenuButton SubscriptionLength) {
		List<String> selectedItems = SubscriptionLength.getItems().stream()
				.filter(item -> CheckMenuItem.class.isInstance(item) && CheckMenuItem.class.cast(item).isSelected())
				.map(MenuItem::getText).collect(Collectors.toList());
		if (selectedItems.size() > 1 || selectedItems.size() < 1)
			return "NotOne";
		return selectedItems.get(0);
	}

	/**
	 * this method checks if the user entered valid length, if not present a proper
	 * message, else, allowed the user to purchase the subscription (if it passes
	 * the terms in the server) with the selected time length. if the user has
	 * active but expiring subscription for this collection it renewal the
	 * subscription.
	 * 
	 * @param event
	 */
	@FXML
	void clickBuySubscription(ActionEvent event) {
		this.event = event;
		String length = SubscriptionLength(SubscriptionLength);
		CityCatalogRespond CatalogItem = CityCatalogTable.getSelectionModel().getSelectedItem();

		if (CatalogItem == null || length.equals("NotOne")) {
			HomepageBoundry.messageWindow(AlertType.ERROR, " Error in subscription Purchases",
					"please choose collection, make sure you picked a SINGLE length to the subscription!", "Try again");
		}
		if (CatalogItem != null && !(length.equals("NotOne"))) {
			Optional<ButtonType> option = HomepageBoundry.messageWindow(AlertType.CONFIRMATION,
					"Subscription Purchases",
					"Are you sure you wish to buy " + CatalogItem.getName() + "'s Maps collection subscription?",
					"If you are please press 'ok");
			if (option.get() == ButtonType.OK) {
				length = length.substring(0, 1);
				ChatClient.addSubscriptionlistener(this);
				if (NewExpSub.contains(CatalogItem.getName())) {
					ChatClient.AddRenewalListener(this);
					PurchaseController.RenewalSubscription(CatalogItem.getCattalodID(), this.id, length);
				} else
					PurchaseController.setSubscriptionRecord(CatalogItem.getCattalodID(), this.id, length);
			}
		}
	}

	public void Renewalmsg(String Renewal) {
		Platform.runLater(() -> {
			CityCatalogRespond CatalogItem = CityCatalogTable.getSelectionModel().getSelectedItem();
			if (Renewal.equals("Renewalworked")) {
				HomepageBoundry.messageWindow(AlertType.INFORMATION, "Renewal message", "The renewal succeeded!!",
						"You have extended the subscription successfully and recive 10% discount, the collection are now on your computer!!");
				NewExpSub.remove(CatalogItem.getName());
				try {
					ChatClient.addclientGetImagesCollection(this);
					MapController.getMapCollectionForClient(CatalogItem.getCattalodID());
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} else
				HomepageBoundry.messageWindow(AlertType.ERROR, "", "Error ", "Could not Renewal the subscription!");
			if (ChatClient.RenewalListener.contains(this))
				ChatClient.RenewalListener.remove(ChatClient.RenewalListener.size() - 1);
		});
	}

	public void setSubscriptionRespond(String respond) {
		Platform.runLater(() -> {
			CityCatalogRespond CatalogItem = CityCatalogTable.getSelectionModel().getSelectedItem();
			switch (respond) {
			case "ClientCardInfoNotInTheSystem":
				Optional<ButtonType> option = HomepageBoundry.messageWindow(AlertType.CONFIRMATION, "OOps...",
						"You haven't Registerd yours payment method",
						"Would you like to to submmit  your payment method now?");
				if (option.get() == ButtonType.OK) {
					info.add(id);
					info.add(Username);
					info.add(Permission);
					try {
						Loadpage("PurchaseSubscription");
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				break;
			case "SubscriptionStillActive": {
				HomepageBoundry.messageWindow(AlertType.ERROR, "", "You have already subscribed for this item!!",
						"You were not charged for this purchase, the collection is now send to your computer.");
				ChatClient.addclientGetImagesCollection(this);
				try {
					MapController.getMapCollectionForClient(CatalogItem.getCattalodID());
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
				break;
			case "PurchaseSuccessfully":
				HomepageBoundry.messageWindow(AlertType.INFORMATION, "Success",
						this.Username + ", Your purchase of this subscription has been completed!!",
						"Now you can enjoy YOUR maps, the maps send to the computer.");
				ChatClient.addclientGetImagesCollection(this);
				try {
					MapController.getMapCollectionForClient(CatalogItem.getCattalodID());
				} catch (SQLException e) {e.printStackTrace();}
				break;
			case "Paymentmethodisexpired":
				option = HomepageBoundry.messageWindow(AlertType.CONFIRMATION, "OOps...",
						"You payment method is expired!!", "Would you like to update it now?");
				if (option.get() == ButtonType.OK) {
					info.add(id);
					info.add(Username);
					info.add(Permission);
					try {
						Loadpage("PurchaseSubscription");
					} catch (IOException e) {e.printStackTrace();}
				}
				break;
			default:
				System.out.println("we had a problem");
				break;
			}
			if (ChatClient.Subscriptionlistener.contains(this))
				ChatClient.Subscriptionlistener.remove(ChatClient.Subscriptionlistener.size() - 1);

		});
	}

	@Override
	public void CityListAfterSearch(ArrayList<Object> cityList) {
		Platform.runLater(() -> {
			ArrayList<String> arr = new ArrayList<String>();
			AfterSearch.removeAll(AfterSearch);
			if (cityList.size() > 1) {
				cityList.remove(0);
				for (Object O : cityList)
					arr.add((String) O);
				for (CityCatalogRespond City : list) {
					if (arr.contains(City.getName().toLowerCase())) {
						AfterSearch.add(City);
						System.out.println(City.getName());
					}
				}
			}
			CityCatalogTable.setItems(AfterSearch);
			if (ChatClient.CatalogAfterSearchlistener.contains(this))
				ChatClient.CatalogAfterSearchlistener.remove(ChatClient.CatalogAfterSearchlistener.size() - 1);

		});
	}

	public void returnSetNewPriceResult(boolean result) {
		Platform.runLater(() -> {
			if (result) {
				HomepageBoundry.messageWindow(AlertType.INFORMATION, "", "Success!!",
						"This collection price request has been send to the company manager for confirmation.");
			} else {
				HomepageBoundry.messageWindow(AlertType.ERROR, "Error!!", "Couldn't change the collection price",
						"Please check your input and try again");
			}
			  if (ChatClient.SetNewPricelistener.contains(this))
				  ChatClient.SetNewPricelistener.remove(this);
			
		});
	}

	public void someoneGetMapCollectionCleint(ArrayList<mapCollectionImg> arr) {
		CityCatalogRespond CatalogItem = CityCatalogTable.getSelectionModel().getSelectedItem();
		File file1;

		String file = CatalogItem.getName() + CatalogItem.getVersion();
		boolean success = (new File(file + "\\")).mkdirs();
		if (!success) {
			System.out.println("cannot create new file");
		} else {
			for (int i = 0; i < arr.size(); i++) {
				ByteArrayInputStream bis = new ByteArrayInputStream(arr.get(i).getImg());
				BufferedImage BImage = null;
				try {
					BImage = ImageIO.read(bis);
				} catch (IOException e) {
					e.printStackTrace();
				}
				Image image = SwingFXUtils.toFXImage(BImage, null);
				file1 = new File(file + "\\" + arr.get(i).getMapName() + "_" + arr.get(i).getMapVersion() + ".png");
				try {
					String fileName = file + "\\" + arr.get(i).getMapName() + "_" + arr.get(i).getMapVersion()
							+ "_description.txt";
					PrintWriter outputStream = new PrintWriter(fileName);
					outputStream.println(CatalogItem.getDescription());
					outputStream.flush();
					outputStream.close();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
				BufferedImage bImage = SwingFXUtils.fromFXImage((Image) image, null);
				ByteArrayOutputStream s = new ByteArrayOutputStream();
				try {
					ImageIO.write(bImage, "png", file1);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		}
	}

}
