   package application;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import Controllers.UserController;
import client.ChatClient;
import entities.ClientCardResponse;
import entities.HistoryPurchaseResponse;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
/**
 * this class display the personal and history purcase details 
 */
public class ClientCardBoundry extends ServerEvent {

    ObservableList<HistoryPurchaseResponse> list;
    
    ArrayList<HistoryPurchaseResponse> b = new ArrayList<HistoryPurchaseResponse>();

	@FXML
	private Label NameLabel;

	@FXML
	private Label IDLabel;

	@FXML
	private Label PNLabel;

	@FXML
	private Label SexLabel;

	@FXML
	private Label EmailLable;

	@FXML
	private Label UNLabel;

	@FXML
	private Button BackButton;

    @FXML
    private TableColumn<HistoryPurchaseResponse, String> TC_ID;

    @FXML
    private TableColumn<HistoryPurchaseResponse, String> TC_city;

    @FXML
    private TableColumn<HistoryPurchaseResponse, String> TC_price;

    @FXML
    private TableColumn<HistoryPurchaseResponse, String> TC_version;

    @FXML
    private TableView<HistoryPurchaseResponse> TV_HistoryPurchase;

    private Parent root = null;
    private String ClientName = "empty";
    private String mainID = "",personID="";
    private String user, Permission;

    @FXML
    void initialize() {
   	 assert NameLabel != null : "fx:id=\"NameLabel\" was not injected: check your FXML file 'ClientCardInterface.fxml'.";
   	 assert IDLabel != null : "fx:id=\"IDLabel\" was not injected: check your FXML file 'ClientCardInterface.fxml'.";
   	 assert PNLabel != null : "fx:id=\"PNLabel\" was not injected: check your FXML file 'ClientCardInterface.fxml'.";
   	 assert SexLabel != null : "fx:id=\"SexLabel\" was not injected: check your FXML file 'ClientCardInterface.fxml'.";
   	 assert EmailLable != null : "fx:id=\"EmailLable\" was not injected: check your FXML file 'ClientCardInterface.fxml'.";
   	 assert UNLabel != null : "fx:id=\"UNLabel\" was not injected: check your FXML file 'ClientCardInterface.fxml'.";
   	 assert BackButton != null : "fx:id=\"BackButton\" was not injected: check your FXML file 'ClientCardInterface.fxml'.";
   	 assert TV_HistoryPurchase != null : "fx:id=\"TV_HistoryPurchase\" was not injected: check your FXML file 'ClientCardInterface.fxml'.";
   	 assert TC_ID != null : "fx:id=\"TC_ID\" was not injected: check your FXML file 'ClientCardInterface.fxml'.";
   	 assert TC_city != null : "fx:id=\"TC_city\" was not injected: check your FXML file 'ClientCardInterface.fxml'.";
   	 assert TC_version != null : "fx:id=\"TC_version\" was not injected: check your FXML file 'ClientCardInterface.fxml'.";
   	 assert TC_price != null : "fx:id=\"TC_price\" was not injected: check your FXML file 'ClientCardInterface.fxml'.";

   	 TC_ID.setCellValueFactory(new PropertyValueFactory<HistoryPurchaseResponse, String>("ID"));
   	 TC_version.setCellValueFactory(new PropertyValueFactory<HistoryPurchaseResponse, String>("version"));
   	 TC_price.setCellValueFactory(new PropertyValueFactory<HistoryPurchaseResponse, String>("price"));
   	 TC_city.setCellValueFactory(new PropertyValueFactory<HistoryPurchaseResponse, String>("city"));

   	 try {
   		 TV_HistoryPurchase.getSelectionModel().selectedIndexProperty().addListener(new rowSelectListener());
   	 } catch (Exception e) {
   		 e.printStackTrace();
   	 }
    }

    /** sets the details to rows in the table of search results */
    private class rowSelectListener implements ChangeListener {
   	 public void changed(ObservableValue arg0, Object arg1, Object arg2) {
   		 HistoryPurchaseResponse temp = TV_HistoryPurchase.getSelectionModel().getSelectedItem();

   	 }
    }


    /** 
     * this method return the user to the back page
     * @param event
     * @throws IOException
     */
    @FXML
    void ClickBackButton(ActionEvent event) throws IOException {
   	 switch(Permission) {
   	 case "client":
   		 FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/ClientMainAreaInterface.fxml"));
   		 root = loader.load();
   		 ClientMainAreaBoundry clma = loader.getController();
   		 clma.setClientInfo(this.ClientName, this.Permission, this.mainID);
   		 break;
   	 default:
   		 FXMLLoader loader1 = new FXMLLoader(getClass().getResource("/application/EmployeeMainAreaInterface.fxml"));
   		 root = loader1.load();
   		 EmployeeMainAreaBoundry emma = loader1.getController();
   		 emma.setEmployeeInfo(this.ClientName, this.Permission, this.mainID);
   		 
   	 }
   	 Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
   	 window.setScene(new Scene(root));
   	 window.setOnCloseRequest(new EventHandler<WindowEvent>() {
   	 	@Override
   	 	public void handle(WindowEvent e) {
   			 try {
   				 UserController.logout(mainID);
   			 } catch (SQLException ex) {ex.printStackTrace();}
   	 	}
   	   });
   	 window.show();
    }

    /** 
     * this is a loading method, any page that coming to the clientCard page
     * need to init this values before
     * FOR CLIENT USERES
     * @param name
     * @param Permission
     * @param ID
     */
    public void setClientInfo(String name, String Permission, String ID) {
   	 this.Permission = Permission;
   	 this.ClientName = name;
   	 this.mainID = ID;
    }
    
    /** 
     * this is a loading method, any page that coming to the clientCard page
     * need to init this values before
     * FOR EMPLOYEES USERES
     * @param name
     * @param Permission
     * @param employeeID
     * @param clientID
     */
    public void setEmployeeInfo(String name,String Permission,String employeeID,String clientID) {
   	 this.Permission=Permission;
   	 this.ClientName=name;
   	 this.mainID=employeeID;
   	 this.personID=clientID;
    }

    @Override
    public void someoneGetClientCard(ClientCardResponse clientCardResponse) {
   	 Platform.runLater(() -> {
   		 if (clientCardResponse.getClientCardRes()) {
   			 if (ChatClient.setClientCardinfolisteners.contains(this)) {
   				 NameLabel.setText(clientCardResponse.getName());
   				 IDLabel.setText(clientCardResponse.getID());
   				 PNLabel.setText(clientCardResponse.getPhoneNumber());
   				 SexLabel.setText(clientCardResponse.getSex());
   				 EmailLable.setText(clientCardResponse.getEmail());
   				 UNLabel.setText(clientCardResponse.getUserName());
   				 user = clientCardResponse.getUserName();
   			 }
   		 }
   	 });

    }

    @Override
    public void someoneGetHistoryPurchase(ArrayList<HistoryPurchaseResponse> HPR) {

   	 b.clear();
   	 int i;
   	 for (i = 0; i < HPR.size(); i++) {
   		 if(!HPR.get(i).getCity().equals("")&&!HPR.get(i).getID().equals("")&&!HPR.get(i).getPrice().equals("")&&!HPR.get(i).getVersion().equals(""))
   			 b.add(HPR.get(i));
   	 }
   	 list = FXCollections.observableArrayList(b);
   	 TV_HistoryPurchase.setItems(list);
    }

    /**
     * ask the client info from the server
     */
    public void getClientCardInfo() {
      	 try {
      		 ChatClient.setClientCardinfolisteners.add(this);
      		 if(Permission.equals("company manager")) {
      			 UserController.setClientCardInfo(personID);
      		 }else {
      			 UserController.setClientCardInfo(mainID);
      		 }
      	 } catch (SQLException e) {e.printStackTrace();}
       }


    

}


