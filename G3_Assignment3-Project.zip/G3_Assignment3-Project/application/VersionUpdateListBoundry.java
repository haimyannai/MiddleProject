package application;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.imageio.ImageIO;

import Controllers.ManagerController;
import Controllers.UserController;
import client.ChatClient;
import entities.EditMapRequest;
import entities.UpdateRequest;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;


/** this boundary connects the managers and the request that waits for their decisions.
 * here, the managers can evaluate the different requests and decide on the action to take.
 * @author maor asis
 */
public class VersionUpdateListBoundry extends ServerEvent {

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private Button Homebtn;

	@FXML
	private Button Deniedbtn;

	@FXML
	private Label MainLable;
	
	@FXML
    private Pane paneImageMap;
	
	@FXML
    private ImageView imgEditMap;

	@FXML
	private TableView<UpdateRequest> PriceChangeRequestTable;

	@FXML
	private TableColumn<UpdateRequest, String> DateCol;

	@FXML
	private TableColumn<UpdateRequest, String> MapidCol;

	@FXML
	private TableColumn<UpdateRequest, String> EmployeeCol;

	@FXML
	private TableColumn<UpdateRequest, String> PermossionCol;

	@FXML
	private TableColumn<UpdateRequest, String> DescriptionCol;

	@FXML
	private TableColumn<UpdateRequest, String> amountCol;

	@FXML
	private Button Apply;

	@FXML
	private Button Backbtn;

	@FXML
	private TableView<EditMapRequest> EditMapTable;

	@FXML
	private TableColumn<EditMapRequest, String> MapnameCol;

	@FXML
	private TableColumn<EditMapRequest, String> VersionCol;

	@FXML
	private TableColumn<EditMapRequest, String> DescriptionCol1;

	@FXML
	private Button RefreshButton;

	private Parent root = null;

	private String user, permission;

	private String id = "";

	private ActionEvent event;

	ObservableList<UpdateRequest> companylist = FXCollections.observableArrayList();

	ObservableList<EditMapRequest> contentlist = FXCollections.observableArrayList();

	@FXML
	void initialize() {
		assert Homebtn != null : "fx:id=\"Homebtn\" was not injected: check your FXML file 'VersionUpdateListInterface.fxml'.";
		assert MainLable != null : "fx:id=\"MainLable\" was not injected: check your FXML file 'VersionUpdateListInterface.fxml'.";
		assert PriceChangeRequestTable != null : "fx:id=\"PriceChangeRequestTable\" was not injected: check your FXML file 'VersionUpdateListInterface.fxml'.";
		assert DateCol != null : "fx:id=\"DateCol\" was not injected: check your FXML file 'VersionUpdateListInterface.fxml'.";
		assert MapidCol != null : "fx:id=\"MapidCol\" was not injected: check your FXML file 'VersionUpdateListInterface.fxml'.";
		assert EmployeeCol != null : "fx:id=\"EmployeeCol\" was not injected: check your FXML file 'VersionUpdateListInterface.fxml'.";
		assert PermossionCol != null : "fx:id=\"PermossionCol\" was not injected: check your FXML file 'VersionUpdateListInterface.fxml'.";
		assert DescriptionCol != null : "fx:id=\"DescriptionCol\" was not injected: check your FXML file 'VersionUpdateListInterface.fxml'.";
		assert amountCol != null : "fx:id=\"amountCol\" was not injected: check your FXML file 'VersionUpdateListInterface.fxml'.";
		assert Apply != null : "fx:id=\"Apply\" was not injected: check your FXML file 'VersionUpdateListInterface.fxml'.";
		assert Backbtn != null : "fx:id=\"Backbtn\" was not injected: check your FXML file 'VersionUpdateListInterface.fxml'.";
		assert Deniedbtn != null : "fx:id=\"Deniedbtn\" was not injected: check your FXML file 'VersionUpdateListInterface.fxml'.";
		assert RefreshButton != null : "fx:id=\"RefreshButton\" was not injected: check your FXML file 'VersionUpdateListInterface.fxml'.";
		assert EditMapTable != null : "fx:id=\"EditMapTable\" was not injected: check your FXML file 'VersionUpdateListInterface.fxml'.";
		assert MapnameCol != null : "fx:id=\"MapnameCol\" was not injected: check your FXML file 'VersionUpdateListInterface.fxml'.";
		assert VersionCol != null : "fx:id=\"VersionCol\" was not injected: check your FXML file 'VersionUpdateListInterface.fxml'.";
		assert DescriptionCol1 != null : "fx:id=\"DescriptionCol1\" was not injected: check your FXML file 'VersionUpdateListInterface.fxml'.";

		/** inisilaize the company manager table **/
		DateCol.setCellValueFactory(new PropertyValueFactory<UpdateRequest, String>("date"));
		MapidCol.setCellValueFactory(new PropertyValueFactory<UpdateRequest, String>("collectionID"));
		EmployeeCol.setCellValueFactory(new PropertyValueFactory<UpdateRequest, String>("employee"));
		PermossionCol.setCellValueFactory(new PropertyValueFactory<UpdateRequest, String>("permission"));
		DescriptionCol.setCellValueFactory(new PropertyValueFactory<UpdateRequest, String>("description"));
		amountCol.setCellValueFactory(new PropertyValueFactory<UpdateRequest, String>("amount"));

		/** inisilaize the content manager table **/
		MapnameCol.setCellValueFactory(new PropertyValueFactory<EditMapRequest, String>("mapname"));
		VersionCol.setCellValueFactory(new PropertyValueFactory<EditMapRequest, String>("version"));
		DescriptionCol1.setCellValueFactory(new PropertyValueFactory<EditMapRequest, String>("description"));

		try {
			PriceChangeRequestTable.getSelectionModel().selectedIndexProperty().addListener(new rowSelectListener());
			EditMapTable.getSelectionModel().selectedIndexProperty().addListener(new rowSelectListener());
		} catch (Exception e) {e.printStackTrace();}
	}
	
	
	/**this methods sets the details to rows in the table of search results 
	 * @author maor asis
	 */
	private class rowSelectListener implements ChangeListener {
		public void changed(ObservableValue arg0, Object arg1, Object arg2) {
			UpdateRequest temp = PriceChangeRequestTable.getSelectionModel().getSelectedItem();
			EditMapRequest temp1 = EditMapTable.getSelectionModel().getSelectedItem();
		}
	}

	
	/**
	 * This methods take the user (manager) to the previous page,
	 * while removes him from all listeners lists.
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void GoToPreviousPage(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/EmployeeMainAreaInterface.fxml"));
		root = loader.load();
		EmployeeMainAreaBoundry employee = loader.getController();
		employee.setEmployeeInfo(this.user, this.permission, this.id);
		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene(new Scene(root));
		window.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent e) {
				try {
					UserController.logout(id);
				} catch (SQLException ex) {ex.printStackTrace();}
			}
		});
		if(ChatClient.EditMapRequestListener.contains(this))
			ChatClient.EditMapRequestListener.remove(ChatClient.EditMapRequestListener.size()-1);
		if(ChatClient.SetVersionListlistener.contains(this))
			ChatClient.SetVersionListlistener.remove(ChatClient.SetVersionListlistener.size()-1);
		if(ChatClient.NewMapVersionlisner.contains(this))
			ChatClient.NewMapVersionlisner.remove(ChatClient.NewMapVersionlisner.size()-1);
		window.show();
	}

	
	/**
	 * reloads the table-view with updated data.
	 * for each manager a different controller methods. 
	 * @param event
	 */
	@FXML
	void ReloadList(ActionEvent event) {
		UploadRequestList();
	}

	
	/**
	 * loads the designated table with the proper data.
	 */
	public void UploadRequestList() {
		if (this.permission.equals("company manager")) {
			try {
				ChatClient.AddVersionListlistener(this);
				ManagerController.getVersionUpdateRequestList();
			} catch (Exception e) {e.printStackTrace();}
		} else {
			ChatClient.addEditMapRequestListener(this);
			ManagerController.UploadEditMapRequests();
		}
	}

	
	public void SetCollectionPriceUpdateRequestTable(ArrayList<Object> respond) {
		Platform.runLater(() -> {
				respond.remove(0);
				companylist.removeAll(companylist);
				if (respond.size() >0) {
					for (Object O : respond)
						companylist.add((UpdateRequest) O);
			}
				PriceChangeRequestTable.setItems(companylist);
		});
	}

	
	/**
	 * saved the values of the current user.
	 * then active a methods that get all the requests from the server to the table-view.
	 * @param user: the user's user name
	 * @param permission: the position in the company
	 * @param id: the id of the user
	 */
	public void SetManagerInfo(String user, String permission, String id) {
		this.user = user;
		this.permission = permission;
		this.id = id;
		if (permission.equals("content manager")) {
			PriceChangeRequestTable.setVisible(false);
			PriceChangeRequestTable.disabledProperty();
			MainLable.setText("New Map Version Request List");
		} else {
			EditMapTable.setVisible(false);
			EditMapTable.disabledProperty();
			paneImageMap.setVisible(false);
			paneImageMap.disabledProperty();
			imgEditMap.setVisible(false);
			imgEditMap.disabledProperty();
			MainLable.setText("Change Map Price Request List");
		}
		UploadRequestList();
	}

	
	
	/**
	 * by pressing the approve button this methods active the right methods that approve
	 * this request whether it's in either tables.
	 * @param event
	 */
	@FXML
	void ApproveRequest(ActionEvent event) {
		if (permission.equals("company manager")) {
			UpdateRequest request = PriceChangeRequestTable.getSelectionModel().getSelectedItem();
			if (request != null) {
				try {
					ChatClient.AddSetNewPricelistener(this);
					ManagerController.SetNewCollectionPrice(request.getCollectionID(), request.getAmount());
				} catch (Exception e) {e.printStackTrace();}
			} else
				HomepageBoundry.messageWindow(AlertType.ERROR, "Error Massege", "Error in approval!!",
						"Please select a request before you press 'approve'");
		} else {
			EditMapRequest request = EditMapTable.getSelectionModel().getSelectedItem();
			if (request != null) {
				try {
					ChatClient.addNewMapVersion(this);
					ManagerController.SetNewMapVersion(request.getMapname(), request.getVersion());
				} catch (Exception e) {e.printStackTrace();}
			} else
				HomepageBoundry.messageWindow(AlertType.ERROR, "Error Massege", "Error in selection!!",
						"Please select a request before you press 'approve'");
		}
	}

	
	
	public void SetNewMapUpdateRespond(String respond) {
		if (respond.equals("UpdateWorked")) {
			HomepageBoundry.messageWindow(AlertType.INFORMATION, "Succsses!!",
					"You Succssesfully approve this request!!",
					"The DB have been updated and now clients can purchase this map.");
		} else
			HomepageBoundry.messageWindow(AlertType.ERROR, "Failed!!", "Couldn't update this request!!",
					"Please seek technical suppory!");
		UploadRequestList();
	}

	/**by pressing the 'denied' button this methods reject the selected request and
	 * presents a proper massage.
	 * @param event
	 */
	@FXML
	void DeniedRequests(ActionEvent event) {
		if (permission.equals("company manager")) {
			UpdateRequest request = PriceChangeRequestTable.getSelectionModel().getSelectedItem();
			if (request != null) {
				try {
					ChatClient.AddDeinedListenerr(this);
					ManagerController.setDeniedRequest(request.getId());
				} catch (Exception e) {e.printStackTrace();}
			}
		} else {
			EditMapRequest request = EditMapTable.getSelectionModel().getSelectedItem();
			if (request != null) {
				try {
					ChatClient.addDeniedNewMapVersion(this);
					ManagerController.DeniedMapVersion(request.getMapname(), request.getVersion());
					
				} catch (Exception e) {e.printStackTrace();}
			} else
				HomepageBoundry.messageWindow(AlertType.ERROR, "Error Massege", "Error in selection!!",
						"Please select a request before you press 'approve'");
		}
	}

	
	public void SetDeniedNewMapVersionRespond(boolean respond) {
		if (respond)
			HomepageBoundry.messageWindow(AlertType.CONFIRMATION, "Success!!",
					"You have successfully denied the request",
					"You can refresh the table to watch the remaining requests");
		else
			HomepageBoundry.messageWindow(AlertType.ERROR, "Failed!!", "Couldn't denied this request!!",
					"Please seek technical support!");
		if(ChatClient.DeniedNewMapVersionlisner.contains(this))
			ChatClient.DeniedNewMapVersionlisner.remove(ChatClient.DeniedNewMapVersionlisner.size()-1);
		UploadRequestList();
	}

	
	@Override
	public void returnSetNewPriceResult(boolean result) {
		Platform.runLater(() -> {
			if (result) {
				HomepageBoundry.messageWindow(AlertType.INFORMATION, "Success!!",
						"This collection price has been changed", "You can watch the change in the city catalog");
			} else {
				HomepageBoundry.messageWindow(AlertType.ERROR, "Error!!", "Couldn't change the collection price",
						"Please check your input and try again");
			}
			UploadRequestList();
		});
	}

	
	public void DeinedRequestAnswer(boolean respond) {
		Platform.runLater(() -> {
			if (respond) {
				HomepageBoundry.messageWindow(AlertType.INFORMATION, "Success!!", "Request has been denied!",
						"To remove the request from the list please refresh");
			} else
				HomepageBoundry.messageWindow(AlertType.ERROR, "Faild!!", "Could not reject the request ",
						"Please try again");
			UploadRequestList();
		});
	}

	
	public void setEditMapRequests(ArrayList<Object> result) {
			contentlist.removeAll(contentlist);
			if(result.size()>1) {	
				result.remove(0);
				for (Object request : result) {
					contentlist.add((EditMapRequest) request);
				}
			}
			EditMapTable.setItems(contentlist);
	}
	
	
	/**
	 * when ever the company manager presses any request on the list he get to see
	 * the new map version in the right side of the screen, then gets to decide on the result.
	 * @param event
	 */
	@FXML
    void displayEditedMap(MouseEvent event) {
		EditMapRequest editMapRequest = EditMapTable.getSelectionModel().getSelectedItem();
		if (editMapRequest != null)
			showImgInImageView(editMapRequest.getImg());
    }
	
	
	/**
	 * this methods import the image from the DB and present it when ever the manager presses a request.
	 * @param img: the 'blob' type file from the DB.
	 */
	public void showImgInImageView(byte[] img)
	{
		paneImageMap.getChildren().clear();
		ByteArrayInputStream bis = new ByteArrayInputStream((byte[])img);
		Image imageMap;
		BufferedImage BImage = null;
		try {
			BImage = ImageIO.read(bis);
		} catch (IOException e) {e.printStackTrace();}
		Image image = SwingFXUtils.toFXImage(BImage, null);
		ImageView Img = new ImageView();
		imgEditMap.setImage(image);
		paneImageMap.getChildren().add(imgEditMap);
	}


	
	
	
}