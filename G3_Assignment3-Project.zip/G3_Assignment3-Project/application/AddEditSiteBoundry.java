package application;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Controllers.SiteController;
import Controllers.UserController;
import client.ChatClient;
import entities.SiteInfoForEditResponse;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
/**
 * This class responsible to the window AddEditSite when any kind of content employee and employee with higher 
 * Permission want to Add or Edit site. If want to Add a site,the window is open empty with only the city name
 * that belongs to the site,all the other fields in the window are empty and ready to be fill.
 * If want to Edit site,the window is open already with the suitable details that belong to current site.
 * @author shahar
 * 
 */
public class AddEditSiteBoundry extends ServerEvent {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Label headLinelbl;
    
    @FXML
    private TextField citynameLbl;

    @FXML
    private TextField txtSitename;

    @FXML
    private TextField txtloction;

    @FXML
    private TextField txtType;

    @FXML
    private Button btnBack;

    @FXML
    private CheckBox btnDisab;
    
    private ActionEvent event;

    @FXML
    private Button btnSave;

    @FXML
    private Button btnEdit;

    @FXML
    private TextArea txtDescr;

    private Parent root = null;
    private String username = null;
    private int userid = 0;
    private String permmision = null;
    private String cityname = null;
    private int siteID = 0;
    private Scene prevpag = null;

    @FXML
    void initialize() {
   	 assert headLinelbl != null : "fx:id=\"headLinelbl\" was not injected: check your FXML file 'AddEditSiteInterface.fxml'.";
   	 assert txtSitename != null : "fx:id=\"txtSitename\" was not injected: check your FXML file 'AddEditSiteInterface.fxml'.";
   	 assert txtloction != null : "fx:id=\"txtloction\" was not injected: check your FXML file 'AddEditSiteInterface.fxml'.";
   	 assert txtType != null : "fx:id=\"txtType\" was not injected: check your FXML file 'AddEditSiteInterface.fxml'.";
   	 assert btnBack != null : "fx:id=\"btnBack\" was not injected: check your FXML file 'AddEditSiteInterface.fxml'.";
   	 assert btnSave != null : "fx:id=\"btnSave\" was not injected: check your FXML file 'AddEditSiteInterface.fxml'.";
   	 assert btnEdit != null : "fx:id=\"btnEdit\" was not injected: check your FXML file 'AddEditSiteInterface.fxml'.";
   	 assert txtDescr != null : "fx:id=\"txtDescr\" was not injected: check your FXML file 'AddEditSiteInterface.fxml'.";

    }

    /**
     * The setSiteInfo with all those necessary parameters relevant to all the windows that call this window
     * because that this window has two ways to be open,one for Add site and the other for Edit so this window
     * need to know who's called him,if come to edit,the class adding it self to the list of SiteInfoToWinlisteners
     * and call a method to get the right details to the site.  
     * @param label
     * @param username
     * @param id
     * @param permmision
     * @param cityname
     * @param siteID
     * @param prevpag
     */
    public void setSiteInfo(String label, String username, int id, String permmision, String cityname, int siteID, Scene prevpag) {
   	 headLinelbl.setText(label);
   	 this.username = username;
   	 this.userid = id;
   	 this.permmision = permmision;
   	 this.cityname = cityname;
   	 this.siteID = siteID;
   	 this.prevpag=prevpag;
   	 citynameLbl.setText(cityname);
   	 citynameLbl.setDisable(true);
   	 switch (label) {
   	 case "Edit site":
   		 ChatClient.addSiteInfoToWinlisteners(this);
   		 SiteController.getSiteInfoBackForEdit(cityname, siteID);
   		 btnSave.setVisible(false);
   		 break;
   	 case "Add site":
   		 btnEdit.setVisible(false);
   		 break;
   	 }
    }

    /**
     * When BtnBack is clicked,first if this class exist in one of the listeners list,it removes
     * then he need to know which window called him and according to that returns to right window
     * @param event
     */
    @FXML
    void clickBtnBack(ActionEvent event) {
    	this.event=event;
   	  if (ChatClient.getSiteInfoBackToWinEditlisteners.contains(this)) {
   		  ChatClient.getSiteInfoBackToWinEditlisteners.remove(this);
   	 	}
   	   if (ChatClient.SiteInfoFowardForEditRes.contains(this)) {
   		   ChatClient.SiteInfoFowardForEditRes.remove(this);
   	   }
   	   if (ChatClient.SiteInfoFowardForAddRes.contains(this)) {
   		   ChatClient.SiteInfoFowardForAddRes.remove(this);
   	 	}
   	 try {
   		 if(prevpag == null) {
   			 FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/EmployeeMainAreaInterface.fxml"));
   			 root = loader.load();
   			 EmployeeMainAreaBoundry employeeMainAreaBoundry = loader.getController();
   			 employeeMainAreaBoundry.setEmployeeInfo(username, permmision, String.valueOf(userid));
   			 Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
   		   	 window.setScene(new Scene(root));
   			 window.setOnCloseRequest(new EventHandler<WindowEvent>() {
   				 @Override
   				 public void handle(WindowEvent e) {
   					 try {
   						 UserController.logout(String.valueOf(userid));
   					 } catch (SQLException ex) {
   						 ex.printStackTrace();
   					 }
   				 }
   			 });
   			 window.show();
   		 }
   		 else {
   			 Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
   		   	 window.setScene(prevpag);
   		   	 window.show();
   		 }
   	 } catch (Exception e) {
   	  }
   	 
    }
    
    /**
     * When BtnEdit is clicked,this window is opened with all the last update details of the site then,before clicking ,check if one of the fields are empty,if so pop suitable message
     * then check what the status of the btnDisable and send all the info to the server. 
     
     * @param event
     */
    @FXML
    void clickBtnEdit(ActionEvent event) {
    this.event=event;
   	 String status = "0";
   	 ;
   	 if (txtSitename.getText().equals("") || txtloction.getText().equals("") || txtType.getText().equals("")
   			 || txtDescr.getText().equals("")) {
   		 HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "one or Two of the fields missing",
   				 "please fill this fields");
   	 } else {
   		 if (btnDisab.isSelected()) {
   			 status = "1";
   		 }
   		 if(!txtSitename.getText().contains("'")) {
   		 SiteInfoForEditResponse siteInfoForEditResponse = new SiteInfoForEditResponse(txtSitename.getText(),
   				 txtloction.getText(), txtType.getText(), txtDescr.getText(), status);
   		 ChatClient.addSiteInfoFowardForEditRes(this);
   		 SiteController.setSiteInfoFowardForEdit(siteInfoForEditResponse, siteID);
   		 }
   		 else
   			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "Please pay attention, name cann't include ' .", "Try again!.");
   			 
   	 }

    }

    /**
     * When BtnSave is clicked,this window is opened with the city of this site then check if one of the necessary fields are empty,if so pop suitable message
     * and then send it to server,and last add new site to the relevant city.
     * @param event
     */
    @FXML
    void clickBtnSave(ActionEvent event) {
    	this.event=event;
   	 String status = "0";
   	 if (txtSitename.getText().equals("") || txtloction.getText().equals("") || txtType.getText().equals("")
   			 || txtDescr.getText().equals("")) {
   		 HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "one or Two of the fields missing",
   				 "please fill this fields");
   	 } else {
   		 if (btnDisab.isSelected()) {
   			 status = "1";
   		 }
   		 if(!txtSitename.getText().contains("'")) {
   		 SiteInfoForEditResponse siteInfoForEditResponse = new SiteInfoForEditResponse(txtSitename.getText(),
   				 txtloction.getText(), txtType.getText(), txtDescr.getText(), status);
   		 ChatClient.addSiteInfoFowardForAddRes(this);
   		 SiteController.setSiteInfoFowardForAdd(siteInfoForEditResponse, this.cityname);
   		 }
   		 else
    			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "Please pay attention, name cann't include ' .", "Try again!.");
    			 
   	 }
    }

    @Override
    public void getSiteInfoBackForEdit(ArrayList<SiteInfoForEditResponse> arr) {
   	 // TODO Auto-generated method stub
   	 txtSitename.setText(arr.get(0).getName());
   	 txtloction.setText(arr.get(0).getLocation());
   	 txtType.setText(arr.get(0).getType());
   	 if (arr.get(0).getDisabeled().equals("1")) {
   		 btnDisab.setSelected(true);
   	 }
   	 txtDescr.setText(arr.get(0).getDescription());
    }

    @Override
    public void getSiteInfoBackForEdit(boolean bool) {
    	Platform.runLater(() -> {
   	 if (bool == true) {
   		 HomepageBoundry.messageWindow(AlertType.INFORMATION, "Success", "You have edited the site successfully", "");
   		 clickBtnBack(event);
   	 } else {
   		 HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "something went wrong", "");
   	 }
    	});
    }

    @Override
    public void getSiteInfoFowardForAddRes(boolean bool) {
    	Platform.runLater(() -> {
   	 if (bool == true) {
   		 HomepageBoundry.messageWindow(AlertType.INFORMATION, "Success", "You have add the site successfully", "");
   		clickBtnBack(event);
   	 } else {
   		 HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "something went wrong",
   				 "this site name already exist");
   	 }
    	});
    }
}


