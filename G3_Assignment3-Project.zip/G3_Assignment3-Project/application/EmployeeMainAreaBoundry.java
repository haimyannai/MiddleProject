package application;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import Controllers.ManagerController;
import Controllers.MapController;
import Controllers.UserController;
import client.ChatClient;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * This class is the boundary of the workers work area GUI
 * employees can access the city catalog and view maps
 * content employee can also add/edit cities,maps,sites and tours
 * content employee can also delete all of the above and access version request list and reports
 * company manager can also view clients details
 * @author gilad
 */
public class EmployeeMainAreaBoundry extends ServerEvent {

    @FXML
    private MenuButton MapOptionMB;
    @FXML
    private MenuButton SetOptionMB;
    @FXML
    private MenuButton TourOPtionMB;

    @FXML
    private TextField MapNameTEXT;
    @FXML
    private TextField MapSiteTEXT;
    @FXML
    private TextField MapTourTEXT;
    @FXML
    private TextField MapCtyTEXT;
    @FXML
    private TextField clientIdField;

    @FXML
    private Label positionLabel;
    @FXML
    private Label Title;
    @FXML
    private Label username;
    @FXML
    private Label presentClient;
    
    @FXML
    private Button LoggOutButton;
    @FXML
    private Button CityCatalogButton;
    @FXML
    private Button RequestListButton;
    @FXML
    private Button openClientCardBtn;

    @FXML
    private ImageView x5;

    @FXML
    ObservableList<CheckMenuItem> data;

    @FXML
    private ComboBox<String> reportOptionBtn;
    @FXML
    private ComboBox<String> MapOptionsBtn;
    @FXML
	private ComboBox<String> siteOptionCombo;
    @FXML
    private ComboBox<String> tourOptionsCombo;
    @FXML
	private ComboBox<String> cityOptionCombo;
    @FXML
	private ComboBox<String> chooseMapCombo;
    @FXML
	private ComboBox<String> chooseSiteCombo;
    @FXML
    private ComboBox<String> chooseTourCombo;
    @FXML
    private ComboBox<String> chooseCityCombo;
    @FXML
    private ComboBox<String> choosePersonCombo;
    @FXML
	private ComboBox<String> comboboxSitesCiteisnames;




    private ActionEvent event;
    private Parent root = null;
    private ArrayList<String> info = new ArrayList<String>();
    private ArrayList<ArrayList<Object>> sitesArray = new ArrayList<>();
    private ArrayList<ArrayList<Object>> toursArray = new ArrayList<>();
    private ArrayList<Object> tourOption = new ArrayList<>();
    private String selected = "";
    private String id;
    private String employeeName = "empty";
    private String position;
    private String mapOption,cityOption,siteCity,personOption;
    private int siteId,isDeleted=0;

    /**
     * At initialization, fill the options combo box and set the appropriate visibility of combo boxes in order to create a clear workspace for the workers
     */
    @FXML
    void initialize() {
        assert root != null : "fx:id=\"root\" was not injected: check your FXML file 'EmployeeMainAreaInterface.fxml'.";
        assert MapOptionMB != null : "fx:id=\"MapOptionMB\" was not injected: check your FXML file 'EmployeeMainAreaInterface.fxml'.";
        assert SetOptionMB != null : "fx:id=\"SetOptionMB\" was not injected: check your FXML file 'EmployeeMainAreaInterface.fxml'.";
        assert TourOPtionMB != null : "fx:id=\"TourOPtionMB\" was not injected: check your FXML file 'EmployeeMainAreaInterface.fxml'.";
        assert MapNameTEXT != null : "fx:id=\"MapNameTEXT\" was not injected: check your FXML file 'EmployeeMainAreaInterface.fxml'.";
        assert MapSiteTEXT != null : "fx:id=\"MapSiteTEXT\" was not injected: check your FXML file 'EmployeeMainAreaInterface.fxml'.";
        assert MapTourTEXT != null : "fx:id=\"MapTourTEXT\" was not injected: check your FXML file 'EmployeeMainAreaInterface.fxml'.";
        assert MapCtyTEXT != null : "fx:id=\"MapCtyTEXT\" was not injected: check your FXML file 'EmployeeMainAreaInterface.fxml'.";
        assert Title != null : "fx:id=\"Title\" was not injected: check your FXML file 'EmployeeMainAreaInterface.fxml'.";
        assert LoggOutButton != null : "fx:id=\"LoggOutButton\" was not injected: check your FXML file 'EmployeeMainAreaInterface.fxml'.";
        assert positionLabel != null : "fx:id=\"positionLabel\" was not injected: check your FXML file 'EmployeeMainAreaInterface.fxml'.";
        assert RequestListButton != null : "fx:id=\"RequestListButton\" was not injected: check your FXML file 'EmployeeMainAreaInterface.fxml'.";
        assert CityCatalogButton != null : "fx:id=\"CityCatalogButton\" was not injected: check your FXML file 'EmployeeMainAreaInterface.fxml'.";
        assert presentClient != null : "fx:id=\"presentClient\" was not injected: check your FXML file 'EmployeeMainAreaInterface.fxml'.";
        assert clientIdField != null : "fx:id=\"clientIdField\" was not injected: check your FXML file 'EmployeeMainAreaInterface.fxml'.";
        assert openClientCardBtn != null : "fx:id=\"openClientCardBtn\" was not injected: check your FXML file 'EmployeeMainAreaInterface.fxml'.";
        assert reportOptionBtn != null : "fx:id=\"reportOptionBtn\" was not injected: check your FXML file 'EmployeeMainAreaInterface.fxml'.";
        chooseMapCombo.setVisible(false);
        chooseSiteCombo.setVisible(false);
        chooseTourCombo.setVisible(false);
        chooseCityCombo.setVisible(false);
        comboboxSitesCiteisnames.setVisible(false);
        reportOptionBtn.getItems().add("Basic Report");
        reportOptionBtn.getItems().add("Custom Report");
        MapOptionsBtn.getItems().add("Add map");
        MapOptionsBtn.getItems().add("Edit map");
        siteOptionCombo.getItems().add("Add site");
        siteOptionCombo.getItems().add("Edit site");
        tourOptionsCombo.getItems().add("Add tour");
        tourOptionsCombo.getItems().add("Edit tour");
        cityOptionCombo.getItems().add("Add city");
        cityOptionCombo.getItems().add("Edit city");
        if(ChatClient.getDataListener.contains(this))
        	ChatClient.getDataListener.remove(ChatClient.getDataListener.size()-1);
        someoneGetData();
    }

    /**
	 * Opens the city catalog page via LoadPage method
	 */
    @FXML
    void ClickbtnCitycatalog(ActionEvent event) throws IOException {
        this.event=event;
        LoadPage("CityCatalog");
    }
    
    /**
	 * Opens the version update list via LoadPage method
	 */
    @FXML
	void UpdateVersionClick(ActionEvent event) throws IOException {
        this.event=event;
        LoadPage("VersionUpdateList");
	}
    
    /**
	 * Opens the maps viewing page via LoadPage method
	 */
    @FXML
    void showMapsClick(ActionEvent event) throws IOException {
  	  this.event=event;
  	  LoadPage("Maps");
    }

    /**
	 * Redirects the user to the selected page.
	 * Making all the preparations in order to move between pages properly.
	 * @param page - the page name that the user wants to get to
	 * @throws IOException
	 */
    public void LoadPage(String page) throws IOException {
     	 FXMLLoader loader= new FXMLLoader(getClass().getResource("/application/"+page+"Interface.fxml"));
     	 root = loader.load();
     	 try {
     	 switch (page)
     	 {
     	 case "BasicReport":
     		 BasicReportBoundry basicReport = loader.getController();
     		 basicReport.setEmployeeInfo(employeeName, position, id);
     		 break;
     	 case "CustomReport":
     		 CustomReportBoundry customReport = loader.getController();
     		 customReport.setEmployeeInfo(employeeName, position, id);
     		 break;
     	 case "AddEditMap":
     		 AddEditMapBoundry addboundry = loader.getController();
     		 addboundry.setEmployeeInfo(employeeName, position, id,(Stage) ((Node) event.getSource()).getScene().getWindow());
     		 if(MapOptionsBtn.getSelectionModel().getSelectedItem().equals("Edit map")) {
     				 addboundry.setMapInfo(mapOption);
     				 addboundry.setEmployeeInfo(employeeName, position, id,(Stage) ((Node) event.getSource()).getScene().getWindow());
     		   }else {
     			   addboundry.setMapInfo("");
     		   }
     		   break;
     	   case "AddEditSite":
     			AddEditSiteBoundry addEditSiteBoundry = loader.getController();
     		   if (siteOptionCombo.getSelectionModel().getSelectedItem().equals("Edit site")) {
     			   for(ArrayList<Object> site : sitesArray) {//find site ID
     				   if(site.get(0).equals(chooseSiteCombo.getSelectionModel().getSelectedItem())) {
     					 addEditSiteBoundry.setSiteInfo("Edit site",employeeName,Integer.valueOf(id),position,(String)site.get(1),Integer.valueOf((String) site.get(2)),null);
     				   }
     			   }
     		   }else {
     			  addEditSiteBoundry.setSiteInfo("Add site",employeeName,Integer.valueOf(id),position,selected,0,null);
     		   }
     		   break;
     	   case "AddEditTour":
     		   AddEditTourBoundry addEditTourBoundry = loader.getController();
     		   addEditTourBoundry.setEmployeeInfo(employeeName, position, id,null);
     		   if(tourOptionsCombo.getSelectionModel().getSelectedItem().equals("Edit tour")) {
     			   addEditTourBoundry.setEditTour(tourOption);
     		   }
     		   break;
     	   case "AddEditCity":
     		   AddEditCityBoundry addEditCityBoundry = loader.getController();
     		   if(cityOptionCombo.getSelectionModel().getSelectedItem().equals("Edit city")) {
     			   addEditCityBoundry.setInfoAddEditCity("Edit city",cityOption,employeeName,id,position);
     		   }else {
     			   addEditCityBoundry.setInfoAddEditCity("Add city","",employeeName,id,position);
     		   }
     		   break;
     	   case "CityCatalog":
     		   CityCatalogBoundry cityCatalogBoundry= loader.getController();
     		   cityCatalogBoundry.setClientInfo(employeeName, position, id,new ArrayList<String>());
     		   break;
     	   case "VersionUpdateList":
     		   VersionUpdateListBoundry versionUpdateListBoundry = loader.getController();
     		   versionUpdateListBoundry.SetManagerInfo(employeeName, position, id);
     		   break;
     	   case "ClientCard":
     		   ClientCardBoundry clientCardBoundry = loader.getController();
     		   clientCardBoundry.setEmployeeInfo(employeeName, position, id,personOption);
     		   clientCardBoundry.getClientCardInfo();
     		   break;
     	   case "Maps":
     		   MapsBoundry mapsBoundry = loader.getController();
     		   mapsBoundry.setMapInfoForRegullarEmployees(employeeName,position,id);
     		   break;
     	   }
     	 info.removeAll(info);
     	 Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
     	 window.setScene(new Scene(root));
     	 window.setOnCloseRequest(new EventHandler<WindowEvent>() {
         @Override
         public void handle(WindowEvent e) {
   		  try {
   			  UserController.logout(id);
   		  }catch (SQLException ex) {ex.printStackTrace();}
         }
     	 });
     	 window.show();
     	 }catch(Exception e){e.printStackTrace();}
    }
    
    /**
	 * When the user chooses a report this method loads the specific report page via loadPage method
	 * @param event
	 * @throws IOException
	 */
    @FXML
    void ClickReportOption(ActionEvent event) throws IOException {
        this.event = event;
        if (reportOptionBtn.getSelectionModel().getSelectedItem().equals("Basic Report")) {
     	   LoadPage("BasicReport");
        } else {
     	   LoadPage("CustomReport");
        }
    }

    /**
     * when the user chooses "add map" this method calls loadPage method and opens the add map page.
     * when the user chooses "edit map" this method enables the maps combo box so the user can choose a map to edit.
     * @param event
     * @throws IOException
     */
    @FXML
    void MapOptionsClick(ActionEvent event) throws IOException {
        this.event = event;
        if (MapOptionsBtn.getSelectionModel().getSelectedItem().equals("Add map")) {
     	   LoadPage("AddEditMap");
        }
        else {
     	   chooseMapCombo.setVisible(true);
        }
    }
    /**
     * when the user choose a map, if the option is edit, it loads the edit map page with the relevant info
     * if the option is delete, deletes the map and all of its relates.
     * @param event
     * @throws IOException
     */
	 @FXML
  	  void chooseMapClick(ActionEvent event) throws IOException {
		 if(isDeleted!=0) {//when an item is removed from a combo box, the method is called again, this line preventing a second,unnecessary deletion.  
   	   		 isDeleted=0;
   	   		 return;
   	   	 }
		 this.event=event;
		 mapOption=chooseMapCombo.getSelectionModel().getSelectedItem();
		 if(MapOptionsBtn.getSelectionModel().getSelectedItem().equals("Edit map"))
			 LoadPage("AddEditMap");
		 else {    
     	   	 isDeleted=1;
     	   	 chooseMapCombo.getItems().remove(chooseMapCombo.getSelectionModel().getSelectedItem());
     	   	 ManagerController.deleteRow("map", mapOption);
     	  
     	   	 HomepageBoundry.messageWindow(AlertType.INFORMATION, "notice", "The map has been deleted!", "");
		 }
	 }
    
	 
	 /**
	  * when the user chooses "add site" this method enables the cities combo box so the user can choose the city for the site.
      * when the user chooses "edit site" this method enables the site combo box so the user can choose a site to edit.
	  * @param event
	  * @throws IOException
	  */
	 @FXML
  	  void siteOptionsClick(ActionEvent event) throws IOException {
     	this.event=event;
     	if(siteOptionCombo.getSelectionModel().getSelectedItem().equals("Add site")) {
     	  comboboxSitesCiteisnames.setVisible(true);
     	}
     	else {
     	   chooseSiteCombo.setVisible(true);
     	}
  	  }
	 /**
	  * when the user choose a site, if the option is edit, it loads the edit site page with the relevant info
     * if the option is delete, deletes the site and all of its relates.
	  * @param event
	  * @throws IOException
	  */
	 @FXML
    void chooseSiteClick(ActionEvent event) throws IOException {
		 if(isDeleted!=0) {//when an item is removed from a combo box, the method is called again, this line preventing a second,unnecessary deletion.  
      		 isDeleted=0;
      		 return;
      	 }
		 this.event=event;
		 selected = comboboxSitesCiteisnames.getSelectionModel().getSelectedItem();
     	for( ArrayList<Object> a : sitesArray) {//find the site in the sites array in order to get its id and city
  	   if(a.get(0).equals(chooseSiteCombo.getSelectionModel().getSelectedItem())) {
  		   siteId=Integer.valueOf((String) a.get(2));
  		   siteCity=(String) a.get(1);
  	   }
       	  }
     	if(siteOptionCombo.getSelectionModel().getSelectedItem().equals("Delete site")) {
     		isDeleted=1;
   		chooseSiteCombo.getItems().remove(chooseSiteCombo.getSelectionModel().getSelectedItem());
     		ManagerController.deleteRow("site", siteId);
     		HomepageBoundry.messageWindow(AlertType.INFORMATION, "notice", "The site has been deleted!", "");
     	}else {
     		LoadPage("AddEditSite");
     	}
        
	 }
    
	 /**
	  * when the user chooses "add tour" this method calls loadPage method and opens the add tour page.
     * when the user chooses "edit tour" this method enables the tour combo box so the user can choose a tour to edit.
	  * @param event
	  * @throws IOException
	  */
	 @FXML
    void tourOptionsClick(ActionEvent event) throws IOException {
     	this.event=event;
     	if(tourOptionsCombo.getSelectionModel().getSelectedItem().equals("Add tour")) {
     		LoadPage("AddEditTour");
     	}
     	else {
     		chooseTourCombo.setVisible(true);
     	}
  	  }
	 /**
	  * when the user choose a tour, if the option is edit, it loads the edit tour page with the relevant info
     * if the option is delete, deletes the tour and all of its relates.
	  * @param event
	  * @throws IOException
	  */
	 @FXML
  	  void chooseTourClick(ActionEvent event) throws IOException {
		 if(isDeleted!=0) {//when an item is removed from a combo box, the method is called again, this line preventing a second,unnecessary deletion.  
			 isDeleted=0;
			 return;
		 }
  	   for( ArrayList<Object> a : toursArray) {//find the tour in the tours array and set tourOption with the selected tour in the combo box
  		   if(a.get(1).equals(chooseTourCombo.getSelectionModel().getSelectedItem())) {
  			   tourOption=(ArrayList<Object>) a;
  		   }
  	   }
  	   if(tourOptionsCombo.getSelectionModel().getSelectedItem().equals("Edit tour"))
  		   LoadPage("AddEditTour");
  	   else {
  		   ManagerController.deleteRow("tour", tourOption.get(0));
  		   isDeleted=1;
  		   chooseTourCombo.getItems().remove(chooseTourCombo.getSelectionModel().getSelectedItem());
  		 HomepageBoundry.messageWindow(AlertType.INFORMATION, "notice", "The tour has been deleted!", "");
  	   }
  	  }
      
	 /**
	  * when the user chooses "add city" this method calls loadPage method and opens the add city page.
     * when the user chooses "edit city" this method enables the cities combo box so the user can choose a city to edit.
	  * @param event
	  * @throws IOException
	  */
	 @FXML
  	  void CityOptionsClick(ActionEvent event) throws IOException {
		 this.event=event;
     	if(cityOptionCombo.getSelectionModel().getSelectedItem().equals("Add city")) {
     		LoadPage("AddEditCity");
     	}
     	else {
     	   chooseCityCombo.setVisible(true);
     	}
  	  }
	 
	/**
 	* when the user choose a city, if the option is edit, it loads the edit city page with the relevant info
     * if the option is delete, deletes the city and all of its relates.
 	* @param event
 	* @throws IOException
 	*/
	 @FXML
  	  void chooseCityClick(ActionEvent event) throws IOException {
		 this.event=event;
		 if(isDeleted!=0) {//when an item is removed from a combo box, the method is called again, this line preventing a second,unnecessary deletion.  
			 isDeleted=0;
			 return;
		 }
        	 cityOption=chooseCityCombo.getSelectionModel().getSelectedItem();
        	 if(cityOptionCombo.getSelectionModel().getSelectedItem().equals("Edit city"))
        		 LoadPage("AddEditCity");
        	 else {
        		 isDeleted=1;
        		 ManagerController.deleteRow("city", cityOption);
        		 chooseCityCombo.getItems().remove(chooseCityCombo.getSelectionModel().getSelectedItem());
        		 HomepageBoundry.messageWindow(AlertType.INFORMATION, "notice", "The city has been deleted!", "");
        	 }
  	  }
    
	 /**
	  * when the user chooses the person he/she wants to view, this method calls loadPage method and opens the client card page.
	  * @param event
	  * @throws IOException
	  */
	 @FXML
	 void choosePersonClick(ActionEvent event) throws IOException {
  	   this.event = event;
  	   personOption=choosePersonCombo.getSelectionModel().getSelectedItem();
  	   LoadPage("ClientCard");
	 }


	 /**
	  * when a person click logout button this method changes the user status to logged out and returns the user to the log in page
	  * @param event
	  * @throws IOException
	  */
    @FXML
    void ClickbtnLoggOut(ActionEvent event) throws IOException {
        try {
			UserController.logout(id);
		} catch (SQLException e) {e.printStackTrace();}
        HomepageBoundry control = new HomepageBoundry();
        control.ClickBtnHomePage(event);
    }

    /**
     * this method sets the work area prior to the permission the user has in the system.
     */
    public void visibility() {
  	  if (position.equals("employee")) {
  		  chooseMapCombo.setVisible(false);
  		  chooseSiteCombo.setVisible(false);
  		  chooseTourCombo.setVisible(false);
  		  chooseCityCombo.setVisible(false);
  		  choosePersonCombo.setVisible(false);
  		  RequestListButton.setVisible(false);
  		  reportOptionBtn.setVisible(false);
  	  }
        if (position.equals("content employee")) {
     	   RequestListButton.setVisible(false);
     	   reportOptionBtn.setVisible(false);
     	   choosePersonCombo.setVisible(false);
        }
        else if (position.equals("content manager")) {
     	   choosePersonCombo.setVisible(false);
     	   MapOptionsBtn.getItems().add("Delete map");
     	   siteOptionCombo.getItems().add("Delete site");
     	   tourOptionsCombo.getItems().add("Delete tour");
     	   cityOptionCombo.getItems().add("Delete city");
        }
        else if(position.equals("company manager")) {
     	   MapOptionsBtn.getItems().add("Delete map");
     	   siteOptionCombo.getItems().add("Delete site");
     	   tourOptionsCombo.getItems().add("Delete tour");
     	   cityOptionCombo.getItems().add("Delete city");
        }
    }
    

    /**
     * this method sets the user info in order to navigate between pages and calls the visibility method to prepare this page
     * @param userName
     * @param userType
     * @param id
     */
    void setEmployeeInfo(String userName, String userType, String id) {
        this.id = id;
        employeeName = userName;
        position = userType;
        positionLabel.setText("Position: " + position);
        Title.setText("Welcome to GCM: " + " " + employeeName);
        visibility();
    }
    
    /**
     * This method calls the controller method to get data from the data base and fill the combo boxes with it.
     */
    public void someoneGetData() {
        ChatClient.getDataListeners(this);
        MapController.getData();
    }

    /**
     * when the data from the data base is returned, fill the combo boxes with it, set sites array and tours array with the sites and tours which in the DB.
     */
    @Override
    public void someoneGetData(ArrayList<Object> result) {
        int i=0,j=0;
        ArrayList<String> arr=(ArrayList<String>) result.get(1);
        while(i < arr.size()) {//fill maps combo box
     	   chooseMapCombo.getItems().add(arr.get(i++));
        }
        i=0;
        sitesArray= new ArrayList<>();//fill sites combo box
        while(i< ((ArrayList<ArrayList<String>>) result.get(2)).size()) {//keeps the array of sites names and ID in "sitesArray", fills the combobox "chooseSite" with sites names
     	  ArrayList<Object> sites= ((ArrayList<ArrayList<Object>>) result.get(2)).get(i++);
     	   sitesArray.add(sites);
     	   chooseSiteCombo.getItems().add((String) sites.get(0));
        }
        i=0;
        toursArray = new ArrayList<>();//fill sites combo box
        while(i< ((ArrayList<ArrayList<String>>) result.get(3)).size()) {
     	   ArrayList<Object> tours = ((ArrayList<ArrayList<Object>>) result.get(3)).get(i++);
     	   toursArray.add(tours);
     	   chooseTourCombo.getItems().add((String) tours.get(1));
        }
        i=0;
        j=0;
        arr= (ArrayList<String>) result.get(4);
        while(i < arr.size()) {//fill city combo box
     	   chooseCityCombo.getItems().add(arr.get(i++));
     	   comboboxSitesCiteisnames.getItems().add(arr.get(j++));
        }
        i=0;
        arr = (ArrayList<String>) result.get(5);
        while(i<arr.size()) {//fill person combo box
     	   choosePersonCombo.getItems().add(arr.get(i++));
        }
      
    }

}






