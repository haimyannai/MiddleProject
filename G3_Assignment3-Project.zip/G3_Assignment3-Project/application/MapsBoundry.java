package application;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Optional;

import javax.imageio.ImageIO;

import Controllers.MapController;
import Controllers.UserController;
import client.ChatClient;
import entities.EditMapEmployeeRequest;
import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
/**
 * This class display two kinds of scene to the employees: show maps, and edit sites in the maps
 */
public class MapsBoundry extends ServerEvent {

	/** Parameters for content employee or content manager */

	@FXML
	private SplitPane parentPane;

	@FXML
	private Label lblCombobox;

	@FXML
	private Button btnConfirmation;

	@FXML
	private Button btncoordinate;

	@FXML
	private Button btnBack;

	@FXML
	private Button btnShowMap;

	@FXML
	private ComboBox<String> cmbListSite;

	@FXML
	private TextArea txtDescription;

	@FXML
	private Label lblHeadlineCityMap;

	@FXML
	private Pane mapPane;

	@FXML
	private Button btnShowsite;

	@FXML
	private Button btnEditCordinate;

	@FXML
	private Pane paneImage;

	@FXML
	private Label lblListOfSites;

	@FXML
	private Label lblEditDiscription;

	/** Parameters for reguular client */
	@FXML
	private Button btnLoadMapForRegullarClient;

	@FXML
	private ComboBox<String> cmbCities;

	@FXML
	private Label lblChooseMap;

	@FXML
	private AnchorPane mapAnchroPane;

    @FXML
    private ImageView loadImg;
    
	private String kindOfPage;
	private String username = null;
	private String Permission = null;
	private String userID = null;
	private String cityname = null;
	private String mapname = null;
	private int giveNewLocationFlag = 1;
	private int loactionFlag = 0;
	private int isMapChanged = 0;
	private double locationX = -1;
	private double locationY = -1;
	private Scene prevPagetemp;
	private String originalMapName;
	private ArrayList<Object> arr = new ArrayList<Object>();
	ArrayList<Object> arrayForLastPage = new ArrayList<Object>();
	EditMapEmployeeRequest editMapEmployeeRequest;
	MapController mapController = new MapController();
	private ArrayList<Object> arrBackToServer;

	ArrayList<EditMapEmployeeRequest> tempSite = new ArrayList<EditMapEmployeeRequest>();
	EditMapEmployeeRequest initTempSite = new EditMapEmployeeRequest("temp", "", -1, -1, 0);
	EditMapEmployeeRequest tempSiteEdit = new EditMapEmployeeRequest("", "", -1, -1, 0);
	ImageView mapImg;

	/** Vals for regullar user */
	ArrayList<EditMapEmployeeRequest> tempRegullatSite = new ArrayList<EditMapEmployeeRequest>();

	@FXML
	void initialize() throws SQLException {
		assert btnBack != null : "fx:id=\"btnBack\" was not injected: check your FXML file 'Mapsinterface.fxml'.";
		assert btnConfirmation != null : "fx:id=\"btnConfirmation\" was not injected: check your FXML file 'Mapsinterface.fxml'.";
		assert btnEditCordinate != null : "fx:id=\"btnEditCordinate\" was not injected: check your FXML file 'Mapsinterface.fxml'.";
		assert btnLoadMapForRegullarClient != null : "fx:id=\"btnLoadMapForRegullarClient\" was not injected: check your FXML file 'Mapsinterface.fxml'.";
		//assert btnShowMap != null : "fx:id=\"btnShowMap\" was not injected: check your FXML file 'Mapsinterface.fxml'.";
		assert cmbCities != null : "fx:id=\"cmbCities\" was not injected: check your FXML file 'Mapsinterface.fxml'.";
		assert cmbListSite != null : "fx:id=\"cmbListSite\" was not injected: check your FXML file 'Mapsinterface.fxml'.";
		assert lblChooseMap != null : "fx:id=\"lblChooseMap\" was not injected: check your FXML file 'Mapsinterface.fxml'.";
		assert lblCombobox != null : "fx:id=\"lblCombobox\" was not injected: check your FXML file 'Mapsinterface.fxml'.";
		assert lblEditDiscription != null : "fx:id=\"lblEditDiscription\" was not injected: check your FXML file 'Mapsinterface.fxml'.";
		assert lblHeadlineCityMap != null : "fx:id=\"lblHeadlineCityMap\" was not injected: check your FXML file 'Mapsinterface.fxml'.";
		assert lblListOfSites != null : "fx:id=\"lblListOfSites\" was not injected: check your FXML file 'Mapsinterface.fxml'.";
		assert mapPane != null : "fx:id=\"mapPane\" was not injected: check your FXML file 'Mapsinterface.fxml'.";
		assert paneImage != null : "fx:id=\"paneImage\" was not injected: check your FXML file 'Mapsinterface.fxml'.";
		assert parentPane != null : "fx:id=\"parentPane\" was not injected: check your FXML file 'Mapsinterface.fxml'.";
		assert txtDescription != null : "fx:id=\"txtDescription\" was not injected: check your FXML file 'Mapsinterface.fxml'.";
		cmbCities.getItems().removeAll(cmbCities.getItems());
	}

	/**
     * this function set the map info to the page and set the relevant city name to
     * the labels JUST FOR CONTENT EMPLOYEES | CONTENT MANAGER | COMPANY MANAGER
     * @param prevPage
     * @param username
     * @param Permission
     * @param userID
     * @param cityname
     * @param mapname
     */
	public void setMapInfoForContent(Scene prevPage, String username, String Permission, String userID, String cityname,
			String mapname, String originalMapName) {
		
		
		this.prevPagetemp = prevPage;
		this.username = username;
		this.Permission = Permission;
		this.userID = userID;
		this.cityname = cityname;
		this.mapname = mapname;
		this.originalMapName = originalMapName;
		lblHeadlineCityMap.setText("Welcome To:" + cityname);
		lblCombobox.setText(cityname + "map's collection:");

		// display the relevant page
		if (Permission.equals("content employee") || Permission.equals("content manager")
				|| Permission.equals("company manager")) {
			this.kindOfPage = "edit";
			lblHeadlineCityMap.setText(cityname);
			lblCombobox.setText(mapname);
			this.tempSite.add(initTempSite);
			loadImg.setVisible(true);
			lblListOfSites.setVisible(true);
			cmbListSite.setVisible(true);
			lblHeadlineCityMap.setVisible(true);
			btnConfirmation.setVisible(true);
			//btnShowMap.setVisible(true);
			lblListOfSites.setVisible(true);
			txtDescription.setVisible(true);
			lblEditDiscription.setVisible(true);
			btnEditCordinate.setVisible(true);
			lblCombobox.setVisible(true);
			lblHeadlineCityMap.setVisible(true);
			MapController MapController = new MapController();
			try {
				MapController.updateStatusMap(this.mapname);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				clickBtnShowMap();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}

    /**
     * this function load the show maps
     * FOR ALL KIND OF EMPLOYEE
     * @param username
     * @param Permission
     * @param userID
     * @throws SQLException
     */
	public void setMapInfoForRegullarEmployees(String username, String Permission, String userID) throws SQLException {

		this.username = username;
		this.Permission = Permission;
		this.userID = userID;
		kindOfPage = "show";
		btnLoadMapForRegullarClient.setVisible(true);
		cmbCities.setVisible(true);
		lblChooseMap.setVisible(true);
		MapController mapController = new MapController();
		ChatClient.AddMapDetailsListeners(this);
		mapController.getDetailsMapRegullarEmployee();

	}

    /**
     * this function put an image point on the specific place of the cursor update
     * the points on map if update location that had points, delete the old point if
     * set new cordinate for place without cordinates, add it to the map
     * @param event
     */
	@FXML
	void getMouseCooridinate(MouseEvent event) {
		try {
			if (loactionFlag == 1) {
				Button btn = new Button();
				this.locationX = event.getX() - 25;
				this.locationY = event.getY() - 35;
				btn.setLayoutX(event.getX() - 25);
				btn.setLayoutY(event.getY() - 35);

				Label lbl = new Label();
				lbl.setText(this.tempSiteEdit.getSitename());
				lbl.setLayoutX(this.locationX);
				lbl.setLayoutY(this.locationY + 37);
				lbl.setTextFill(Color.web("#990000"));
				lbl.setFont(Font.font("Ariel", FontWeight.BOLD, 12));
				mapPane.getChildren().add(lbl);

				Image image = new Image(getClass().getResourceAsStream("loc.gif"));
				ImageView img = new ImageView(image);
				btn.setGraphic(img);
				btn.setStyle("-fx-background-color: Blend;");
				mapPane.getChildren().add(btn);
				loactionFlag = 0;
				giveNewLocationFlag = 1;
				isMapChanged = 1;

				for (int i = 0; i < tempSite.size(); i++) {
					if (tempSite.get(i).getSitename().equals(tempSiteEdit.getSitename())) {
						this.tempSite.get(i).setLocationX(locationX);
						this.tempSite.get(i).setLocationY(locationY);

					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

    /**
     * this method load the map from the database to the users
     * @param event
     * @throws SQLException
     */
	void clickBtnShowMap() throws SQLException {

		MapController mapController = new MapController();
		ChatClient.addmapImagelisteners(this);
		mapController.getCityMapImage(this.mapname);

	}

	/**
	 * this method display the maps to the employees for showing
	 * @param event
	 */
	@FXML
	void clickBtnLoadMapForRegullarClient(ActionEvent event) {
		mapPane.getChildren().clear();
		MapController mapController = new MapController();
		ChatClient.addmapImagelisteners(this);
		if (cmbCities.getSelectionModel().getSelectedItem() == null) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "OOPS", "pay attention",
					"you must have to choose map from the maps name before loading");
		} else {
			try {
				mapController.getCityMapImageRegullar(cmbCities.getSelectionModel().getSelectedItem().toString());
				//ChatClient.AddMapDetailsListeners(this);
				mapController.getDetailsMapRegullarEmployee();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

    /**
     * this method allows the content employees to send their edits to the comapny manager
     * by sending the edits details and take a snapsot of the edited map
     * @param event
     */
	@FXML
	void clickbtnConfirmation(ActionEvent event) {
		MapController mapController = new MapController();
		Parent root = null;
		if (isMapChanged == 1) {
			try {
				mapController.getMapCollectionExit(new String(originalMapName));
			} catch (SQLException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			arrBackToServer = new ArrayList<Object>();
			if (txtDescription.getText().equals("") || giveNewLocationFlag == 0) {
				HomepageBoundry.messageWindow(AlertType.ERROR, "OOPS", "please make sure you place the site on map ",
						"or complete the site edit description");
				return;
			} else {
				Optional<ButtonType> option = HomepageBoundry.messageWindow(AlertType.CONFIRMATION, "Are you sure",
						"you want to send this to confirmation?", "");
				if (option.get() == ButtonType.OK) // if pressed on 'edit location'
				{
					///////// PRINT SCREEN/////////
					Stage stage = (Stage) this.mapAnchroPane.getScene().getWindow();
					Scene scn = (Scene) this.mapAnchroPane.getScene();

					WritableImage image1 = new WritableImage(630, 567);
					scn.snapshot(image1);

					BufferedImage bImage = SwingFXUtils.fromFXImage((Image) image1, null);
					ByteArrayOutputStream s = new ByteArrayOutputStream();
					try {
						ImageIO.write(bImage, "png", s);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					byte[] res = s.toByteArray();
					this.arrBackToServer.add(tempSite);
					this.arrBackToServer.add((String) txtDescription.getText().toString());
					this.arrBackToServer.add(res);
					ChatClient.addEditInfoToMangerReqlisteners(this);
					try {
						mapController.setEditInfoToManger(this.arrBackToServer);
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				Platform.runLater(() -> {
					if (ChatClient.ShowDetailsForRegullarEmployee.contains(this))
						ChatClient.ShowDetailsForRegullarEmployee
								.remove(ChatClient.ShowDetailsForRegullarEmployee.size() - 1);

				});
				Platform.runLater(() -> {

					if (ChatClient.mapImagelisteners.contains(this))
						ChatClient.mapImagelisteners.remove(ChatClient.mapImagelisteners.size() - 1);
				});
				FXMLLoader loader = new FXMLLoader(
						getClass().getResource("/application/EmployeeMainAreaInterface.fxml"));
				try {
					root = loader.load();
				} catch (IOException e) {
					e.printStackTrace();
				}
				EmployeeMainAreaBoundry emab = loader.getController();
				emab.setEmployeeInfo(this.username, this.Permission, this.userID);
				//TODO
				option = HomepageBoundry.messageWindow(AlertType.CONFIRMATION, "sent Succesfully to the manager",
						"and waiting for his approval", "");

				Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
				window.setScene(new Scene(root));
				window.show();

			}
		} else {
			HomepageBoundry.messageWindow(AlertType.ERROR, "OOPS", "you didn't make any update ",
					"it unecessary to send for confirmation");
		}
	}


	
	
    /**
     * this method allows to change the location to the specific site which choosed
     * @param event
     */
	@FXML
	void clickbtnEditCordinate(ActionEvent event) {
		if (cmbListSite.getSelectionModel().getSelectedItem() == null) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Pay Attension!",
					"YOU didnt locate " + this.tempSiteEdit.getSitename(),
					" Please choose site from the site list before");
			return;
		} else {
			if (giveNewLocationFlag == 0) {
				HomepageBoundry.messageWindow(AlertType.ERROR, "Pay Attension!",
						"YOU didnt locate " + this.tempSiteEdit.getSitename(), " Please locate this site");
				return;
			}
			if (!(tempSite.get(0).getMapname().equals("temp")) && (giveNewLocationFlag == 1)) {
				for (int i = 0; i < tempSite.size(); i++) {
					if (cmbListSite.getSelectionModel().getSelectedItem().equals(tempSite.get(i).getSitename())) {
						if (tempSite.get(i).getLocationX() != -1 && tempSite.get(i).getLocationY() != -1) {
							Optional<ButtonType> option = HomepageBoundry.messageWindow(AlertType.CONFIRMATION,
									"This site has location alredy!!",
									"Are you sure you want to change the location of this site?", "");
							if (option.get() == ButtonType.OK) // if pressed on 'edit location'
							{
								tempSite.get(i).setLocationX(-1);
								tempSite.get(i).setLocationY(-1);
								this.tempSiteEdit = this.tempSite.get(i);
								loactionFlag = 1;
								giveNewLocationFlag = 0;
								showLocationSiteOnMap();
							} else// if pressed 'not edit'
								return;

						} else// if the site do not has cordinate on the map
						{
							HomepageBoundry.messageWindow(AlertType.INFORMATION, "Pay Attension!",
									"This site has NOT yet located", "Locate this site");
							giveNewLocationFlag = 0;
							this.tempSiteEdit = this.tempSite.get(i);
							loactionFlag = 1;
						}

					}
				}
			}
		}
	}

    /**
     * this method allows to return to the back page 
     * @param event
     * @throws SQLException
     */
	@FXML
	void clickBtnBack(ActionEvent event) throws SQLException {
		Parent root = null;
		if (kindOfPage.equals("edit")) {
			// update the status val in map Image table

			// remove this from the listener arrayList
			Platform.runLater(() -> {

				if (ChatClient.ShowDetailsForRegullarEmployee.contains(this))
					ChatClient.ShowDetailsForRegullarEmployee
							.remove(ChatClient.ShowDetailsForRegullarEmployee.size() - 1);
			});

			Platform.runLater(() -> {
				if (ChatClient.mapImagelisteners.contains(this))
					ChatClient.mapImagelisteners.remove(ChatClient.mapImagelisteners.size() - 1);
			});
			
			// load the back page
			
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
				public void handle(WindowEvent e) {
					try {
						UserController.logout(userID);
					} catch (SQLException ex) {
						ex.printStackTrace();
					}
					try {
						MapController mapController = new MapController();
						mapController.getMapCollectionExit(new String(originalMapName));
					} catch (SQLException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
				}
			});
			window.setScene(prevPagetemp);
			MapController.removeUpdate(mapname);
			window.show();
		} else {
			if (kindOfPage.equals("show")) {
				Platform.runLater(() -> {
					if (ChatClient.ShowDetailsForRegullarEmployee.contains(this))
						ChatClient.ShowDetailsForRegullarEmployee
								.remove(ChatClient.ShowDetailsForRegullarEmployee.size() - 1);
				});
				Platform.runLater(() -> {
					if (ChatClient.mapImagelisteners.contains(this))
						ChatClient.mapImagelisteners.remove(ChatClient.mapImagelisteners.size() - 1);

				});
				FXMLLoader loader = new FXMLLoader(
						getClass().getResource("/application/EmployeeMainAreaInterface.fxml"));
				try {
					root = loader.load();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				EmployeeMainAreaBoundry emab = loader.getController();
				emab.setEmployeeInfo(this.username, this.Permission, this.userID);
				Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
				window.setScene(new Scene(root));
				window.show();
			}
		}

	}

	/**
	 * this method show the location site on the map
	 */
	public void showLocationSiteOnMap() {
		mapPane.getChildren().clear();
		Image img;
		for (int i = 0; i < this.tempSite.size(); i++) {
			if (this.tempSite.get(i).getLocationX() != -1 && this.tempSite.get(i).getLocationY() != -1) {
				Button btn = new Button();
				Label lbl = new Label();
				lbl.setText(this.tempSite.get(i).getSitename());
				lbl.setLayoutX(this.tempSite.get(i).getLocationX());
				lbl.setLayoutY(this.tempSite.get(i).getLocationY() + 37);
				lbl.setTextFill(Color.web("#990000"));
				lbl.setFont(Font.font("Ariel", FontWeight.BOLD, 12));
				btn.setLayoutX(this.tempSite.get(i).getLocationX());
				btn.setLayoutY(this.tempSite.get(i).getLocationY());
				img = new Image(getClass().getResourceAsStream("loc.gif"));
				ImageView imgV = new ImageView(img);
				btn.setGraphic(imgV);
				btn.setStyle("-fx-background-color: Blend;");
				mapPane.getChildren().add(btn);
				mapPane.getChildren().add(lbl);

			}
		}

	}

	/**
	 * this method get the relavent details from the server and init the page as the
	 * user expected
	 */
	@Override
	public void someoneGetmapImagelisteners(Object mapImage, ArrayList<EditMapEmployeeRequest> arr) {

		String tempSiteName;
		Image img;

		try {
			if (mapImage instanceof String) {
				HomepageBoundry.messageWindow(AlertType.ERROR, "OOPS", "Someone editing this map right now!",
						"try again in few minutes");
			} else {
				ByteArrayInputStream bis = new ByteArrayInputStream((byte[]) mapImage);
				BufferedImage BImage = ImageIO.read(bis);
				Image image = SwingFXUtils.toFXImage(BImage, null);
				ImageView Img = new ImageView();
				Img.setImage(image);
				Img.setFitWidth(630);
				Img.setFitHeight(590);
				paneImage.getChildren().add(Img);
				this.tempSite.remove(0);
				
				if(arr==null)
				{
					HomepageBoundry.messageWindow(AlertType.INFORMATION, "Pay attention",
							"there are no sites that chosed to edit", "");
				}
				else
				{
					for (int i = 0; i < arr.size(); i++) {
						tempSite.add(new EditMapEmployeeRequest(arr.get(i).getMapname(), arr.get(i).getSitename(),
								arr.get(i).getLocationX(), arr.get(i).getLocationY(), arr.get(i).getId()));
						tempSiteName = arr.get(i).getSitename();
						cmbListSite.getItems().add(tempSiteName);
	
						if (arr.get(i).getLocationX() != -1 && arr.get(i).getLocationY() != -1) {
							Button btn = new Button();
							Label lbl = new Label();
							lbl.setText(arr.get(i).getSitename());
							lbl.setLayoutX(arr.get(i).getLocationX());
							lbl.setLayoutY(arr.get(i).getLocationY() + 37);
							lbl.setTextFill(Color.web("#990000"));
							lbl.setFont(Font.font("Ariel", FontWeight.BOLD, 12));
							btn.setLayoutX(arr.get(i).getLocationX());
							btn.setLayoutY(arr.get(i).getLocationY());
							img = new Image(getClass().getResourceAsStream("loc.gif"));
							ImageView imgV = new ImageView(img);
							btn.setGraphic(imgV);
							btn.setStyle("-fx-background-color: Blend;");
							mapPane.getChildren().add(btn);
							mapPane.getChildren().add(lbl);
	
						}
					}
				}
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void someoneWantToUpdateTheSiteEditList(boolean update1, boolean update2) {
		// TODO Auto-generated method stub

		if (update1 == true && update2 == true) {
			HomepageBoundry.messageWindow(AlertType.INFORMATION, "Success",
					"Your Edit info sent to manager Succesfully", "You will get answer soon!");
		} else {
			HomepageBoundry.messageWindow(AlertType.ERROR, "OOPS", "something get wrongs", "try again in few minutes");
		}
	}

	@Override
	public void someoneGetMapsNameCollectoin(ArrayList<String> arrMap, ArrayList<EditMapEmployeeRequest> arrSite) {
		cmbCities.getItems().clear();
		tempRegullatSite = arrSite;
		for (int i = 0; i < arrMap.size(); i++) {
			cmbCities.getItems().add(arrMap.get(i));
		}

	}

	@Override
	public void RegullarEmployeeWantPhoto(Object mapImage) {

		ByteArrayInputStream bis = new ByteArrayInputStream((byte[]) mapImage);
		Image img;
		BufferedImage BImage = null;
		try {
			BImage = ImageIO.read(bis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Image image = SwingFXUtils.toFXImage(BImage, null);
		ImageView Img = new ImageView();
		Img.setImage(image);
		Img.setFitWidth(630);
		Img.setFitHeight(590);
		paneImage.getChildren().add(Img);

		// mapPane.getChildren().remove(lbl);
		for (int i = 0; i < tempRegullatSite.size(); i++) {
			if (tempRegullatSite.get(i).getLocationX() != -1 && tempRegullatSite.get(i).getLocationY() != -1
					&& tempRegullatSite.get(i).getMapname()
							.equals(cmbCities.getSelectionModel().getSelectedItem().toString())) {
				Button btn = new Button();
				Label lbl = new Label();
				lbl.setText(tempRegullatSite.get(i).getSitename());
				lbl.setLayoutX(tempRegullatSite.get(i).getLocationX());
				lbl.setLayoutY(tempRegullatSite.get(i).getLocationY() + 37);
				lbl.setTextFill(Color.web("#990000"));
				lbl.setFont(Font.font("Ariel", FontWeight.BOLD, 12));
				btn.setLayoutX(tempRegullatSite.get(i).getLocationX());
				btn.setLayoutY(tempRegullatSite.get(i).getLocationY());
				img = new Image(getClass().getResourceAsStream("loc.gif"));
				ImageView imgV = new ImageView(img);
				btn.setGraphic(imgV);
				btn.setStyle("-fx-background-color: Blend;");
				mapPane.getChildren().add(btn);
				mapPane.getChildren().add(lbl);

			}
		}

	}

}



