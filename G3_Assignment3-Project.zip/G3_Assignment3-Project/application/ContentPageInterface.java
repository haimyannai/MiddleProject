package application;

import java.io.IOException;

import client.ChatClient;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class ContentPageInterface extends ServerEvent {
	
    @FXML
    private TextArea txtViewPrivacyTerms;

    @FXML
    private Button btnHomePage;

    @FXML
    void ClickBtnHomePage(ActionEvent event) throws IOException {
    	
    	Parent RegistratiomForm = FXMLLoader.load(getClass().getResource("/application/HomePageInterface.fxml"));
		Scene RegistratiomFormScene = new Scene(RegistratiomForm);
		if(ChatClient.Loginlisteners.contains(this))
			ChatClient.Loginlisteners.remove(ChatClient.Loginlisteners.size()-1);
		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene(RegistratiomFormScene);
		window.show();
		

    }


}
