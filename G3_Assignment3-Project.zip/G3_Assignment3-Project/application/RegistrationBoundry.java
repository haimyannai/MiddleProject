package application;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import Controllers.UserController;
import client.ChatClient;
import entities.RegisterDataRequest;
import entities.RegisterDataResponse;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
/**
 *this class allows to register as a client to the system
 */
public class RegistrationBoundry extends ServerEvent {

	HomepageBoundry control = new HomepageBoundry();

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private AnchorPane registAncor;

	@FXML
	private Pane RegistrationPane;

	@FXML
	private TextField txtFullname;

	@FXML
	private TextField txtEmail;

	@FXML
	private ComboBox<String> sexCombobox;

	@FXML
	private TextField txtID;

	@FXML
	private TextField txtPhone;

	@FXML
	private PasswordField txtPassword;

	@FXML
	private PasswordField txtRePassword;

	@FXML
	private TextField txtUsername;

	@FXML
	private DatePicker birthdaypicker;

	@FXML
	private TextField addresstext;

	@FXML
	private ImageView x3;

	@FXML
	private ImageView x4;

	@FXML
	private ImageView x1;

	@FXML
	private ImageView x2;

	@FXML
	private ImageView x7;

	@FXML
	private ImageView x6;

	@FXML
	private Label headLinelbl;

	@FXML
	private Button btnFinish;

	@FXML
	private Button btnBack;

	@FXML
	private Button btnUpdate;

	@FXML
	private TextField txtCluePassword;

	@FXML
	private ImageView x5;

	private ActionEvent event=null;

	private Parent root = null;

	private Stage window = null;

	private int flagWindow = 0;

	private String username = null;

	private String id = null;

	private String permmision = null;

	private String label = "";

	@FXML
	void initialize() {
		assert registAncor != null : "fx:id=\"registAncor\" was not injected: check your FXML file 'RegistrationInterface.fxml'.";
		assert RegistrationPane != null : "fx:id=\"RegistrationPane\" was not injected: check your FXML file 'RegistrationInterface.fxml'.";
		assert txtFullname != null : "fx:id=\"txtFullname\" was not injected: check your FXML file 'RegistrationInterface.fxml'.";
		assert txtEmail != null : "fx:id=\"txtEmail\" was not injected: check your FXML file 'RegistrationInterface.fxml'.";
		assert sexCombobox != null : "fx:id=\"sexCombobox\" was not injected: check your FXML file 'RegistrationInterface.fxml'.";
		assert txtID != null : "fx:id=\"txtID\" was not injected: check your FXML file 'RegistrationInterface.fxml'.";
		assert txtPhone != null : "fx:id=\"txtPhone\" was not injected: check your FXML file 'RegistrationInterface.fxml'.";
		assert birthdaypicker != null : "fx:id=\"birthdaypicker\" was not injected: check your FXML file 'RegistrationInterface.fxml'.";
		assert addresstext != null : "fx:id=\"addresstext\" was not injected: check your FXML file 'RegistrationInterface.fxml'.";
		assert txtPassword != null : "fx:id=\"txtPassword\" was not injected: check your FXML file 'RegistrationInterface.fxml'.";
		assert txtRePassword != null : "fx:id=\"txtRePassword\" was not injected: check your FXML file 'RegistrationInterface.fxml'.";
		assert txtUsername != null : "fx:id=\"txtUsername\" was not injected: check your FXML file 'RegistrationInterface.fxml'.";
		assert txtCluePassword != null : "fx:id=\"txtCluePassword\" was not injected: check your FXML file 'RegistrationInterface.fxml'.";
		assert x3 != null : "fx:id=\"x3\" was not injected: check your FXML file 'RegistrationInterface.fxml'.";
		assert x4 != null : "fx:id=\"x4\" was not injected: check your FXML file 'RegistrationInterface.fxml'.";
		assert x1 != null : "fx:id=\"x1\" was not injected: check your FXML file 'RegistrationInterface.fxml'.";
		assert x2 != null : "fx:id=\"x2\" was not injected: check your FXML file 'RegistrationInterface.fxml'.";
		assert btnFinish != null : "fx:id=\"btnFinish\" was not injected: check your FXML file 'RegistrationInterface.fxml'.";
		assert btnBack != null : "fx:id=\"btnBack\" was not injected: check your FXML file 'RegistrationInterface.fxml'.";
		assert x5 != null : "fx:id=\"x5\" was not injected: check your FXML file 'RegistrationInterface.fxml'.";
		assert btnUpdate != null : "fx:id=\"btnUpdate\" was not injected: check your FXML file 'RegistrationInterface.fxml'.";
		x1.setVisible(false);
		x2.setVisible(false);
		x3.setVisible(false);
		x4.setVisible(false);
		x5.setVisible(false);
		x6.setVisible(false);
		x7.setVisible(false);
		sexCombobox.getItems().add("Male");
		sexCombobox.getItems().add("Female");
	}

    /** this method check user name input*/
	boolean checkUsername() {
		if (txtUsername.getText().equals("")) {
			return true;
		}
		return false;
	}
    /** this method check full name input*/
	boolean checkFullName() {
		if (txtFullname.getText().equals("")) {
			return true;
		}
		return false;
	}
    /** this method check id input*/
	boolean checkID() {
		String ID = txtID.getText();

		if (ID.equals("") || ID.length() != 9) {
			return true;
		}

		for (int i = 0; i < ID.length(); i++) {
			if (!(ID.charAt(i) >= '0' && ID.charAt(i) <= '9')) {
				return true;
			}
		}
		while (ID.length() > 9) {
			if (ID.charAt(0) == '0')
				ID = ID.substring(1);
			else {
				return true;
			}
		}
		while (ID.length() < 9) {
			ID = "0" + ID;
		}
		return false;
	}
    /** this method check password input*/
	boolean checkPassword() {
		if (txtPassword.getText().equals("")) {
			return true;
		}
		return false;
	}
    /** this method check the email input*/
	boolean checkEmail() {
		String[] EmailParts = null;
		String email = txtEmail.getText();
		if (email.equals(null) || email.equals(""))
			return true;
		EmailParts = email.split("@");
		if (EmailParts.length != 2)
			return true;
		if (EmailParts[0].equals("") || EmailParts[1] == null)
			return true;
		if (!EmailParts[1].equals("gmail.com"))
			return true;
		return false;
	}

    /** this method check re password input*/
	boolean checkRePassword() {
		if (txtRePassword.getText().equals("")) {
			return true;
		}
		if (!(txtRePassword.getText().equals(txtPassword.getText()))) {
			return true;
		}
		return false;
	}
    /**
     * this method load the page with the initianal details that require
     * @param Label
     * @param id
     * @param username
     * @param permmision
     */
	public void setPersonalUpdateInfo(String Label, String id, String username, String permmision) {
		this.id = id;
		this.username = username;
		this.permmision = permmision;
		this.label = Label;
		headLinelbl.setText("Update your personal information");
		txtFullname.setDisable(true);
		x1.setVisible(false);
		txtID.setDisable(true);
		txtUsername.setDisable(true);
		x2.setVisible(false);
		x3.setVisible(false);
		x4.setVisible(false);
		x5.setVisible(false);
		sexCombobox.setDisable(true);
		btnFinish.setVisible(false);
		btnUpdate.setVisible(true);
		birthdaypicker.setDisable(true);
		ChatClient.addgetUpdateClientInfolisteners(this);
		try {
			UserController.getUpdateClientInfo(id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

    /**
     * this method allows to return to the back page
     * @param event
     * @throws IOException
     */
	@FXML
	void ClickbtnBack(ActionEvent event) throws IOException {

		if (ChatClient.Registeredlisteners.contains(this))
			ChatClient.Registeredlisteners.remove(ChatClient.Registeredlisteners.size() - 1);
		if (ChatClient.UpdateClientInfolisteners.contains(this))
			ChatClient.UpdateClientInfolisteners.remove(ChatClient.UpdateClientInfolisteners.size() - 1);
		if (ChatClient.getUpdateClientInfolisteners.contains(this))
			ChatClient.getUpdateClientInfolisteners.remove(ChatClient.getUpdateClientInfolisteners.size() - 1);
		if (label.equals("ClientMainAreaBoundry")) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/ClientMainAreaInterface.fxml"));
			root = loader.load();
			ClientMainAreaBoundry clientMainAreaBoundry = loader.getController();
			clientMainAreaBoundry.setClientInfo(username, permmision, id);
			Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
			window.setScene(new Scene(root));
			window.show();
		} else {control.ClickBtnHomePage(event);}
	}
    /**
     * this following methods hide error images
     * @param event
     */
	@FXML
	void hideX1(MouseEvent event) {
		x1.setVisible(false);
	}

	@FXML
	void hideX2(MouseEvent event) {
		x2.setVisible(false);
	}

	@FXML
	void hideX3(MouseEvent event) {
		x3.setVisible(false);
	}

	@FXML
	void hideX4(MouseEvent event) {
		x4.setVisible(false);
	}

	@FXML
	void hideX5(MouseEvent event) {
		x5.setVisible(false);
	}

    /**
     * this method allows to update the info by pressing on update btn
     * @param event
     * @throws SQLException
     */
	@FXML
	void ClickbtnUpdate(ActionEvent event) throws SQLException, IOException {
		if (checkRePassword()) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "Your password dont match", "try again!");
			return;
		}
		if (txtPhone.getText().equals("") || txtEmail.getText().equals("") || addresstext.getText().equals("")
				|| checkPassword()) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "please fill all the the missing fileds",
					"try again!");
			return;
		} else {
			String phone = txtPhone.getText();
			String email = txtEmail.getText();
			String address = addresstext.getText();
			String Username = txtUsername.getText();
			String Password = txtPassword.getText();
			RegisterDataRequest registerDataRequest = new RegisterDataRequest("", id, phone, "", email, Username,
					Password, "", "", address);
			ChatClient.addUpdateClientInfolisteners(this);
			UserController.updateClientInfo(registerDataRequest);
			
		}
	}

    /**
     * this method allows to finish the registration by preeing on registration btn
     * @param event
     * @throws SQLException
     */
	@FXML
	void ClickbtnFinish(ActionEvent event) throws SQLException, IOException {
		int countErrors = 0;
		this.event = event;

		if (checkFullName()) {
			x1.setVisible(true);
			countErrors++;
		}
		if (checkID()) {
			x2.setVisible(true);
			countErrors++;
		}

		if (checkUsername()) {
			x3.setVisible(true);
			countErrors++;
		}
		if (checkPassword()) {
			x4.setVisible(true);
			countErrors++;
		}
		if (checkRePassword()) {
			x5.setVisible(true);
			countErrors++;
		}
		if (checkEmail()) {
			countErrors++;
			x6.setVisible(true);
		}

		if (countErrors != 0) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "please fill all the the missing fileds",
					"try again!");
			return;
		} else {
			ChatClient.addRegisterListener(this);
			String fullname = txtFullname.getText();
			String id = txtID.getText();
			String phone = txtPhone.getText();
			String sex = sexCombobox.getSelectionModel().getSelectedItem();
			String email = txtEmail.getText();
			if (birthdaypicker.getValue() == null) {
				x7.setVisible(true);
				HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "please choose in the birthday filed",
						"try again!");
				return;
			}
			String birthday = birthdaypicker.getValue().toString();
			String address = addresstext.getText();
			String username = txtUsername.getText();
			String password = txtPassword.getText();
			String cluePassword = txtCluePassword.getText();
			RegisterDataRequest registerDataRequest = new RegisterDataRequest(fullname, id, phone, sex, email, username,
					password, cluePassword, birthday, address);
			UserController.registrateUser(registerDataRequest);
	
		}
	}

	/*
	 * @Override public void someoneLoggedin(LoginDataResponse loginRes) { }
	 */

	@Override
	public void someoneRegistered(RegisterDataResponse registerDataResponse) {
		try {
			if (registerDataResponse.getRegisterRes()) {
				HomepageBoundry.messageWindow(AlertType.INFORMATION, "Sucess", "Successfuly registered", "");
				loadPage();
			} else {
				HomepageBoundry.messageWindow(AlertType.ERROR, "OOPS", "this ID or Username are taken",
						"please try again");
				Platform.runLater(() -> {
					if (ChatClient.Registeredlisteners.contains(this))
						ChatClient.Registeredlisteners.remove(ChatClient.Registeredlisteners.size() - 1);
				});
			}
		} catch (IOException e) {e.printStackTrace();}
	}

	public void getUpdateClientInfo(RegisterDataRequest registerDataRequest) {

		txtPhone.setText(registerDataRequest.getPhone());
		txtEmail.setText(registerDataRequest.getEmail());
		addresstext.setText(registerDataRequest.getAddress());
		txtFullname.setPromptText(registerDataRequest.getFullname());
		txtID.setPromptText(registerDataRequest.getId());
		birthdaypicker.setPromptText(registerDataRequest.getBirthday());
		txtUsername.setPromptText(registerDataRequest.getUsername());
		txtPassword.setText(registerDataRequest.getPassword());
	}

	public void someoneUpdateHisInfo(boolean res) {
		Platform.runLater(() -> {
		if (res == true) {
			HomepageBoundry.messageWindow(AlertType.INFORMATION, "Sucess", "Successfuly Updated", "Now you can return to the main area by clicking back!");
			btnUpdate.setVisible(false);
		} else {
			HomepageBoundry.messageWindow(AlertType.ERROR, "OOPS", "Your Updated faild",
					"you missed some fields or your password doest NOT match");
		}

});
}
    /**
     * this method load the purchase subscription page
     * @throws IOException
     */
	public void loadPage() throws IOException {

		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/PurchaseSubscriptionInterface.fxml"));
		root = loader.load();
		PurchaseSubscriptionBoundry purchaseSubscription = loader.getController();
		purchaseSubscription.setUserInfo(txtID.getText(), txtUsername.getText(), "client",null);
		purchaseSubscription.setPageInfo("registration");
		if (flagWindow == 0) {
			this.window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(new Scene(root));
			flagWindow = 1;
		}

		window.show();
	}

}