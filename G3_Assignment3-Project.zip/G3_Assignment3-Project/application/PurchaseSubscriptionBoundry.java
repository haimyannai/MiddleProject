package application;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import Controllers.PurchaseController;
import Controllers.UserController;
import client.ChatClient;
import entities.CreditCardInfoResponse;
import entities.CreditCardInforRequest;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * this boundary has few different faces.
 * it is a page were the user can set new payment methods or update current details.
 * @author maor asis
 */
public class PurchaseSubscriptionBoundry extends ServerEvent {

	@FXML
	private Label lblpageHeadLine;

	@FXML
	private Label lblItem;

	@FXML
	private Label Length_label;

	@FXML
	private ComboBox<String> Sub_Len_CB;

	@FXML
	private ChoiceBox<String> creditCardCombobox;

	@FXML
	private Label CurrentCompany;

	@FXML
	private TextField txtCvr;

	@FXML
	private Button Donebtn;

	@FXML
	private TextField txtCardnumber;

	@FXML
	private Button Laterbtn;

	@FXML
	private TextField txtExdate;
	@FXML
	private ImageView x1;
	@FXML
	private ImageView x2;
	@FXML
	private ImageView x3;
	@FXML
	private ImageView x4;

	private Parent root = null;

	private String ID;

	private String username;

	private String permmision = "";

	private String privousAction;

	private int flagWindow = 0;

	private Stage window = null;

	private ActionEvent event;

	ArrayList<String> exp = new ArrayList<String>();

	@FXML
	void initialize() {
		assert lblpageHeadLine != null : "fx:id=\"lblpageHeadLine\" was not injected: check your FXML file 'PurchaseSubsciptionInterface.fxml'.";
		assert creditCardCombobox != null : "fx:id=\"creditCardCombobox\" was not injected: check your FXML file 'PurchaseSubsciptionInterface.fxml'.";
		assert lblItem != null : "fx:id=\"lblItem\" was not injected: check your FXML file 'PurchaseSubsciptionInterface.fxml'.";
		assert txtCvr != null : "fx:id=\"txtCvr\" was not injected: check your FXML file 'PurchaseSubsciptionInterface.fxml'.";
		assert txtExdate != null : "fx:id=\"txtExdate\" was not injected: check your FXML file 'PurchaseSubsciptionInterface.fxml'.";
		assert txtCardnumber != null : "fx:id=\"txtCardnumber\" was not injected: check your FXML file 'PurchaseSubsciptionInterface.fxml'.";
		assert Laterbtn != null : "fx:id=\"Laterbtn\" was not injected: check your FXML file 'PurchaseSubsciptionInterface.fxml'.";
		assert Donebtn != null : "fx:id=\"Donebtn\" was not injected: check your FXML file 'PurchaseSubsciptionInterface.fxml'.";
		assert x1 != null : "fx:id=\"x1\" was not injected: check your FXML file 'PurchaseSubsciptionInterface.fxml'.";
		assert x2 != null : "fx:id=\"x2\" was not injected: check your FXML file 'PurchaseSubsciptionInterface.fxml'.";
		assert x3 != null : "fx:id=\"x3\" was not injected: check your FXML file 'PurchaseSubsciptionInterface.fxml'.";
		assert x4 != null : "fx:id=\"x4\" was not injected: check your FXML file 'PurchaseSubsciptionInterface.fxml'.";
		assert CurrentCompany != null : "fx:id=\"CurrentCompany\" was not injected: check your FXML file 'PurchaseSubsciptionInterface.fxml'.";

		creditCardCombobox.getItems().add("MasterCard");
		creditCardCombobox.getItems().add("IsraCard");
		creditCardCombobox.getItems().add("Visa");
		creditCardCombobox.getItems().add("PayPal");
		creditCardCombobox.getItems().add("AmericanExpress");
		creditCardCombobox.getItems().add("Discover");

	}

	/**
     * saves the user information.
     * @param ID
     * @param username
     * @param permmision
     * @param exp
     */
	public void setUserInfo(String ID, String username, String permmision, ArrayList<String> exp) {
		this.ID = ID;
		this.username = username;
		this.permmision = permmision;
		this.exp = exp;
	}
	/**
     * hide the 'X' mark when the user wishes to currect his input
     * @param event
     */
	@FXML
	void hideX1(MouseEvent event) {
		x1.setVisible(false);
	}

	@FXML
	void hideX2(MouseEvent event) {
		x2.setVisible(false);
	}

	@FXML
	void hideX3(MouseEvent event) {
		x3.setVisible(false);
	}

	@FXML
	void hideX4(MouseEvent event) {
		x4.setVisible(false);
	}

	/**
     * checks if the expiration date that entered is valid.
     * return false if not, true if yes.
     * @return
     */
	boolean checkExDate() {
		if (txtExdate.getText().equals("")) {
			return true;
		}
		if ((txtExdate.getText().charAt(2) != '/') || (txtExdate.getText().length() != 7)) {
			return true;
		}
		for (int i = 0; i < (txtExdate.getText()).length(); i++) {
			if (i != 2) {
				if (!(txtExdate.getText().charAt(i) >= '0' & txtExdate.getText().charAt(i) <= '9')) {
					return true;
				}
			}
		}
		return false;
	}

	/**
     * check for valid CVR input.
     * @return
     */
	boolean checkCVR() {
		if (txtCvr.getText().equals("")) {
			return true;
		}
		if (txtCvr.getText().length() != 3) {
			return true;
		}

		for (int i = 0; i < (txtCvr.getText()).length(); i++) {
			if (!(txtCvr.getText().charAt(i) >= '0' && txtCvr.getText().charAt(i) <= '9')) {
				return true;
			}
		}
		return false;
	}

	/**
     * checks if the client entered a 9 digit valid number.
     * @return
     */
	boolean checkCardNum() {
		if ((txtCardnumber.getText()).length() != 9 || (txtCardnumber.getText()).equals("")) {
			return true;
		}
		for (int i = 0; i < (txtCardnumber.getText()).length(); i++) {
			if (!(txtCardnumber.getText().charAt(i) >= '0' && txtCardnumber.getText().charAt(i) <= '9')) {
				return true;
			}
		}
		return false;
	}

	/**
     * returns false if the user didn't pick any company.
     * @return
     */
	boolean checkCardCompanyName() {
		try {
			creditCardCombobox.getSelectionModel().getSelectedItem().equals(null);
			return false;
		} catch (NullPointerException e) {
			return true;
		}

	}
	/**
     * this methods present the page accordingly to the user how view it.
     * @param privousAction
     */
	public void setPageInfo(String privousAction) {
		this.privousAction = privousAction;
		switch (privousAction) {
		case "CityCatalog": 
		case "registration":
			lblpageHeadLine.setText("Set payment metod");
			lblItem.setVisible(false);
			break;
		case "ClientMainArea":
			lblpageHeadLine.setText("Update Payment Method");
			lblItem.setVisible(false);
			Donebtn.setText("Set Changes");
			Laterbtn.setText("Back");
			ChatClient.addClientPaymentlistener(this);
			PurchaseController.getPaymentInfo(this.ID);
			break;
		}
	}

	public void returnPaymentInfo(ArrayList<Object> payment) {
		Platform.runLater(() -> {
			ArrayList<String> arr = new ArrayList<String>();
			if (payment.size() > 1) {
				payment.remove(0);
				for (Object O : payment)
					arr.add((String) O);
				CurrentCompany.setText(arr.get(0));
				txtCardnumber.setText(arr.get(1));
				txtExdate.setText(arr.get(3));
				txtCvr.setText(arr.get(2));
				if (ChatClient.ClientPaymentMethodlistener.contains(this))
					ChatClient.ClientPaymentMethodlistener.remove(ChatClient.ClientPaymentMethodlistener.size() - 1);
			}
		});
	}

	/**
     * exit the user from this page to his main 
     * @param event
     * @throws IOException
     */
	@FXML
	void clickBtnBack(ActionEvent event) throws IOException {
		if (lblpageHeadLine.getText().equals("Update Payment Method")) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/ClientMainAreaInterface.fxml"));
			root = loader.load();
			ClientMainAreaBoundry ClientMainArea = loader.getController();
			ClientMainArea.setClientInfo(this.username, this.permmision, this.ID);
		} else if(!lblpageHeadLine.getText().equals("Update Payment Method")&& this.privousAction.equals("CityCatalog")) {//TODO
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/EmployeeMainAreaInterface.fxml"));
			root = loader.load();
			EmployeeMainAreaBoundry Employee = loader.getController();
			Employee.setEmployeeInfo(this.username, this.permmision, this.ID);
		}	
		else {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/HomePageInterface.fxml"));
			root = loader.load();
		}
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(new Scene(root));
			window.show();
	}


	/**
     * checks if all the wanted field has been filled, if not present to the user a marker
     * that indicate what needed to be changed.
     * after a full input, the boundary active a controller methods that set or updated the client card info.
     * @param event
     * @throws SQLException
     */
	@FXML
	void clickBtnDone(ActionEvent event) throws SQLException {
		this.event = event;
		int countErrors = 0;
		if (checkCardCompanyName()) {
			x1.setVisible(true);
			countErrors++;
		}
		if (checkCardNum()) {
			x2.setVisible(true);
			countErrors++;
		}
		if (checkExDate()) {
			x3.setVisible(true);
			countErrors++;
		}
		if (checkCVR()) {
			x4.setVisible(true);
			countErrors++;
		}
		if (countErrors != 0) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "please fill all the the missing fileds",
					"try again!");
			return;
		}
		String companyCard = creditCardCombobox.getSelectionModel().getSelectedItem();
		int cardNumber = Integer.parseInt(txtCardnumber.getText());
		String exDate = txtExdate.getText();
		int cvr = Integer.parseInt(txtCvr.getText());
		if (!lblpageHeadLine.getText().equals("Set payment metod")&& !txtExdate.equals("")) {
			ChatClient.addNewPaymentInfolistener(this);/// to update
			PurchaseController.setNewPaymentInfo(new CreditCardInforRequest(companyCard, cardNumber, cvr, exDate, this.ID));
		} else {
			ChatClient.addCreditInfolisteners(this);//to create new
			CreditCardInforRequest creditCardInfo = new CreditCardInforRequest(companyCard, cardNumber, cvr, exDate,this.ID);
			UserController.setCreditInfo(creditCardInfo);
		}

	}

	@Override
	public void someoneSetCreditInfo(CreditCardInfoResponse creditCardInfoResponse) {//after setting new payment methods.
		Platform.runLater(() -> {
		try {
			if (creditCardInfoResponse.getCreditCardInfoRes()) {//TODO
				HomepageBoundry.messageWindow(AlertType.INFORMATION, "Sucess", "Successfuly payment details added", "");
/*			if (ChatClient.setCreditInfolisteners.contains(this))
					ChatClient.setCreditInfolisteners.remove(ChatClient.Registeredlisteners.size() - 1);*/
				loadPage();
			} else {
				HomepageBoundry.messageWindow(AlertType.ERROR, "OOPS", "this credit info are in use",
						"please try again");
			}
		} catch (IOException e) {e.printStackTrace();}
	});
}

	/**
     * takes the user to his main area after he execute his action.
     * @throws IOException
     */
	public void loadPage() throws IOException {//TODO
		FXMLLoader loader;

		if (privousAction.equals("CityCatalog")) {
			loader = new FXMLLoader(getClass().getResource("/application/CityCatalogInterface.fxml"));
			root = loader.load();
			CityCatalogBoundry catalog = loader.getController();
			catalog.setClientInfo(this.username, this.permmision, this.ID, this.exp);
		} else if (privousAction.equals("registration")) {
			loader = new FXMLLoader(getClass().getResource("/application/HomePageInterface.fxml"));
			root = loader.load();
			HomepageBoundry hpb = new HomepageBoundry();
			hpb.ClickBtnHomePage(event);
		}
		 else if(!this.permmision.equals("client")){
			loader = new FXMLLoader(getClass().getResource("/application/EmployeeMainAreaInterface.fxml"));
			root = loader.load();
			EmployeeMainAreaBoundry Employee = loader.getController();
			Employee.setEmployeeInfo(this.username, this.permmision, this.ID);
		}
		if (flagWindow == 0) {
			this.window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(new Scene(root));
			flagWindow = 1;
		}
		window.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent e) {
				try {
					UserController.logout(ID);
				} catch (SQLException ex) {ex.printStackTrace();}
			}
		});
		window.show();
	}

	
	public void SetNewPaymentInfoResult(boolean result) {///after update so, go back to the client main area
		Platform.runLater(() -> {
			if (result) {
				HomepageBoundry.messageWindow(AlertType.INFORMATION, "Success",
						"Your Payment methods detaild has been updated Successfully",
						"Now you will return to the privious page");
				
			} else {
				HomepageBoundry.messageWindow(AlertType.ERROR, "Oppss...", "Your Payment methods couldn't been added",
						"Please try again in 5 minutes and check your input");
			}
			if (ChatClient.SetNewPaymentInfolistener.contains(this))
				ChatClient.SetNewPaymentInfolistener.remove(ChatClient.SetNewPaymentInfolistener.size() - 1);
			try {
				clickBtnBack(event);
			} catch (IOException e) {e.printStackTrace();}
		});
		
	}

}
