package application;

import application.*;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;

public class PrivacyTermsBoundry extends ServerEvent{

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextArea txtViewPrivacyTerms;

    @FXML
    private Button btnHomePage;

    @FXML
    void ClickBtnHomePage(ActionEvent event) throws IOException {
    	HomepageBoundry hpb=new HomepageBoundry();
    	hpb.ClickBtnHomePage(event);
    }

    @FXML
    void initialize() {
        assert txtViewPrivacyTerms != null : "fx:id=\"txtViewPrivacyTerms\" was not injected: check your FXML file 'PrivacyTermsInterface.fxml'.";
        assert btnHomePage != null : "fx:id=\"btnHomePage\" was not injected: check your FXML file 'PrivacyTermsInterface.fxml'.";
    }
}