package application;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import Controllers.ReportController;
import Controllers.UserController;
import client.ChatClient;
import entities.BasicReportResponse;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * This class is the boundary of the page Basic report.
 * In this page the user can set a pair of dates and get the information about purchases between those dates for every city in the system
 * The table in this page also shows the amount of views downloads and number of maps.
 * @author gilad
 *
 */
public class BasicReportBoundry extends ServerEvent {

	@FXML
	private ImageView Homebtn;
	@FXML
	private DatePicker fromDatePicker;
	@FXML
	private DatePicker toDatePicker;

	@FXML
	private TableView<BasicReportResponse> Table = new TableView<>();

	@FXML
	private TableColumn<BasicReportResponse, String> cityCol;

	@FXML
	private TableColumn<BasicReportResponse, String> mapsCol;

	@FXML
	private TableColumn<BasicReportResponse, String> purchasesCol;

	@FXML
	private TableColumn<BasicReportResponse, String> subscriptionCol;

	@FXML
	private TableColumn<BasicReportResponse, String> renewalsCol;

	@FXML
	private TableColumn<BasicReportResponse, String> viewsCol;

	@FXML
	private TableColumn<BasicReportResponse, String> downloadsCol;

	@FXML
	private Button showTableBtn;

	@FXML
	private Button backBtn;

	private ActionEvent event;
	
	private Parent root = null;
	
	private String id;
	
	private String employeeName = "empty";
	
	private String position;
	
	private int flagWindow = 0;
	
	private Stage window = null;

	ObservableList<BasicReportResponse> data = FXCollections.observableArrayList();

	@FXML
	void initialize() {
		assert Homebtn != null : "fx:id=\"Homebtn\" was not injected: check your FXML file 'BasicReportInterface.fxml'.";
		assert fromDatePicker != null : "fx:id=\"fromDatePicker\" was not injected: check your FXML file 'BasicReportInterface.fxml'.";
		assert toDatePicker != null : "fx:id=\"toDatePicker\" was not injected: check your FXML file 'BasicReportInterface.fxml'.";
		assert showTableBtn != null : "fx:id=\"showTableBtn\" was not injected: check your FXML file 'BasicReportInterface.fxml'.";
		assert Table != null : "fx:id=\"Table\" was not injected: check your FXML file 'BasicReportInterface.fxml'.";
		assert cityCol != null : "fx:id=\"cityCol\" was not injected: check your FXML file 'BasicReportInterface.fxml'.";
		assert mapsCol != null : "fx:id=\"mapsCol\" was not injected: check your FXML file 'BasicReportInterface.fxml'.";
		assert purchasesCol != null : "fx:id=\"purchasesCol\" was not injected: check your FXML file 'BasicReportInterface.fxml'.";
		assert subscriptionCol != null : "fx:id=\"subscriptionCol\" was not injected: check your FXML file 'BasicReportInterface.fxml'.";
		assert renewalsCol != null : "fx:id=\"renewalsCol\" was not injected: check your FXML file 'BasicReportInterface.fxml'.";
		assert viewsCol != null : "fx:id=\"viewsCol\" was not injected: check your FXML file 'BasicReportInterface.fxml'.";
		assert downloadsCol != null : "fx:id=\"downloadsCol\" was not injected: check your FXML file 'BasicReportInterface.fxml'.";
		assert backBtn != null : "fx:id=\"backBtn\" was not injected: check your FXML file 'BasicReportInterface.fxml'.";
		cityCol.setCellValueFactory(new PropertyValueFactory<BasicReportResponse, String>("city"));
		mapsCol.setCellValueFactory(new PropertyValueFactory<BasicReportResponse, String>("maps"));
		purchasesCol.setCellValueFactory(new PropertyValueFactory<BasicReportResponse, String>("purchases"));
		subscriptionCol.setCellValueFactory(new PropertyValueFactory<BasicReportResponse, String>("subscriptions"));
		renewalsCol.setCellValueFactory(new PropertyValueFactory<BasicReportResponse, String>("renewals"));
		viewsCol.setCellValueFactory(new PropertyValueFactory<BasicReportResponse, String>("views"));
		downloadsCol.setCellValueFactory(new PropertyValueFactory<BasicReportResponse, String>("downloads"));

		try {
			Table.getSelectionModel().selectedIndexProperty().addListener(new rowSelectListener());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * this method loads the table with the relevant details between the picked dates of the date pickers
	 * @param event
	 */
	@FXML
	void showTableClick(ActionEvent event) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
		LocalDate localDate = LocalDate.now();
		this.event = event;
		if (toDatePicker.getValue() != null && fromDatePicker.getValue() != null) {
			LocalDate toDate = toDatePicker.getValue();
			LocalDate fromDate = fromDatePicker.getValue();
			System.out.println(localDate);
			System.out.println(toDate);
			System.out.println(fromDate);
			if (toDate.compareTo(localDate) <= 0 && fromDate.compareTo(localDate) <= 0
					&& toDate.compareTo(fromDate) >= 0) {
				ChatClient.addBasicReportListeners(this);
				ReportController.getBasicTable(fromDate, toDate);
			} else {
				HomepageBoundry.messageWindow(AlertType.ERROR, "date error", "invalid dates", "please try again");
			}
		} else {
			HomepageBoundry.messageWindow(AlertType.ERROR, "date error", "please select dates", "");
		}

	}

	/**
	 * this method returns the user to its home page 
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void ClickBtnHomePage(ActionEvent event) throws IOException {
		this.event = event;
		Loadpage("EmployeeMainArea");
	}

	/**
	 * this method returns the user to its home page 
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void backBtnClick(ActionEvent event) throws IOException {
		this.event = event;
		Loadpage("EmployeeMainArea");

	}

	/**
	 * This methods loads employee main area page with the information the boundary needs 
	 * @param page
	 * @throws IOException
	 */
	public void Loadpage(String page) throws IOException {

		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/" + page + "Interface.fxml"));
		root = loader.load();
		try {
			EmployeeMainAreaBoundry employeeMainAreaBoundry = loader.getController();
			employeeMainAreaBoundry.setEmployeeInfo(employeeName, position, id);
			if (flagWindow == 0) {
				this.window = (Stage) ((Node) event.getSource()).getScene().getWindow();
				window.setScene(new Scene(root));
				flagWindow = 1;
			}
			window.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
				public void handle(WindowEvent e) {
					try {
						UserController.logout(id);
					} catch (SQLException ex) {
						ex.printStackTrace();
					}
				}
			});
			window.show();
		} catch (Exception e) {
		}
		;
	}

	/**
	 *  this method sets the details to rows in the table of search results
	 */
	private class rowSelectListener implements ChangeListener {
		public void changed(ObservableValue arg0, Object arg1, Object arg2) {
			BasicReportResponse temp = Table.getSelectionModel().getSelectedItem();

		}
	}

	/**
	 * This method fills the table with the relevant info from the data base.
	 */
	@Override
	public void someoneAskedForBasicReport(ArrayList<Object> basicReportResponse) {
		System.out.println("someone wants basic report");
		data = FXCollections.observableArrayList();
		for (Object a : basicReportResponse) {
			data.add((BasicReportResponse) a);
			// System.out.println((BasicReportResponse)a);
		}
		Table.setItems(data);

	}

	/**
	 * This method sets the employee info for an easy transfer between system pages.
	 * @param userName
	 * @param userType
	 * @param id
	 */
	void setEmployeeInfo(String userName, String userType, String id) {
		this.id = id;
		employeeName = userName;
		position = userType;

	}
}
