package application;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import Controllers.CityController;
import Controllers.UserController;
import client.ChatClient;
import entities.ToursOfCitiesInfo;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * this class belong to the window of AddEditCity
 * @author shahar
 
 */
public class AddEditCityBoundry extends ServerEvent {

	@FXML
	private ImageView cityImg;

	@FXML
	private Label headLineLbl;

	@FXML
	private TextField txtName;

	@FXML
	private MenuButton checkManuBar;

	@FXML
	private TextArea txtDesc;

	@FXML
	private Button btnAdd;

	@FXML
	private Label lblAddTour;

	@FXML
	private Button btnBack;

	@FXML
	private Button btnEdit;

	private String cityname;

	private Parent root = null;

	private String username = null;

	private String id;

	private String permmision = null;

	private ArrayList<ToursOfCitiesInfo> a1 = new ArrayList<>();

	private ActionEvent event = null;

	@FXML
	void initialize() {
		assert headLineLbl != null : "fx:id=\"headLineLbl\" was not injected: check your FXML file 'AddEditCityInterface.fxml'.";
		assert txtName != null : "fx:id=\"txtName\" was not injected: check your FXML file 'AddEditCityInterface.fxml'.";
		assert lblAddTour != null : "fx:id=\"lblAddTour\" was not injected: check your FXML file 'AddEditCityInterface.fxml'.";
		assert checkManuBar != null : "fx:id=\"checkManuBar\" was not injected: check your FXML file 'AddEditCityInterface.fxml'.";
		assert txtDesc != null : "fx:id=\"txtDesc\" was not injected: check your FXML file 'AddEditCityInterface.fxml'.";
		assert btnAdd != null : "fx:id=\"btnAdd\" was not injected: check your FXML file 'AddEditCityInterface.fxml'.";
		assert btnBack != null : "fx:id=\"btnBack\" was not injected: check your FXML file 'AddEditCityInterface.fxml'.";
		assert btnEdit != null : "fx:id=\"btnEdit\" was not injected: check your FXML file 'AddEditCityInterface.fxml'.";

	}

	/**
	   *The setInfoAddEditCity with all those necessary parameters relevant to all the windows that call this window
	   * because that this window has two ways to be open,one for Add site and the other for Edit so this window
	   * need to know who's called him,if come to edit,the class adding it self to the list of CityInfolisteners
	   * and call a method to get the right details to the site.      
	   * @param label
	   * @param cityname
	   * @param username
	   * @param id
	   * @param permmision
	   */
	public void setInfoAddEditCity(String label, String cityname, String username, String id, String permmision) {
		headLineLbl.setText(label);
		this.cityname = cityname;
		this.id = id;
		this.permmision = permmision;
		this.username = username;
		switch (label) {
		case "Edit city":
			btnEdit.setVisible(true);
			btnAdd.setVisible(false);
			txtName.setText(cityname);
			ChatClient.addCityInfolisteners(this);//
			try {
				CityController.getCityTourDetails(cityname);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			break;
		case "Add city":
			btnAdd.setVisible(true);
			btnEdit.setVisible(false);
			lblAddTour.setVisible(false);
			checkManuBar.setVisible(false);
			break;

		}
	}

	/**
	 * This method clickbtnEdit check if the necessary fields are empty
	 * otherwise send all the updated detailed of the cite to the server
	 * @param event
	 */
	@FXML
	void clickbtnEdit(ActionEvent event) {
		this.event = event;
		if (txtName.getText().equals("") || txtDesc.getText().equals("")) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "please fill the missing fields",
					"missing city name or city description");
			return;
		}
		// need to inset cutyname not "yokneam"
		ToursOfCitiesInfo toursOfCitiesInfo = new ToursOfCitiesInfo(0, "", cityname, "", txtDesc.getText());
		ArrayList<ToursOfCitiesInfo> temp = new ArrayList<ToursOfCitiesInfo>();
		List<String> selectedItems = checkManuBar.getItems().stream()
				.filter(item -> CheckMenuItem.class.isInstance(item) && CheckMenuItem.class.cast(item).isSelected())
				.map(MenuItem::getText).collect(Collectors.toList());
		int index = 0;
		temp.add(toursOfCitiesInfo);
		for (int i = 0; i < a1.size(); i++) {
			if (index != selectedItems.size()) {
				if (a1.get(i).getSitename().equals(selectedItems.get(index))) {
					toursOfCitiesInfo = new ToursOfCitiesInfo(a1.get(i).getId(), a1.get(i).getSitename(),
							a1.get(i).getCityname(), "1", txtDesc.getText());
					temp.add(toursOfCitiesInfo);
					index++;
				}
			}
		}
		try {
			ChatClient.addTourNamesBacklisteners(this);//
			CityController.setCitiesTourInfo(temp);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	/**
	 * This method clickbtnAdd check if the necessary fields are empty
	 * otherwise send all the New detailed of the new cite to the server
	 * @param event
	 */
	@FXML
	void clickbtnAdd(ActionEvent event) {
		this.event = event;
		String cityName;
		String cityDesc;
		if (txtName.getText().equals("") || txtDesc.getText().equals("")) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "please fill the missing fields",
					"missing city name or city description");
			return;
		}
		cityName = txtName.getText();
		cityDesc = txtDesc.getText();
		ChatClient.addNewCitiesInfolisteners(this);///
		try {
			CityController.setNewCitiesInfo(cityName, cityDesc);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}


/**
 * This method clickbtnBack removes this boundary from all his listeners list if exist
 * and load the previous window back.
 * @param event
 * @throws IOException
 */
	@FXML
	void clickbtnBack(ActionEvent event) throws IOException {
		
		if (ChatClient.CityInfolisteners.contains(this)) {
			ChatClient.CityInfolisteners.remove(ChatClient.CityInfolisteners.size() - 1);
		}
		if (ChatClient.TourNamesBacklisteners.contains(this)) {
			ChatClient.TourNamesBacklisteners.remove(ChatClient.TourNamesBacklisteners.size() - 1);
		}
		if (ChatClient.NewCitiesInfolisteners.contains(this)) {
			ChatClient.NewCitiesInfolisteners.remove(ChatClient.NewCitiesInfolisteners.size() - 1);
		}
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/EmployeeMainAreaInterface.fxml"));
			root = loader.load();
			EmployeeMainAreaBoundry employeeMainAreaBoundry = loader.getController();
			employeeMainAreaBoundry.setEmployeeInfo(username, permmision, String.valueOf(id));
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(new Scene(root));
			window.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
				public void handle(WindowEvent e) {
					try {
						UserController.logout(String.valueOf(id));
					} catch (SQLException ex) {
						ex.printStackTrace();
					}
				}
			});
			window.show();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void someoneWantToUpdateTheSiteEditList(ArrayList<ToursOfCitiesInfo> arr, String desc) {
		CheckMenuItem tour;
		ArrayList<ToursOfCitiesInfo> temp = new ArrayList<>();
		temp = arr;
		a1 = arr;
		for (int i = 0; i < temp.size(); i++) {
			tour = new CheckMenuItem(temp.get(i).getSitename());
			if (temp.get(i).getRecommended().equals("1")) {
				tour.setSelected(true);
			}
			checkManuBar.getItems().add(tour);
		}
		txtDesc.setText(desc);
	}

	@Override
    public void getTourNamesBackToWin(boolean bool) {
   	 Platform.runLater(() -> {
   	 if (bool == true) {
   		 HomepageBoundry.messageWindow(AlertType.INFORMATION, "Success", "Your Request sent to system", "");
   		 try {
   			 clickbtnBack(event);
   		 } catch (IOException e) {e.printStackTrace();}
   	 } else {
   		 HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "something went wrong", "");
   	 }
   	 });
    
	}
	
	@Override
    public void getNewCitiesInfoResToWin(boolean bool) {
   	 Platform.runLater(() -> {
   	 if (bool == true) {
   		 HomepageBoundry.messageWindow(AlertType.INFORMATION, "Success", "Your Request sent to system", "");
   		 try {
   			 clickbtnBack(event);
   		 } catch (IOException e) {e.printStackTrace();}
   	 } else {
   		 HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "something went wrong",
   				 "this city name alreay exist");
   	 }
   	 });
	}
    

}
