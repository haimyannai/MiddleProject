package Controllers;

import java.util.ArrayList;

import application.HomepageBoundry;
import client.ClientConsole;
import entities.TourRequest;
import javafx.scene.control.Alert.AlertType;
/**
 * This class is responsible for every action about tours which needs info from the data base.
 * @author gilad
 *
 */
public class tourController {
	/**
	 * This method adds a new tour and its sites to the data base
	 * @param tour an array list of tour details and and array list with the sites of the tour.
	 */
    public static void addTour(TourRequest tour) {
   	 ArrayList<Object> arr = new ArrayList<>();
   	 arr.add("addTour");
   	 arr.add(tour);
   	 try {
   	 ClientConsole.client.handleMessageFromClientUI(arr);
   	 }catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","please connect to server");}
    }
    
    /**
     * This method edits an existing tour in the data base.
     * @param tour an array list of tour details and and array list with the sites of the tour.
     */
    public static void editTour(TourRequest tour) {
   	 ArrayList<Object> arr = new ArrayList<>();
   	 arr.add("editTour");
   	 arr.add(tour);
   	 try {
   	 ClientConsole.client.handleMessageFromClientUI(arr);
   	 }catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","please connect to server");}
    }
}


