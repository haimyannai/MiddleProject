package Controllers;

import java.time.LocalDate;
import java.util.ArrayList;

import client.ClientConsole;
import entities.BasicReportRequest;
/**
 * This class is responsible for every action about the report that requires info from the data base
 */
public class ReportController {

	/**
	 * This method gets all the details that needs to be shown in the table between from date and to date
	 * @param fromDate the earliest date to get data from
	 * @param toDate the latest date to get data from
	 */
	public static void getBasicTable(LocalDate fromDate, LocalDate toDate) {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("getBasicReport");
		BasicReportRequest basicReportRequest = new BasicReportRequest(fromDate, toDate);
		arr.add(basicReportRequest);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
