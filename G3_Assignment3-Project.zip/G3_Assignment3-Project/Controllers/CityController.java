package Controllers;

import java.sql.SQLException;
import java.util.ArrayList;

import application.HomepageBoundry;
import client.ClientConsole;
import entities.LoginDataRequest;
import entities.ToursOfCitiesInfo;
import javafx.scene.control.Alert.AlertType;

public class CityController {

	public CityController() {

	}

	/**
	 * imports from the DB all the catalog, and present the available one for purchase.
	 * @throws SQLException
	 */
	public static void getCityCatalogDetails() throws SQLException {

		ArrayList<Object> arr = new ArrayList<>();
		arr.add("getCatalog");
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		} catch (NullPointerException e) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "OOPS!", "Couldn't upload the catalog");
		}

	}

	/**
	 * returns the name of the collections that answers the search parameters.
	 * @param SearchInfo: list of collections.
	 * @throws SQLException
	 */
	public static void getCityCatalogAfterSearch(ArrayList<String> SearchInfo) throws SQLException {

		ArrayList<Object> arr = new ArrayList<>();
		arr.add("CityCatalogAfterSearch");
		arr.add(SearchInfo);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		} catch (Exception e) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "OOPS!", "Couldn't upload the catalog");
		}

	}

	/**
	 * This method gets all the cities from the data base to display in combo box at add edit tour page
	 */
	public static void getCities() {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("getCities");
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		} catch (Exception e) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "OOPS!", "Couldn't upload the catalog");
		}
	}
	/**
	 * This method gets all the cities from the data base to display in combo box at add edit tour page
	 * @param cityName - an array of all the city sites
	 * @param tourName - an array of all the sites in the tour
	 */

	public static void getCitySites(String cityName, String tourName) {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("getCitySites");
		arr.add(cityName);
		arr.add(tourName);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		} catch (Exception e) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "OOPS!", "Couldn't upload the catalog");
		}
	}

	/**
	 * This method gets a city name the details of tours in that city
	 * @param cityname
	 * @throws SQLException
	 */
	public static void getCityTourDetails(String cityname) throws SQLException {

		ArrayList<Object> arr = new ArrayList<>();
		arr.add("CityTourDet");
		arr.add(cityname);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		} catch (NullPointerException e) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "OOPS!", "Couldn't upload the catalog");
		}

	}

	/**
	 * This method gets a tour info and uploads it to the data base
	 * @param arr
	 * @throws SQLException
	 */
	public static void setCitiesTourInfo(ArrayList<ToursOfCitiesInfo> arr) throws SQLException {

		ArrayList<Object> arrObj = new ArrayList<>();
		arrObj.add("setCitiesTourInfo");
		arrObj.add(arr);
		try {
			ClientConsole.client.handleMessageFromClientUI(arrObj);
		} catch (NullPointerException e) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "OOPS!", "Couldn't upload the catalog");
		}

	}

	/**
	 * this method receives city name and description and upload a new city to the data base
	 * @param str
	 * @param str2
	 * @throws SQLException
	 */
	public static void setNewCitiesInfo(String str, String str2) throws SQLException {

		ArrayList<Object> arrObj = new ArrayList<>();
		arrObj.add("NewCitiesInfo");
		arrObj.add(str);
		arrObj.add(str2);
		try {
			ClientConsole.client.handleMessageFromClientUI(arrObj);
		} catch (NullPointerException e) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "OOPS!", "Couldn't upload the catalog");
		}
	}

	/**
	 * This method gets a city name and updates the views of the map collection of the city
	 * @param city
	 * @throws SQLException
	 */
	public static void UpdateColectionViews(String city) throws SQLException {
		      	 
		 ArrayList<Object> arrObj = new ArrayList<>();
		 arrObj.add("UpdateColectionViews");
		 arrObj.add(city);
		 try {
			 ClientConsole.client.handleMessageFromClientUI(arrObj);
		 }catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","Couldn't upload the catalog");}

	}
}