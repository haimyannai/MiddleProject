package Controllers;

import java.sql.SQLException;
import java.util.ArrayList;

import application.HomepageBoundry;
import client.ClientConsole;
import javafx.scene.control.Alert.AlertType;
/**
 * This class is responsible for every action a manager does referring the data base.
 */
public class ManagerController {

	public ManagerController() {}
	/**
     * this methods changes the price of the wanted collection in DB
     * @param CollectionID
     * @param price
     */
	public static void SetNewCollectionPrice(String CollectionID, String price) {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("ManagerSetNewPrice");
		arr.add(CollectionID);
		arr.add(price);
		try {
		ClientConsole.client.handleMessageFromClientUI(arr);
		}catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","please connect to server");}
	}
	
	/**
	 * ask the server to return all the new map change requests.
	 */
	public static void getVersionUpdateRequestList() {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("CollectionPriceUpdateRequest");
		try {
		ClientConsole.client.handleMessageFromClientUI(arr);
		}catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","please connect to server");}
	}
	
	/**
	 * ask the server to denied this requests.
	 * @param id:the request id.
	 */
	public static void setDeniedRequest(String id) {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("DeniedRequest");
		arr.add(id);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		}catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","please connect to server");}
	}
	 /**
	  * allowed the 'content manager' employee to send a request to change the collection price. 
	  * @param collectionID: the collection id.
	  * @param price: the new price.
	  * @param user: the employee user name.
	  */
	public static void SetNewPriceChangeRequest(String collectionID,String price,String user) {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("SetNewPriceChangeRequest");
		arr.add(collectionID);
		arr.add(price);
		arr.add(user);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		}catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","please connect to server");}
	}
	
	
	/**
	 * asking the DB to return all the edit map request to the 'content manager' interface.
	 */
	public static void UploadEditMapRequests() {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("UploadEditMapRequests");
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		}catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","please connect to server");}
	}
	
	/**
	 * allowed the 'content manager' to approve a new map version and make is available for purchase.
	 * @param mapname: the map name.
	 * @param mapVersion: the new desire version.
	 * @throws SQLException
	 */
	public static void SetNewMapVersion(String mapname,String mapVersion) throws SQLException {
		
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("SetNewMapVersion");
		arr.add(mapname);
		arr.add(mapVersion);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		}catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","Couldn't upload the catalog");}
	}
	
	/**
	 * allowed the 'content manager' to denied request.
	 * @param mapname: the map name.
	 * @param mapVersion: the new desire version.
	 * @throws SQLException
	 */
	public static void DeniedMapVersion(String mapname,String mapVersion) throws SQLException {
		
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("DeniedMapVersion");
		arr.add(mapname);
		arr.add(mapVersion);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		}catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","Couldn't upload the catalog");}
	}
	
	/**
	 * this method sends to mySQL the table to delete from and the item to delete
	 * @param table
	 * @param toDel
	 */
	public static void deleteRow(String table,Object toDel) {
	   	 ArrayList<Object> arr = new ArrayList<>();
	   	 arr.add("deleteRow");
	   	 arr.add(table);
	   	 arr.add(toDel);
	   	 try {
	   		 ClientConsole.client.handleMessageFromClientUI(arr);
	   	 }catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","Couldn't upload the catalog");}
	    }

}
