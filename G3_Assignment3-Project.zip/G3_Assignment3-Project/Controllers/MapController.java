package Controllers;

import java.sql.SQLException;
import java.util.ArrayList;

import application.HomepageBoundry;
import client.ClientConsole;
import javafx.scene.control.Alert.AlertType;
/**
 * This class is responsible for each action about a map inforamation that requires the database. 
 */
public class MapController {
	
	/**
	 * This method gets a map name and gets all the relevant info of this map from the data base
	 * @param mapName
	 */
	public static void getMapInfo(String mapName) {

		ArrayList<Object> command = new ArrayList<>();
		command.add("getMapDetails");
		command.add(mapName);
		try {
			ClientConsole.client.handleMessageFromClientUI(command);
		} catch (NullPointerException e) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "OOPS!", "please connect to server");
		}
	}

    /**
     * This method gets all the relevant info of a created map and updates the database with it
     * map name
     * description
     * city name
     * arrayList<String> sites
     * ArrayList<String> tours
     * original map name
     * @param info
     */
	public static void saveMapInfoToDB(String mapName,String originalMapName, String description, String cityName,ArrayList<String> sites,ArrayList<String> tours) {
		ArrayList<Object> command = new ArrayList<>();
		command.add("saveMapInfoToDB");
		command.add(mapName);
		command.add(description);
		command.add(cityName);
		command.add(sites);
		command.add(tours);
		command.add(originalMapName);
		try {
			ClientConsole.client.handleMessageFromClientUI(command);
		} catch (NullPointerException e) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "OOPS!", "please connect to server");
		}
	}

	/**
	 * This method gets all the relevant info of a created map and insert a new map to the database with it
	 * @param mapName
	 * @param description
	 * @param cityName
	 * @param sites
	 * @param tours
	 * @param mapPic
	 */
	public static void insertNewMap(String mapName, String description, String cityName, ArrayList<String> sites,
			ArrayList<String> tours,String mapPic) {
		ArrayList<Object> command = new ArrayList<>();
		command.add("insertNewMap");
		command.add(mapName);
		command.add(description);
		command.add(cityName);
		command.add(sites);
		command.add(tours);
		command.add(mapPic);
		try {
			ClientConsole.client.handleMessageFromClientUI(command);
		} catch (NullPointerException e) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "OOPS!", "please connect to server");
		}
	}

	/**
	 * This method getting data about cities, sites,tours,maps and users for the main employee area from the data base.
	 */
	public static void getData() {
		ArrayList<Object> command = new ArrayList<>();
		command.add("getData");
		try {
			ClientConsole.client.handleMessageFromClientUI(command);
		} catch (NullPointerException e) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "OOPS!", "please connect to server");
		}
	}

    /**
     * this function get the the name of the maps of the relevant city and ask for
     * the map collection page
     */
	public static void getCityMapCollectionNames(String mapname) throws SQLException {

		ArrayList<Object> arr = new ArrayList<>();
		arr.add("mapsCollection");
		arr.add(mapname);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		} catch (NullPointerException e) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "OOPS!", "Couldn't upload the catalog");
		}

	}

    /**
     * this function get the selected map name from the user and ask for the map
     * image
     */
	public static void getCityMapImage(String mapname) throws SQLException {

		ArrayList<Object> arr = new ArrayList<>();
		arr.add("mapImage");
		arr.add(mapname);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		} catch (NullPointerException e) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "OOPS!", "Couldn't upload the catalog");
		}

	}

    /**
     * this function get the selected map name from the user and ask for the map
     * image
     */
	public static void getCityMapImageRegullar(String mapname) throws SQLException {

		ArrayList<Object> arr = new ArrayList<>();
		arr.add("mapImageRegullar");
		arr.add(mapname);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		} catch (NullPointerException e) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "OOPS!", "Couldn't upload the catalog");
		}

	}

    /**
     * this function update the map status when the content employee press on back
     * button
     */
	public static void updateStatusMap(String mapname) throws SQLException {

		ArrayList<Object> arr = new ArrayList<>();
		arr.add("updateStatus");
		arr.add(mapname);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		} catch (NullPointerException e) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "OOPS!", "Couldn't upload the catalog");
		}

	}
	/**
	 * This method adds the info to the manager request list
	 * @param obj
	 * @throws SQLException
	 */
	public static void setEditInfoToManger(ArrayList<Object> obj) throws SQLException {
		
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("EditInfoToManger");
		arr.add(obj);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		}catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","Couldn't upload the catalog");}
	
	}


	/**
	 *asking for get maps details for the showing maps page
	 * @throws SQLException
	 */
	public static void getDetailsMapRegullarEmployee() throws SQLException {
		
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("getMapDetailsRegullar");
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		}catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","Couldn't upload the catalog");}
	}
	
	
	/**
	 *asking server for map collection for client
	 * @param catalogID
	 * @throws SQLException
	 */
	public static void getMapCollectionForClient(String catalogID) throws SQLException {
		
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("getMapCollectionClient");
		arr.add(catalogID);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		}catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","Couldn't upload the catalog");}
	}

	/**
	 *asking server for update the status of the map img
	 * @param mapName
	 * @throws SQLException
	 */
	public static void getMapCollectionExit(String mapName) throws SQLException {
		
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("setStatusForExit");
		arr.add(mapName);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		}catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","Couldn't upload the catalog");}
	}

	/**
	 * This method returns all the map names from the database
	 */
	public static void getMapsNames() {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("getMapsNames");
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		}catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","Couldn't upload the catalog");}
	}

	/** this method asked for site details from the db*/
	public static void getsitesNames(String cityName) {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("getMapSiteForAddEditMap");
		arr.add(cityName);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		}catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","Couldn't upload the catalog");}
	}
	
	/** this method asked for site details from the data base*/
	public static void getToursNames(String cityName) {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("getMapTourForAddEditMap");
		arr.add(cityName);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		}catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","Couldn't upload the catalog");}
	}
	
	
	/**
	*  call the server to remove a temporary update in a map
	* @param mapName from edit map boundary
	*/
	public static void removeUpdate(String mapName) {
		ArrayList<Object> command = new ArrayList<>();
		command.add("removeUpdate");
		command.add(mapName);
		try {
			ClientConsole.client.handleMessageFromClientUI(command);
		} catch (NullPointerException e) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "OOPS!", "please connect to server");
		}
	}
	
	





}



