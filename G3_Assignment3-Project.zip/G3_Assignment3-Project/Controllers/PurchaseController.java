package Controllers;

import java.util.ArrayList;

import application.HomepageBoundry;
import client.ClientConsole;
import entities.CreditCardInforRequest;
import javafx.scene.control.Alert.AlertType;

public class PurchaseController {

	public PurchaseController() {}

	/**
	 * ask the server set a one time purchase record.
	 * @param CollectionID: the collection id.
	 * @param ClientID: the client id.
	 */
	public static void setOneTimePurchaseRecord(String CollectionID,String ClientID) {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("BuyOneTime");
		arr.add(ClientID);
		arr.add(CollectionID);
		try {
		ClientConsole.client.handleMessageFromClientUI(arr);
		}catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","please connect to server");}
	
	}
	
	/**
	 * ask the server to set a renewal record for this subscription.
	 * @param CollectionID: the collection id.
	 * @param ClientID: the client id.
	 * @param length: the amount of time the client wish to have the subscription for(1-6).
	 */
	public static void RenewalSubscription(String CollectionID,String ClientID,String length) {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("RenewalSubscription");
		arr.add(ClientID);
		arr.add(CollectionID);
		arr.add(length);
		try {
		ClientConsole.client.handleMessageFromClientUI(arr);
		}catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","please connect to server");}
	
	}

	/**
	 * ask the server to set a subscription record.
	 * @param CollectionID: the collection id.
	 * @param ClientID: the client id.
	 * @param length: the amount of time the client wish to have the subscription for(1-6).
	 */
	public static void setSubscriptionRecord(String CollectionID,String ClientID,String length) {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("BuySubscription");
		arr.add(ClientID);
		arr.add(CollectionID);
		arr.add(length);
		try {
		ClientConsole.client.handleMessageFromClientUI(arr);
		}catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","please connect to server");}
	
	}
	
	/**
     * ask the server to return the payment info of this user.
     * @param ID
     */
	public static void getPaymentInfo(String ID) {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("getClientPaymentInfo");
		arr.add(ID);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		}catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","please connect to server");}
	}
	
	/**
     * ask the server to insert new record of payment information.
     * @param creditCardInfo
     */
	public static void setNewPaymentInfo(CreditCardInforRequest creditCardInfo) {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("SetNewClientPaymentInfo");
		arr.add(creditCardInfo);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		}catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","please connect to server");}
	}
	
	/**
	 * ask the server to return a list of all the subscription that about to expire.
	 * @param clientID: the client id.
	 */
	public static void CheckForExpiringSubscription(String clientID) {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("CheckForExpiringSubscription");
		arr.add(clientID);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		}catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","please connect to server");}
	}

	
	
	
}
