package Controllers;

import java.util.ArrayList;

import application.HomepageBoundry;
import client.ClientConsole;
import entities.SiteInfoForEditResponse;
import javafx.scene.control.Alert.AlertType;

public class SiteController {
    
    public  SiteController() {
   	 
    }
 
    /**
     * This method getSiteInfoBackForEdit get city name and id of the site for parameters in order to get the suitable
     * details that belong to this site 
     * @param cityname
     * @param id
     */
    public static void getSiteInfoBackForEdit(String cityname,int id) {
   	 ArrayList<Object> arr = new ArrayList<>();
   	 arr.add("SiteInfoBackForEdit");
   	 arr.add(cityname);
   	 arr.add(id);
   	 try {
   	 ClientConsole.client.handleMessageFromClientUI(arr);
   	 }catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","Couldn't upload the catalog");}
    }
    
    /**
     * This method setSiteInfoFowardForEdit get siteInfoForEditResponse object that contains sites details
     * and siteID for parameters in order to update the the site.
     * @param siteInfoForEditResponse
     * @param siteID
     */
    public static void setSiteInfoFowardForEdit(SiteInfoForEditResponse siteInfoForEditResponse,int siteID) {
   	 ArrayList<Object> arr = new ArrayList<>();
   	 arr.add("SiteInfoFowardForEdit");
   	 arr.add(siteInfoForEditResponse);
   	 arr.add(siteID);
   	 try {
   	 ClientConsole.client.handleMessageFromClientUI(arr);
   	 }catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","Couldn't upload the catalog");}
    }
    
    /**
     * This method setSiteInfoFowardForAdd with the parameters that contain the new site details send to server
     * @param siteInfoForEditResponse
     * @param cityname
     */
    public static void setSiteInfoFowardForAdd(SiteInfoForEditResponse siteInfoForEditResponse,String cityname) {
   	 ArrayList<Object> arr = new ArrayList<>();
   	 arr.add("SiteInfoFowardForAdd");
   	 arr.add(siteInfoForEditResponse);
   	 arr.add(cityname);
   	 try {
   	 ClientConsole.client.handleMessageFromClientUI(arr);
   	 }catch(NullPointerException e) {HomepageBoundry.messageWindow(AlertType.ERROR, "Error","OOPS!","Couldn't upload the catalog");}
    }
}


