package Controllers;

import java.sql.SQLException;
import java.util.ArrayList;

import application.HomepageBoundry;
import client.ClientConsole;
import entities.CreditCardInforRequest;
import entities.LoginDataRequest;
import entities.RegisterDataRequest;
import javafx.scene.control.Alert.AlertType;

public class UserController {

	public UserController() {
		// TODO Auto-generated constructor stub
	}
	// name needs changing
	// get username and password,
	// call get user table and check

	/**
	 * This method check if the user name exist in the DB~ by login 
	 * @param userName
	 * @param password
	 * @throws SQLException
	 */
	public static void checkuserinDB(String userName, String password) throws SQLException {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("login");
		LoginDataRequest loginDataRequest = new LoginDataRequest(userName, password);
		arr.add(loginDataRequest);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		} catch (NullPointerException e) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "OOPS!", "please connect to server");
		}

	}

	/**
	 * This methods register a new user to the system.
	 * @param registerDataRequest
	 * @throws SQLException
	 */
	public static void registrateUser(RegisterDataRequest registerDataRequest) throws SQLException {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("registraion");
		arr.add(registerDataRequest);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		} catch (NullPointerException e) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "OOPS!", "please connect to server");
		}

	}

	/**
     * this methods ask the server to change the user credit info.
     * @param creditCardInfo
     * @throws SQLException
     */
	public static void setCreditInfo(CreditCardInforRequest creditCardInfo) throws SQLException {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("creditCardInfo");
		arr.add(creditCardInfo);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		} catch (NullPointerException e) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "OOPS!", "please connect to server");
		}

	}

	// need to add to shortge from shahr 

	/**
	 * this method logs the user out and updates the database user status
	 * @param id
	 * @throws SQLException
	 */
	public static void logout(String id) throws SQLException {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("logout");
		arr.add(id);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		} catch (NullPointerException e) {
			HomepageBoundry.messageWindow(AlertType.ERROR, "Error", "OOPS!", "please connect to server");
		}

	}

	/**
	 * This method sets client card info.
	 * @param ID
	 * @throws SQLException
	 */
	public static void setClientCardInfo(String ID) throws SQLException {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("clientCard");
		arr.add(ID);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
	}

	/**
	 * ask the server to return all the messages that belong to this client.
	 * @param ID: client id.
	 * @throws SQLException
	 */
	public static void getClientMessages(String ID) throws SQLException {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("ClientMessages");
		arr.add(ID);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
	}

	/******************** Update client info ********/
	public static void getUpdateClientInfo(String id) throws SQLException {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("getUpdateClientInfo");
		arr.add(id);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
	}

	/**
	 * This method sets new personal information from the client record
	 * @param registerDataRequest
	 * @throws SQLException
	 */
	public static void updateClientInfo(RegisterDataRequest registerDataRequest) throws SQLException {
		ArrayList<Object> arr = new ArrayList<>();
		arr.add("updateClientInfo");
		arr.add(registerDataRequest);
		try {
			ClientConsole.client.handleMessageFromClientUI(arr);
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
	}
	
	

}
