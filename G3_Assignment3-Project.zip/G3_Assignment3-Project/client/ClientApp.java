package client;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import server.*;

public class ClientApp extends Application {

	@Override
	public void start(Stage primaryStage) throws IOException{
		
		URL url = getClass().getResource("/client/ClientConnectionInterface.fxml");
		Parent pane = FXMLLoader.load( url );
		Scene scene = new Scene( pane );
		//setting the stage
		primaryStage.setScene( scene );
		primaryStage.setTitle( "my mapApp" );
		primaryStage.show();
		
	
	}

	public static void main(String[] args) {
		launch(args);	
	}
}
