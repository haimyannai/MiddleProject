package client;

import java.io.IOException;


import client.ClientConsole;
import javafx.event.ActionEvent;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Stage;


public class LogInBoundry {


    @FXML
    private Pane FirstPane;

    @FXML
    private Font x12;

    @FXML
    private TextField ServerIPtext;

    @FXML
    private Button Connectbtn;

 
	public LogInBoundry() {
		
	}
	
	@FXML
	public void ConnectToServer(ActionEvent event) throws IOException {
		if(ServerIPtext.getText().equals(""))
			ServerIPtext.setText("Please enter server IP");
	
		else {
		String [] newargs=new String[1];
		newargs[0]=ServerIPtext.getText();	
		ClientConsole.connection(newargs);
		}
		Parent RegistratiomForm = FXMLLoader.load(getClass().getResource("/application/HomePageInterface.fxml"));
    	Scene RegistratiomFormScene = new Scene(RegistratiomForm);
    	Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
    	
    	window.setScene(RegistratiomFormScene);
    	window.show();
		}
	

}
