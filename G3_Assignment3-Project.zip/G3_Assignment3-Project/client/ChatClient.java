// This file contains material supporting section 3.7 of the textbook:
// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 

package client;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import OCSF.src.ocsf.client.AbstractClient;
import application.ServerEvent;
import entities.ChatIF;
import entities.CityCatalogRespond;
import entities.ClientCardResponse;
import entities.CreditCardInfoResponse;
import entities.EditMapEmployeeRequest;
import entities.HistoryPurchaseResponse;
import entities.LoginDataResponse;
import entities.RegisterDataRequest;
import entities.RegisterDataResponse;
import entities.SiteInfoForEditResponse;
import entities.ToursOfCitiesInfo;
import entities.mapCollectionImg;
import javafx.application.Platform;

/**
 * This class overrides some of the methods defined in the abstract superclass
 * in order to give more functionality to the client.
 *
 * @author Dr Timothy C. Lethbridge
 * @author Dr Robert Lagani&egrave;
 * @author Fran&ccedil;ois B&eacute;langer
 * @version July 2000
 */
public class ChatClient extends AbstractClient {
	// Instance variables **********************************************

	/**
	 * The interface type variable. It allows the implementation of the display
	 * method in the client.
	 */
	ChatIF clientUI;
	/*************************************************************************************************/
	public static List<ServerEvent> Loginlisteners = new ArrayList<ServerEvent>();

	public static void addLoginListener(ServerEvent toAdd) {
		if (!Loginlisteners.contains(toAdd)) {
			Loginlisteners.add(toAdd);
		}
	}

	public void login(LoginDataResponse loginRes) {
		System.out.println("login!!");

		// Notify everybody that may be interested.
		for (ServerEvent hl : Loginlisteners)
			hl.someoneLoggedin(loginRes);
	}
	/*************************************************************************************************/
	public static List<ServerEvent> mapNamesListeners = new ArrayList<ServerEvent>();

	public static void addMapNamesListener(ServerEvent toAdd) {
		if (!mapNamesListeners.contains(toAdd)) {
			mapNamesListeners.add(toAdd);
		}
	}

	public void chooseMapForAdd(ArrayList<Object> mapsArray) {
		System.out.println("login!!");

		// Notify everybody that may be interested.
		for (ServerEvent hl : mapNamesListeners)
			hl.someoneAskedForMapName(mapsArray);
	}




	/*************************************************************************************************/
	public static List<ServerEvent> Registeredlisteners = new ArrayList<ServerEvent>();

	public static void addRegisterListener(ServerEvent toAdd) {
		if (!Registeredlisteners.contains(toAdd)) {
			Registeredlisteners.add(toAdd);
		}
	}

	public void register(RegisterDataResponse registerDataResponse) {
		System.out.println("register!!");

		// Notify everybody that may be interested.
		for (ServerEvent hl : Registeredlisteners)
			hl.someoneRegistered(registerDataResponse);
	}

	/*************************************************************************************************/
	public static List<ServerEvent> setCreditInfolisteners = new ArrayList<ServerEvent>();

	public static void addCreditInfolisteners(ServerEvent toAdd) {
		if (!setCreditInfolisteners.contains(toAdd)) {
			setCreditInfolisteners.add(toAdd);
		}
	}

	public void CreditInfo(CreditCardInfoResponse creditCardInfoResponse) {
		System.out.println("setCreditInfo!!");

		// Notify everybody that may be interested.
		for (ServerEvent hl : setCreditInfolisteners) {
			hl.someoneSetCreditInfo(creditCardInfoResponse);
		}
	}

	/*************************************************************************************************/

	public static List<ServerEvent> Cataloglisteners = new ArrayList<ServerEvent>();

	public void catalog(ArrayList<CityCatalogRespond> CatalogRespond) {

		for (ServerEvent hl : Cataloglisteners)
			hl.setCityCatalog(CatalogRespond);
	}

	public static void addCatalogListener(ServerEvent toAdd) {
		if (!Cataloglisteners.contains(toAdd)) {
			Cataloglisteners.add(toAdd);
		}
	}

	/*************************************************************************************************/
	public static List<ServerEvent> setClientCardinfolisteners = new ArrayList<ServerEvent>();

	public static void addCreditCardinfolisteners(ServerEvent toAdd) {
		if (!setClientCardinfolisteners.contains(toAdd)) {
			setClientCardinfolisteners.add(toAdd);
		}
	}

	public void clientCardInfo(ClientCardResponse clientCardInfo,
			ArrayList<HistoryPurchaseResponse> historyPurchaseResponse) {
		System.out.println("setClientCard!!");
		System.out.println(clientCardInfo.getEmail() + "" + clientCardInfo.getPhoneNumber());

		// Notify everybody that may be interested.
		for (ServerEvent hl : setClientCardinfolisteners) {
			hl.someoneGetClientCard(clientCardInfo);
			hl.someoneGetHistoryPurchase(historyPurchaseResponse);
		}
	}

	/*************************************************************************************************/

	public static List<ServerEvent> Purchaselistener = new ArrayList<ServerEvent>();

	public static void addPurchaselistener(ServerEvent toAdd) {
		if (!Purchaselistener.contains(toAdd)) {
			Purchaselistener.add(toAdd);
		}
	}

	public void NotifyPurchaselisteners(String purchaseRespond) {

		// Notify everybody that may be interested.
		for (ServerEvent hl : Purchaselistener)
			hl.setOneTimePurchaseRespond(purchaseRespond);
	}

	/*************************************************************************************************/

	public static List<ServerEvent> Subscriptionlistener = new ArrayList<ServerEvent>();

	public static void addSubscriptionlistener(ServerEvent toAdd) {
		if (!Subscriptionlistener.contains(toAdd)) {
			Subscriptionlistener.add(toAdd);
		}
	}

	public void NotifySubscriptionlistener(String SubscriptionRespond) {

		// Notify everybody that may be interested.
		for (ServerEvent hl : Subscriptionlistener)
			hl.setSubscriptionRespond(SubscriptionRespond);
	}

	/*************************************************************************************************/

	public static List<ServerEvent> CatalogAfterSearchlistener = new ArrayList<ServerEvent>();

	public static void addSCatalogAfterSearchlistener(ServerEvent toAdd) {
		if (!CatalogAfterSearchlistener.contains(toAdd)) {
			CatalogAfterSearchlistener.add(toAdd);
		}
	}

	public void CityCatalogAfterSearch(ArrayList<Object> NewCatalog) {
		// Notify everybody that may be interested.
		System.out.println(NewCatalog.toString());
		for (ServerEvent hl : CatalogAfterSearchlistener) {
			hl.CityListAfterSearch(NewCatalog);
		}
	}

	/*************************************************************************************************/
	public static List<ServerEvent> ClientPaymentMethodlistener = new ArrayList<ServerEvent>();

	public static void addClientPaymentlistener(ServerEvent toAdd) {
		if (!ClientPaymentMethodlistener.contains(toAdd)) {
			ClientPaymentMethodlistener.add(toAdd);
		}
	}

	public void presentPaymentInfo(ArrayList<Object> paymentInfo) {
		// Notify everybody that may be interested.
		for (ServerEvent hl : ClientPaymentMethodlistener) {
			hl.returnPaymentInfo(paymentInfo);
		}
	}

	/*************************************************************************************************/
	public static List<ServerEvent> SetNewPaymentInfolistener = new ArrayList<ServerEvent>();

	public static void addNewPaymentInfolistener(ServerEvent toAdd) {
		if (!SetNewPaymentInfolistener.contains(toAdd)) {
			SetNewPaymentInfolistener.add(toAdd);
		}
	}

	public void SetNewPaymentInfo(boolean result) {
		// Notify everybody that may be interested.
		for (ServerEvent hl : SetNewPaymentInfolistener) {
			hl.SetNewPaymentInfoResult(result);
		}
	}

	/*************************************************************************************************/
	public static List<ServerEvent> SetNewPricelistener = new ArrayList<ServerEvent>();

	public static void AddSetNewPricelistener(ServerEvent toAdd) {
		if (!SetNewPricelistener.contains(toAdd)) {
			SetNewPricelistener.add(toAdd);
		}
	}

	public void SetNewPriceresult(boolean result) {
		// Notify everybody that may be interested.
		System.out.println("in th lisner " + result);
		for (ServerEvent hl : SetNewPricelistener) {
			hl.returnSetNewPriceResult(result);
		}
	}

	/*************************************************************************************************/
	public static List<ServerEvent> SetVersionListlistener = new ArrayList<ServerEvent>();

	public static void AddVersionListlistener(ServerEvent toAdd) {
		if (!SetVersionListlistener.contains(toAdd)) {
			SetVersionListlistener.add(toAdd);
		}
	}

	public void SetUpdateRequestTable(ArrayList<Object> result) {
		// Notify everybody that may be interested.
		for (ServerEvent hl : SetVersionListlistener) {
			hl.SetCollectionPriceUpdateRequestTable(result);
		}
	}

	/*************************************************************************************************/

	public static List<ServerEvent> setBasicReportListeners = new ArrayList<ServerEvent>();

	public static void addBasicReportListeners(ServerEvent toAdd) {
		if (!setBasicReportListeners.contains(toAdd)) {
			setBasicReportListeners.add(toAdd);
		}
	}

	public void BasicReport(ArrayList<Object> basicReportResponse) {
		System.out.println("setBasicReport!");
		basicReportResponse.remove(0);
		for (ServerEvent hl : setBasicReportListeners)
			hl.someoneAskedForBasicReport(basicReportResponse);
	}

	/*************************************************************************************************/

	public static List<ServerEvent> ExpListener = new ArrayList<ServerEvent>();

	public static void AddExpListener(ServerEvent toAdd) {
		if (!ExpListener.contains(toAdd)) {
			ExpListener.add(toAdd);
		}
	}

	public void sendexpMassages(ArrayList<Object> result) {
		// Notify everybody that may be interested.
		System.out.println("in th lisner " + result);
		for (ServerEvent hl : ExpListener) {
			hl.presentexpSubscriptions(result);
		}
	}

	/*************************************************************************************************/
	public static List<ServerEvent> RenewalListener = new ArrayList<ServerEvent>();

	public static void AddRenewalListener(ServerEvent toAdd) {
		if (!RenewalListener.contains(toAdd)) {
			RenewalListener.add(toAdd);
		}
	}

	public void sendRenewalMassages(String result) {
		// Notify everybody that may be interested.
		System.out.println("in th lisner " + result);
		for (ServerEvent hl : RenewalListener) {
			hl.Renewalmsg(result);
		}
	}

	/*************************************************************************************************/
	public static List<ServerEvent> DeinedListener = new ArrayList<ServerEvent>();

	public static void AddDeinedListenerr(ServerEvent toAdd) {
		if (!DeinedListener.contains(toAdd)) {
			DeinedListener.add(toAdd);
		}
	}

	public void DeinedRequestAnswer(boolean result) {
		// Notify everybody that may be interested.
		System.out.println("in th lisner " + result);
		for (ServerEvent hl : DeinedListener) {
			hl.DeinedRequestAnswer(result);
		}
	}

	/*************************************************************************************************/
	public static List<ServerEvent> getDataListener = new ArrayList<ServerEvent>();

	public static void getDataListeners(ServerEvent toAdd) {
		if (!getDataListener.contains(toAdd)) {
			getDataListener.add(toAdd);
		}
	}

	public void getData(ArrayList<Object> result) {
		for (ServerEvent hl : getDataListener) {
			hl.someoneGetData(result);
		}
	}

	/*************************************************************************************************/
	public static List<ServerEvent> EditMapRequestListener = new ArrayList<ServerEvent>();

	public static void addEditMapRequestListener(ServerEvent toAdd) {
		if (!EditMapRequestListener.contains(toAdd)) {
			EditMapRequestListener.add(toAdd);
		}
	}

	public void returnEditMapRequest(ArrayList<Object> result) {
		for (ServerEvent hl : EditMapRequestListener) {
			hl.setEditMapRequests(result);
		}
	}

	/*************************************************************************************************/
	public static List<ServerEvent> getCitiesListener = new ArrayList<ServerEvent>();

	public static void getCitiesListeners(ServerEvent toAdd) {
		if (!getCitiesListener.contains(toAdd)) {
			getCitiesListener.add(toAdd);
		}
	}

	public void getCities(ArrayList<Object> result) {
		for (ServerEvent hl : getCitiesListener) {
			hl.someoneGetCities(result);
		}
	}

	/*************************************************************************************************/
	public static List<ServerEvent> getCitySitesListener = new ArrayList<ServerEvent>();

	public static void getCitySitesListeners(ServerEvent toAdd) {
		if (!getCitySitesListener.contains(toAdd)) {
			getCitySitesListener.add(toAdd);
		}
	}

	public void getCitySites(ArrayList<Object> result) {
		for (ServerEvent hl : getCitySitesListener) {
			hl.someoneGetCitySites(result);
		}
	}

	/*************************************************************************************************/

//map boundry

	public static List<ServerEvent> mapImagelisteners = new ArrayList<ServerEvent>();

	public static void addmapImagelisteners(ServerEvent toAdd) {
		if (!mapImagelisteners.contains(toAdd)) {
			mapImagelisteners.add(toAdd);
		}
	}

	public void mapImage(Object mapImage, ArrayList<EditMapEmployeeRequest> arr) {
		// Notify everybody that may be interested.
		for (ServerEvent hl : mapImagelisteners)
			hl.someoneGetmapImagelisteners(mapImage, arr);
	}

	/********************************************************************/

	public static List<ServerEvent> EditInfoToMangerReqlisteners = new ArrayList<ServerEvent>();

	public static void addEditInfoToMangerReqlisteners(ServerEvent toAdd) {
		if (!EditInfoToMangerReqlisteners.contains(toAdd)) {
			EditInfoToMangerReqlisteners.add(toAdd);
		}
	}

	public void EditInfoToMangerReq(boolean update1, boolean update2) {
		// Notify everybody that may be interested.
		for (ServerEvent hl : mapImagelisteners)
			hl.someoneWantToUpdateTheSiteEditList(update1, update2);
	}

	/********************************************************************/
	public static List<ServerEvent> ShowDetailsForRegullarEmployee = new ArrayList<ServerEvent>();

	public static void AddMapDetailsListeners(ServerEvent toAdd) {
		if (!ShowDetailsForRegullarEmployee.contains(toAdd)) {
			ShowDetailsForRegullarEmployee.add(toAdd);
		}
	}

	public void mapRegullarCmbLst(ArrayList<String> arrMap, ArrayList<EditMapEmployeeRequest> arrSite) {
		for (ServerEvent hl : ShowDetailsForRegullarEmployee)
			hl.someoneGetMapsNameCollectoin(arrMap, arrSite);
	}

	public void mapImageLoadRegullar(Object mapImage) {
		// Notify everybody that may be interested.
		for (ServerEvent hl : mapImagelisteners)
			hl.RegullarEmployeeWantPhoto(mapImage);
	}

	/********************************************************************/
	public static List<ServerEvent> CityInfolisteners = new ArrayList<ServerEvent>();

	public static void addCityInfolisteners(ServerEvent toAdd) {
		if (!CityInfolisteners.contains(toAdd)) {
			CityInfolisteners.add(toAdd);
		}
	}

	public void getCityInfolisteners(ArrayList<ToursOfCitiesInfo> arr, String desc) {
		// Notify everybody that may be interested.
		for (ServerEvent hl : CityInfolisteners)
			hl.someoneWantToUpdateTheSiteEditList(arr, desc);
	}

	/*********************************************************************/
	public static List<ServerEvent> TourNamesBacklisteners = new ArrayList<ServerEvent>();

	public static void addTourNamesBacklisteners(ServerEvent toAdd) {
		if (!TourNamesBacklisteners.contains(toAdd)) {
			TourNamesBacklisteners.add(toAdd);
		}
	}

	public void getTourNamesBack(boolean bool) {
		// Notify everybody that may be interested.
		for (ServerEvent hl : CityInfolisteners)
			hl.getTourNamesBackToWin(bool);
	}

	/*********************************************************************/
	public static List<ServerEvent> NewCitiesInfolisteners = new ArrayList<ServerEvent>();

	public static void addNewCitiesInfolisteners(ServerEvent toAdd) {
		if (!NewCitiesInfolisteners.contains(toAdd)) {
			NewCitiesInfolisteners.add(toAdd);
		}
	}

	public void getNewCitiesInfoRes(boolean bool) {
// Notify everybody that may be interested.
		for (ServerEvent hl : NewCitiesInfolisteners)
			hl.getNewCitiesInfoResToWin(bool);
	}

	/*********************************************************************
	 * All what shahar did to site
	 */
	public static List<ServerEvent> getSiteInfoBackToWinEditlisteners = new ArrayList<ServerEvent>();

	public static void addSiteInfoToWinlisteners(ServerEvent toAdd) {
		if (!getSiteInfoBackToWinEditlisteners.contains(toAdd)) {
			getSiteInfoBackToWinEditlisteners.add(toAdd);
		}
	}

	public void getSiteInfoBackForEdit(ArrayList<SiteInfoForEditResponse> arr) {
// Notify everybody that may be interested.
		for (ServerEvent hl : getSiteInfoBackToWinEditlisteners)
			hl.getSiteInfoBackForEdit(arr);
	}

	/*********************************************************************/

	public static List<ServerEvent> SiteInfoFowardForEditRes = new ArrayList<ServerEvent>();

	public static void addSiteInfoFowardForEditRes(ServerEvent toAdd) {
		if (!SiteInfoFowardForEditRes.contains(toAdd)) {
			SiteInfoFowardForEditRes.add(toAdd);
		}
	}

	public void getSiteInfoBackForEdit(boolean bool) {
// Notify everybody that may be interested.
		for (ServerEvent hl : getSiteInfoBackToWinEditlisteners)
			hl.getSiteInfoBackForEdit(bool);
	}

	/*********************************************************************/

	public static List<ServerEvent> SiteInfoFowardForAddRes = new ArrayList<ServerEvent>();

	public static void addSiteInfoFowardForAddRes(ServerEvent toAdd) {
		if (!SiteInfoFowardForAddRes.contains(toAdd)) {
			SiteInfoFowardForAddRes.add(toAdd);
		}
	}

	public void getSiteInfoFowardForAddRes(boolean bool) {
// Notify everybody that may be interested.
		for (ServerEvent hl : SiteInfoFowardForAddRes)
			hl.getSiteInfoFowardForAddRes(bool);
	}

	/*********************************************************************/
	public static List<ServerEvent> NewMapVersionlisner = new ArrayList<ServerEvent>();

	public static void addNewMapVersion(ServerEvent toAdd) {
		if (!NewMapVersionlisner.contains(toAdd)) {
			NewMapVersionlisner.add(toAdd);
		}
	}

	public void SetNewMapUpdateRespond(String respond) {
// Notify everybody that may be interested.
		for (ServerEvent hl : NewMapVersionlisner)
			hl.SetNewMapUpdateRespond(respond);
	}

	/*********************************************************************/
	public static List<ServerEvent> DeniedNewMapVersionlisner = new ArrayList<ServerEvent>();

	public static void addDeniedNewMapVersion(ServerEvent toAdd) {
		if (!DeniedNewMapVersionlisner.contains(toAdd)) {
			DeniedNewMapVersionlisner.add(toAdd);
		}
	}

	public void SetDeniedNewMapVersionRespond(boolean respond) {
// Notify everybody that may be interested.
		for (ServerEvent hl : DeniedNewMapVersionlisner)
			hl.SetDeniedNewMapVersionRespond(respond);
	}

	/*********************************************************************/

	public static List<ServerEvent> Messageslisner = new ArrayList<ServerEvent>();

	public static void addMessageslisner(ServerEvent toAdd) {
		if (!DeniedNewMapVersionlisner.contains(toAdd)) {
			DeniedNewMapVersionlisner.add(toAdd);
		}
	}

	public void SetClientMessages(ArrayList<Object> respond) {
// Notify everybody that may be interested.
		for (ServerEvent hl : DeniedNewMapVersionlisner)
			hl.SetClientMessagesList(respond);
	}

	/*********************************************************************/

	public static List<ServerEvent> clientGetImagesCollectionListener = new ArrayList<ServerEvent>();

	public static void addclientGetImagesCollection(ServerEvent toAdd) {
		if (!clientGetImagesCollectionListener.contains(toAdd)) {
			clientGetImagesCollectionListener.add(toAdd);
		}
	}

	public void clientWantsHisMapCollection(ArrayList<mapCollectionImg> arr) {
// Notify everybody that may be interested.
		for (ServerEvent hl : clientGetImagesCollectionListener)
			hl.someoneGetMapCollectionCleint(arr);
	}

	/*********************************************************************/
	public static List<ServerEvent> UpdateClientInfolisteners = new ArrayList<ServerEvent>();

	public static void addUpdateClientInfolisteners(ServerEvent toAdd) {
		if (!UpdateClientInfolisteners.contains(toAdd)) {
			UpdateClientInfolisteners.add(toAdd);
		}
	}

	public void GetUpdateClientInfo(boolean res) {
		System.out.println("register!!");

		// Notify everybody that may be interested.
		for (ServerEvent hl : UpdateClientInfolisteners)
			hl.someoneUpdateHisInfo(res);
	}

	/******************************************************************************/
	public static List<ServerEvent> getUpdateClientInfolisteners = new ArrayList<ServerEvent>();

	public static void addgetUpdateClientInfolisteners(ServerEvent toAdd) {
		if (!getUpdateClientInfolisteners.contains(toAdd)) {
			getUpdateClientInfolisteners.add(toAdd);
		}
	}

	public void GetClientInfo(RegisterDataRequest registerDataRequest) {
		System.out.println("register!!");
		// Notify everybody that may be interested.
		for (ServerEvent hl : getUpdateClientInfolisteners)
			hl.getUpdateClientInfo(registerDataRequest);
	}

	/*************************************************************************************************/
	public static List<ServerEvent> saveNewMapInfoToDBListener = new ArrayList<ServerEvent>();

	public static void AddSaveNewMapInfolistener(ServerEvent toAdd) {
		if (!saveNewMapInfoToDBListener.contains(toAdd)) {
			saveNewMapInfoToDBListener.add(toAdd);
		}
	}

	public void setEditMapRespond(String result) {
		// Notify everybody that may be interested.
		System.out.println("in the lisner " + result);
		for (ServerEvent hl : saveNewMapInfoToDBListener) {
			hl.nextConfirmation(result);
		}
	}

	/*************************************************************************************************/
	public static List<ServerEvent> saveNewMapListener = new ArrayList<ServerEvent>();

	public static void AddSaveNewMaplistener(ServerEvent toAdd) {
		if (!saveNewMapListener.contains(toAdd)) {
			saveNewMapListener.add(toAdd);
		}
	}

	public void saveNewMap(String result) {
		// Notify everybody that may be interested.
		System.out.println("in the lisner " + result);
		for (ServerEvent hl : saveNewMapListener) {
			hl.saveNewConfirmation(result);
		}
	}
	/*************************************************************************************************/
	public static List<ServerEvent> getMapInfoListener = new ArrayList<ServerEvent>();

	public static void AddgetMapInfolistener(ServerEvent toAdd) {
		if (!getMapInfoListener.contains(toAdd)) {
			getMapInfoListener.add(toAdd);
		}
	}

	public void getMapInfo(ArrayList<Object> result) {
		// Notify everybody that may be interested.
		System.out.println("in th lisner " + result);
		for (ServerEvent hl : getMapInfoListener) {
			hl.getMapDetails(result);
		}
	}
	/**********************For AddEditMap to upload Sitecombox********************************************************/
	public static List<ServerEvent> getMapSitesInfoListener = new ArrayList<ServerEvent>();

	public static void AddgetMapSitesInfo(ServerEvent toAdd) {
		if (!getMapSitesInfoListener.contains(toAdd)) {
			getMapSitesInfoListener.add(toAdd);
		}
	}

	public void getMapInfoSite(ArrayList<Object> result) {
		// Notify everybody that may be interested.
		System.out.println("in th lisner " + result);
		for (ServerEvent hl : getMapSitesInfoListener) {
			hl.getMapSiteDetails(result);
		}
	}
	
	/**********************For AddEditMap to upload Tourcombox********************************************************/
	public static List<ServerEvent> getMapTourInfoListener = new ArrayList<ServerEvent>();

	public static void AddgetMapTourtsInfo(ServerEvent toAdd) {
		if (!getMapTourInfoListener.contains(toAdd)) {
			getMapTourInfoListener.add(toAdd);
		}
	}

	public void getMapInfoTour(ArrayList<Object> result) {
		// Notify everybody that may be interested.
		System.out.println("in th lisner " + result);
		for (ServerEvent hl : getMapTourInfoListener) {
			hl.getMapTourDetails(result);
		}
	}
	/*************************************************************************************************/


	
	
	

	// Constructors ****************************************************

	/**
	 * Constructs an instance of the chat client.
	 *
	 * @param host     The server to connect to.
	 * @param port     The port number to connect on.
	 * @param clientUI The interface type variable.
	 */

	public ChatClient(String host, int port, ChatIF clientUI) throws IOException {
		super(host, port); // Call the superclass constructor
		this.clientUI = clientUI;
		openConnection();
	}

	// Instance methods ************************************************

	/**
	 * This method handles all data that comes in from the server.
	 * handles listeners management according to the switch option 
	 * @param msg The message from the server.
	 */
	public void handleMessageFromServer(Object msg) {
		ArrayList<Object> arr = (ArrayList<Object>) msg;

		switch ((String) arr.get(0)) {
		case "login":
			Platform.runLater(() -> {
				this.login((LoginDataResponse) arr.get(1));
			});
			break;
		case "register":
			Platform.runLater(() -> {
				this.register((RegisterDataResponse) arr.get(1));
			});
			break;
		case "creditCard":
			Platform.runLater(() -> {
				this.CreditInfo((CreditCardInfoResponse) arr.get(1));
			});
			break;
		case "logout":
			Platform.runLater(() -> {
				if ((boolean) arr.get(1))
					System.out.println("client logged out suuccessfully");
			});
			break;
		case "clientCard":
			Platform.runLater(() -> {
				this.clientCardInfo((ClientCardResponse) arr.get(1), (ArrayList<HistoryPurchaseResponse>) arr.get(2));
			});
			break;
		case "getCatalog":
			Platform.runLater(() -> {
				this.catalog((ArrayList<CityCatalogRespond>) arr.get(1));
			});
			break;
		case "purchaseOneTimeResult":
			Platform.runLater(() -> {
				this.NotifyPurchaselisteners((String) arr.get(1));
			});
			break;
		case "BuySubscriptionRespond":
			Platform.runLater(() -> {
				this.NotifySubscriptionlistener((String) arr.get(1));
			});
			break;
		case "CityCatalogAfterSearch":
			Platform.runLater(() -> {
				this.CityCatalogAfterSearch(arr);
			});
			break;
		case "ClientPaymentInfo":
			Platform.runLater(() -> {
				this.presentPaymentInfo(arr);
			});
			break;

		case "setnewClientPaymentInfoAnswer":
			Platform.runLater(() -> {
				this.SetNewPaymentInfo((boolean) arr.get(1));
			});
			break;

		case "ManagerSetNewPrice":
			Platform.runLater(() -> {
				this.SetNewPriceresult((boolean) arr.get(1));
			});
			break;
		case "CollectionPriceUpdateRequest":
			Platform.runLater(() -> {
				this.SetUpdateRequestTable(arr);
			});
			break;
		case "BasicReport":
			Platform.runLater(() -> {
				this.BasicReport(arr);
			});
			break;
		case "ExpiringSubscription":
			Platform.runLater(() -> {
				this.sendexpMassages(arr);
			});
			break;
		case "RenewalSubscriptionRespond":
			Platform.runLater(() -> {
				this.sendRenewalMassages((String) arr.get(1));
			});
			break;
		case "DeniedRequest":
			Platform.runLater(() -> {
				this.DeinedRequestAnswer((boolean) arr.get(1));
			});
			break;
		case "SetNewPriceRequest":
			Platform.runLater(() -> {
				this.SetNewPriceresult((boolean) arr.get(1));
			});
			break;
		case "getData":
			Platform.runLater(() -> {
				this.getData(arr);
			});
			break;
		case "EditMapRequests":
			Platform.runLater(() -> {
				this.returnEditMapRequest(arr);
			});
			break;
		case "getCities":
			Platform.runLater(() -> {
				this.getCities(arr);
			});
			break;
		case "mapImage":
			Platform.runLater(() -> {
				this.mapImage((Object) arr.get(1), (ArrayList<EditMapEmployeeRequest>) arr.get(2));
			});
			break;
		case "EditInfoToMangerReq":
			Platform.runLater(() -> {
				this.EditInfoToMangerReq((Boolean) arr.get(1), (Boolean) arr.get(2));
			});
			break;
		case "mapCollectionnames":
			Platform.runLater(() -> {
				this.mapRegullarCmbLst((ArrayList<String>) arr.get(1), (ArrayList<EditMapEmployeeRequest>) arr.get(2));
			});
			break;
		case "mapImageRegullar":
			Platform.runLater(() -> {
				this.mapImageLoadRegullar((Object) arr.get(1));
			});
			break;
		case "getTourNames":
			Platform.runLater(() -> {
				// arr.remove(0);
				this.getCityInfolisteners((ArrayList<ToursOfCitiesInfo>) arr.get(1), (String) arr.get(2));
				;
			});
			break;
		case "getTourNamesBack":
			Platform.runLater(() -> {
				this.getTourNamesBack((Boolean) arr.get(1));
			});
			break;
		case "getNewCitiesInfoRes":
			Platform.runLater(() -> {
				this.getNewCitiesInfoRes((Boolean) arr.get(1));
			});
			break;
		case "getSiteInfoBackForEdit":
			Platform.runLater(() -> {
				this.getSiteInfoBackForEdit((ArrayList<SiteInfoForEditResponse>) arr.get(1));
			});
			break;
		case "SiteInfoFowardForEditRes":
			Platform.runLater(() -> {
				this.getSiteInfoBackForEdit((Boolean) arr.get(1));
			});
			break;
		case "setSiteInfoFowardForAddRes":
			Platform.runLater(() -> {
				this.getSiteInfoFowardForAddRes((Boolean) arr.get(1));
			});
			break;
		case "SetNewMapVersion":
			Platform.runLater(() -> {
				this.SetNewMapUpdateRespond((String) arr.get(1));
			});
			break;
		case "DeniedNewMapVersion":
			Platform.runLater(() -> {
				this.SetDeniedNewMapVersionRespond((boolean) arr.get(1));
			});
			break;
		case "ClientMessages":
			Platform.runLater(() -> {
				this.SetClientMessages(arr);
			});
			break;
		case "getCollectionImgMapClient":
			Platform.runLater(() -> {
				this.clientWantsHisMapCollection((ArrayList<mapCollectionImg>) arr.get(1));
			});
			break;
		case "getCitySites":
			Platform.runLater(() -> {
				this.getCitySites(arr);
			});
			break;
		case "updateClientInfoRes":
			Platform.runLater(() -> {
				this.GetUpdateClientInfo((Boolean) arr.get(1));
			});
			break;
		case "getUpdateClientInfoBack":
			Platform.runLater(() -> {
				this.GetClientInfo((RegisterDataRequest) arr.get(1));
			});
			break;
		case "getMapInfo":
			Platform.runLater(() -> {
				this.getMapInfo(arr);
			});
			break;
		case "saveNewMapInfoToDB":
			Platform.runLater(() -> {
				this.setEditMapRespond((String) arr.get(1));
			});
			break;
		case "insertNewMap":
			Platform.runLater(() -> {
				this.saveNewMap((String) arr.get(1));
			});
			break;
		case "IgotMapsName":
			Platform.runLater(() -> {
				this.chooseMapForAdd((ArrayList<Object>)arr.get(1));
			});
			break;
		case "IgotSiteName":
			Platform.runLater(() -> {
				this.getMapInfoSite((ArrayList<Object>)arr.get(1));
			});
			break;
		case "IgotTourName":
			Platform.runLater(() -> {
				this.getMapInfoTour((ArrayList<Object>)arr.get(1));
			});
			break;


		}

	}

	/**
	 * This method handles all data coming from the UI
	 *
	 * @param arr The message from the UI.
	 */
	public void handleMessageFromClientUI(ArrayList<Object> arr) {
		// prepare message to server
		try {
			sendToServer(arr);
		} catch (IOException e) {
			e.printStackTrace();
			clientUI.display("Could not send message to server.  Terminating client.");
			quit();
		}
	}

	/**
	 * This method terminates the client.
	 */
	public void quit() {
		try {
			closeConnection();
		} catch (IOException e) {
		}
		System.exit(0);
	}
}
//End of ChatClient class
