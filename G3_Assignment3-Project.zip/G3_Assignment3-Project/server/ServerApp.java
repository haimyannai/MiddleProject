package server;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;

import Controllers.MapController;
import Controllers.UserController;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class ServerApp extends Application {
public static String[] newargs;
	@Override
	public void start(Stage primaryStage) throws IOException {

		URL url = getClass().getResource("/server/ServerStartGUI.fxml");
		Parent pane = FXMLLoader.load(url);
		Scene scene = new Scene(pane);
		// setting the stage
		primaryStage.setScene(scene);
		primaryStage.setTitle("Start Server");
		primaryStage.show();
		
		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent e) {
				mysqlConnection mysql = new mysqlConnection();
				mysql.exitAllClients();
				System.exit(0);
			}
		});

	}

	public static void main(String[] args) {	
		( new mysqlConnection()).openConnection();
		newargs=args;
		launch(args);
	}
}