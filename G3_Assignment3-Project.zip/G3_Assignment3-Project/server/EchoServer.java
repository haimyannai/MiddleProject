package server;
// This file contains material supporting section 3.7 of the textbook:
// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import OCSF.src.ocsf.server.AbstractServer;
import OCSF.src.ocsf.server.ConnectionToClient;
import entities.BasicReportRequest;
import entities.CreditCardInforRequest;
import entities.LoginDataRequest;
import entities.RegisterDataRequest;
import entities.SiteInfoForEditResponse;
import entities.TourRequest;
import entities.ToursOfCitiesInfo;;

/**
 * This class overrides some of the methods in the abstract superclass in order
 * to give more functionality to the server.
 *
 * @author Dr Timothy C. Lethbridge
 * @author Dr Robert Lagani&egrave;re
 * @author Fran&ccedil;ois B&eacute;langer
 * @author Paul Holden
 * @version July 2000
 */
public class EchoServer extends AbstractServer {
	// Class variables *************************************************

	/**
	 * The default port to listen on.
	 */
	final public static int DEFAULT_PORT = 5555;

	// Constructors ****************************************************

	/**
	 * Constructs an instance of the echo server.
	 *
	 * @param port The port number to connect on.
	 */
	public EchoServer(int port) {
		super(port);
	}

	// Instance methods ************************************************

	/**
	 * This method handles any messages received from the client.
	 *
	 * @param msg    The message received from the client.
	 * @param client The connection from which the message originated.
	 */
	public void handleMessageFromClient(Object msg, ConnectionToClient client) {
		mysqlConnection mySql = new mysqlConnection();
		mySql.openConnection();
		System.out.println("Message received: " + msg + " from " + client);
		ArrayList<Object> arr = (ArrayList<Object>) msg;

		// the first val of the arraylist for what the client want to do
		switch ((String) arr.get(0)) {
		case "login":
			ArrayList<Object> loginResult = new ArrayList<Object>();
			loginResult = mySql.login((LoginDataRequest) arr.get(1));
			this.sendToClient(loginResult, client);
			break;
		case "registraion":
			ArrayList<Object> registrationResult = new ArrayList<Object>();
			registrationResult = mySql.register((RegisterDataRequest) arr.get(1));
			this.sendToClient(registrationResult, client);
			break;
		case "creditCardInfo":
			ArrayList<Object> creditCardInfoResult = new ArrayList<Object>();
			creditCardInfoResult = mySql.setCreditCardInfo((CreditCardInforRequest) arr.get(1));
			this.sendToClient(creditCardInfoResult, client);
			break;
		case "logout":
			ArrayList<Object> logoutResult = new ArrayList<Object>();
			logoutResult = mySql.logout(arr.get(1));
			this.sendToClient(logoutResult, client);
			break;
		case "getCatalog":
			ArrayList<Object> Citylist = new ArrayList<Object>();
			Citylist = mySql.BringCityCatalog();
			this.sendToClient(Citylist, client);
			break;
		case "clientCard":
			ArrayList<Object> clientCardResult = new ArrayList<Object>();
			clientCardResult = mySql.clientCardInfo((String) arr.get(1));
			this.sendToClient(clientCardResult, client);
			break;
		case "BuyOneTime":
			ArrayList<Object> PurchaseResult = new ArrayList<Object>();
			PurchaseResult = mySql.BuyOneTime((String) arr.get(1), (String) arr.get(2));
			this.sendToClient(PurchaseResult, client);
			break;
		case "BuySubscription":
			ArrayList<Object> SubscriptionResult = new ArrayList<Object>();
			SubscriptionResult = mySql.BuySubscription((String) arr.get(1), (String) arr.get(2),(String) arr.get(3));
			this.sendToClient(SubscriptionResult, client);
			break;
		case "RenewalSubscription":
			ArrayList<Object> RenewalResult = new ArrayList<Object>();
			RenewalResult = mySql.RenewalSubscription((String) arr.get(1), (String) arr.get(2), (String) arr.get(3));
			this.sendToClient(RenewalResult, client);
			break;

		case "CityCatalogAfterSearch":
			ArrayList<String> CitylistAfterSearch = new ArrayList<String>();
			CitylistAfterSearch = mySql.CitylistAfterSearch((ArrayList<String>) arr.get(1));
			this.sendToClient(CitylistAfterSearch, client);
			break;
		case "getClientPaymentInfo":
			ArrayList<String> ClientPaymentInfo = new ArrayList<String>();
			ClientPaymentInfo = mySql.getClientPaymentInfo((String) arr.get(1));
			this.sendToClient(ClientPaymentInfo, client);
			break;
		case "SetNewClientPaymentInfo":
			ArrayList<Object> setnewClientPaymentInfo = new ArrayList<Object>();
			setnewClientPaymentInfo.add("setnewClientPaymentInfoAnswer");
			boolean res=(mySql.setNewClientPaymentInfo((CreditCardInforRequest) arr.get(1)));
			setnewClientPaymentInfo.add(res);//TODO
			this.sendToClient(setnewClientPaymentInfo, client);
			break;
		case "ManagerSetNewPrice":
			ArrayList<Object> setNewPrice = new ArrayList<Object>();
			setNewPrice.add("ManagerSetNewPrice");
			boolean result = mySql.SetNewCollectionPrice((String) arr.get(1), (String) arr.get(2));
			setNewPrice.add(result);
			this.sendToClient(setNewPrice, client);
			break;
		case "CollectionPriceUpdateRequest":
			ArrayList<Object> UpdateList = new ArrayList<Object>();
			UpdateList = mySql.GetChangePriceRequest();
			this.sendToClient(UpdateList, client);
			break;
		case "getBasicReport":
			ArrayList<Object> basicReportResult = new ArrayList<Object>();
			basicReportResult = mySql.getBasicReportInfo((BasicReportRequest) arr.get(1));
			this.sendToAllClients(basicReportResult);
			break;
		case "CheckForExpiringSubscription":
			ArrayList<Object> ExpiringSubscription;
			ExpiringSubscription = mySql.ReturnExpiringSubscription((String) arr.get(1));
			this.sendToClient(ExpiringSubscription, client);
			break;
		case "DeniedRequest":
			ArrayList<Object> DeniedRequestrespond;
			DeniedRequestrespond = mySql.DeniedRequest((String) arr.get(1));
			this.sendToClient(DeniedRequestrespond, client);
			break;
		case "SetNewPriceChangeRequest":
			ArrayList<Object> SetNewPriceRequest;
			SetNewPriceRequest = mySql.SetNewPriceRequest((String) arr.get(1), (String) arr.get(2),
					(String) arr.get(3));
			this.sendToClient(SetNewPriceRequest, client);
			break;
		case "getData":
			ArrayList<Object> getData;
			getData = mySql.getData();
			this.sendToClient(getData, client);
			break;
		case "UploadEditMapRequests":
			ArrayList<Object> EditMapRequests;
			EditMapRequests = mySql.getEditMapRequests();
			this.sendToClient(EditMapRequests, client);
			break;
		case "getCities":
			ArrayList<Object> getCities;
			getCities = mySql.getCities();
			this.sendToClient(getCities, client);
			break;
		case "getCitySites":
			ArrayList<Object> getCitySites;
			getCitySites = mySql.getCitySites((String) arr.get(1), (String) arr.get(2));
			this.sendToClient(getCitySites, client);
			break;
		case "mapImage":
			ArrayList<Object> mapImage = new ArrayList<Object>();
			try {
				mapImage = mySql.getMapImage((Object) arr.get(1));
			} catch (SQLException | IOException e) {
				e.printStackTrace();
			}
			this.sendToClient(mapImage, client);
			break;
		case "EditInfoToManger":
			try {
				mySql.setNewMapEditInfo((ArrayList<Object>) arr.get(1));
			} catch (SQLException e) {e.printStackTrace();} 
			catch (IOException e) {e.printStackTrace();}
			// this.sendToClient(EditInfoToMangerReq, client);
			break;
		case "getMapDetailsRegullar":
			ArrayList<Object> mapDetail = new ArrayList<Object>();
			mapDetail = mySql.mapsCollectioninfo();
			this.sendToClient(mapDetail, client);
			break;
		case "mapImageRegullar":
			ArrayList<Object> mapRegullar = new ArrayList<Object>();
			try {
				mapRegullar = mySql.getMapImageRegullar((String) arr.get(1));
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			this.sendToClient(mapRegullar, client);
			break;
		case "updateStatus":
			mySql.changeStatusMapforContentEmployee((String) arr.get(1));
			break;
		case "CityTourDet":
			ArrayList<Object> CityTourDet = new ArrayList<Object>();
			try {
				CityTourDet = mySql.getCityTourDet((String) arr.get(1));
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			this.sendToClient(CityTourDet, client);
			break;
		case "setCitiesTourInfo":
			ArrayList<Object> getCitiesTourInfoRes = new ArrayList<Object>();
			try {
				getCitiesTourInfoRes = mySql.setCitiesTourInfo((ArrayList<ToursOfCitiesInfo>) arr.get(1));
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			this.sendToClient(getCitiesTourInfoRes, client);
			break;
		case "NewCitiesInfo":
			ArrayList<Object> getNewCitiesInfoRes = new ArrayList<Object>();
			try {
				getNewCitiesInfoRes = mySql.setNewCitiesInfoRes((String) arr.get(1), (String) arr.get(2));
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			this.sendToClient(getNewCitiesInfoRes, client);
			break;
		case "SiteInfoBackForEdit":
			ArrayList<Object> getSiteInfoBackForEditRes = new ArrayList<Object>();
			try {
				getSiteInfoBackForEditRes = mySql.getSiteInfoBackForEdit((String) arr.get(1), (int) arr.get(2));
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			this.sendToClient(getSiteInfoBackForEditRes, client);
			break;
		case "SiteInfoFowardForEdit":
			ArrayList<Object> getSiteInfoFowardForEditRes = new ArrayList<Object>();
			try {
				getSiteInfoFowardForEditRes = mySql.setSiteInfoFowardForEdit((SiteInfoForEditResponse) arr.get(1),
						(int) arr.get(2));
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			this.sendToClient(getSiteInfoFowardForEditRes, client);
			break;
		case "SiteInfoFowardForAdd":
			ArrayList<Object> SiteInfoFowardForAddRes = new ArrayList<Object>();
			SiteInfoFowardForAddRes = mySql.setSiteInfoFowardForAdd((SiteInfoForEditResponse) arr.get(1),
					(String) arr.get(2));
			this.sendToClient(SiteInfoFowardForAddRes, client);
			break;
		case "SetNewMapVersion":
			ArrayList<Object> NewMapVersionRespond;
			NewMapVersionRespond = mySql.SetNewMapVersion((String) arr.get(1), (String) arr.get(2));
			this.sendToClient(NewMapVersionRespond, client);
			break;
		case "DeniedMapVersion":
			ArrayList<Object> DeniedMapVersion;
			DeniedMapVersion = mySql.DeniedNewMapVersion((String) arr.get(1), (String) arr.get(2));
			this.sendToClient(DeniedMapVersion, client);
			break;
		case "ClientMessages":
			ArrayList<Object> ClientMessages;
			ClientMessages = mySql.GetClientMessages((String) arr.get(1));
			this.sendToClient(ClientMessages, client);
			break;
		case "getMapCollectionClient":
			ArrayList<Object> mapCollectionClient;
			mapCollectionClient = mySql.getMapImageCollectionClient((String) arr.get(1));
			this.sendToClient(mapCollectionClient, client);
			break;
		case "addTour":
			mySql.addTour((TourRequest) arr.get(1));
			break;
		case "editTour":
			mySql.editTour((TourRequest) arr.get(1));
			break;
		case "updateClientInfo":
			ArrayList<Object> updateClientInfoRes = new ArrayList<Object>();
			try {
				updateClientInfoRes = mySql.updateClientInfo((RegisterDataRequest) arr.get(1));
			} catch (SQLException e) {e.printStackTrace();}
			this.sendToClient(updateClientInfoRes, client);
			break;
		case "getUpdateClientInfo":
			ArrayList<Object> getUpdateClientInfoRes = new ArrayList<Object>();
			try {
				getUpdateClientInfoRes = mySql.getUpdateClientInfo((String) arr.get(1));
			} catch (SQLException e) {e.printStackTrace();}
			this.sendToClient(getUpdateClientInfoRes, client);
			break;
		case "saveMapInfoToDB":
			ArrayList<Object> saveMapInfoToDB;
			saveMapInfoToDB = mySql.saveNewMapInfoToDB(arr);
			this.sendToClient(saveMapInfoToDB, client);
			break;
		case "insertNewMap":
			ArrayList<Object> insertNewMap;
			insertNewMap = mySql.insertNewMap(arr);
			this.sendToClient(insertNewMap, client);
			break;
		case "getMapDetails":
			ArrayList<Object> getMapDetails;
			getMapDetails = mySql.getMapInfo((String) arr.get(1));
			this.sendToClient(getMapDetails, client);
			break;
		case "UpdateColectionViews":
			mySql.UpdateColectionViews((String) arr.get(1));
			break;
		case "setStatusForExit":
			mySql.changeStatusMapforContentEmployeeExit((String) arr.get(1));
			break;
		 case "deleteRow":
	   		try {
				mySql.deleteRow((String)arr.get(1),arr.get(2));
			} catch (SQLException e) {e.printStackTrace();}
	   		break;
		 case "getMapsNames":
			 ArrayList<Object> getMapsNames  = new ArrayList<Object>();
			 getMapsNames=mySql.getMapsNames();
			 this.sendToClient(getMapsNames, client);
			 break;
		 case "getMapSiteForAddEditMap":
			 ArrayList<Object> getSite  = new ArrayList<Object>();
			 getSite=mySql.getSiteNameForAddEditMap((String)arr.get(1));
			 this.sendToClient(getSite, client);
			 break;
		 case "getMapTourForAddEditMap":
			 ArrayList<Object> getTour  = new ArrayList<Object>();
			 getTour=mySql.getTourNameForAddEditMap((String)arr.get(1));
			 this.sendToClient(getTour, client);
			 break;
		 case "removeUpdate":
			 mySql.removeUpdate((String) arr.get(1));
			 break;

		}

	}

	/**
	 * This method overrides the one in the superclass. Called when the server
	 * starts listening for connections.
	 */
	protected void serverStarted() {
		System.out.println("Server listening for connections on port " + getPort());
	}

	/**
	 * This method overrides the one in the superclass. Called when the server stops
	 * listening for connections.
	 */
	protected void serverStopped() {
		System.out.println("Server has stopped listening for connections.");
	}

	// Class methods ***************************************************

	/**
	 * This method is responsible for the creation of the server instance (there is
	 * no UI in this phase).
	 *
	 * @param args[0] The port number to listen on. Defaults to 5555 if no argument
	 *        is entered.
	 */
	public static void StartServer(String[] args) {
		int port = 0; // Port to listen on

		try {
			port = Integer.parseInt(args[0]); // Get port from command line
		} catch (Throwable t) {
			port = DEFAULT_PORT; // Set port to 5555
		}

		EchoServer sv = new EchoServer(port);
		setSv(sv);

		try {
			sv.listen(); // Start listening for connections
		} catch (Exception ex) {
			System.out.println("ERROR - Could not listen for clients!");
		}
	}

	public static EchoServer temp;

	public static void setSv(EchoServer sv) {
		temp = sv;
	}

}
//End of EchoServer class
