package server;

import java.io.IOException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import entities.BasicReportRequest;
import entities.BasicReportResponse;
import entities.CityCatalogRespond;
import entities.CityWithToursAndSitesNames;
import entities.ClientCardResponse;
import entities.CreditCardInfoResponse;
import entities.CreditCardInforRequest;
import entities.EditMapEmployeeRequest;
import entities.EditMapRequest;
import entities.HistoryPurchaseResponse;
import entities.LoginDataRequest;
import entities.LoginDataResponse;
import entities.RegisterDataRequest;
import entities.RegisterDataResponse;
import entities.SiteInfoForEditResponse;
import entities.TourRequest;
import entities.ToursOfCitiesInfo;
import entities.UpdateRequest;
import entities.mapCollectionImg;
import entities.DataTypes.UserType;

public class mysqlConnection {

	static Connection conn;

	public void openConnection() {

		try {
			Class.forName("com.mysql.jc.jdbc.Driver");
		} catch (Exception ex) {
			/* handle the error */}

		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost/gcm?serverTimezone=IST", "root", "Aa123456");
			System.out.println("done setting conn ");

		} catch (SQLException ex) {/* handle any errors */
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
			ex.printStackTrace();
		}
	}

    /**  
     * this method check if the user who asked for get in the system has the possibilty to get in
     * @param loginDataRequest
     * @return
     */
	public ArrayList<Object> login(LoginDataRequest loginDataRequest) {
		Statement stmt = null;
		ResultSet rs = null;
		String query1 = "SELECT username,permission,status,ID FROM gcm.user WHERE username='"
				+ loginDataRequest.getUserName() + "' AND password ='" + loginDataRequest.getPassword() + "';";
		System.out.println(query1);
		ArrayList<Object> arr = new ArrayList<Object>();
		LoginDataResponse loginDataResponse = null;
		arr.add("login");
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query1);
			if (rs.first()) {
				if (rs.getString("status").equals("0")) {
					PreparedStatement ps = conn.prepareStatement("UPDATE gcm.user SET `status`=? WHERE username=?");
					ps.setString(2, loginDataRequest.getUserName());
					ps.setString(1, "1");
					ps.executeUpdate();
					loginDataResponse = new LoginDataResponse(true, "",
							UserType.valueOf(rs.getString("permission").toUpperCase()), rs.getString("username"),
							rs.getString("ID"));
				} else {
					loginDataResponse = new LoginDataResponse(false, "connected", UserType.CLIENT, "",
							rs.getString("ID"));
				}
			} else {
				loginDataResponse = new LoginDataResponse(false, "", UserType.CLIENT, "", "");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		arr.add(loginDataResponse);
		return arr;
	}

	/**
	 * This method enter the user details to the database if the registration succeeds
	 * @param registerDataRequest
	 * @return
	 */
	public ArrayList<Object> register(RegisterDataRequest registerDataRequest) {
		Statement stmt = null;
		ResultSet rs = null;

		String query1 = "SELECT username,ID FROM gcm.user WHERE username='" + registerDataRequest.getUsername()
				+ "' OR ID ='" + registerDataRequest.getId() + "'";
		ArrayList<Object> arr = new ArrayList<Object>();
		RegisterDataResponse registerDataResponse = null;
		arr.add("register");
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query1);
			if (rs.first()) {
				registerDataResponse = new RegisterDataResponse(false);
			}

			else {
				String sql1 = "insert into gcm.person values('" + registerDataRequest.getId() + "','"
						+ registerDataRequest.getFullname() + "','" + registerDataRequest.getPhone() + "','"
						+ registerDataRequest.getAddress() + "','" + registerDataRequest.getEmail() + "','"
						+ registerDataRequest.getBirthday() + "','" + registerDataRequest.getSex() + "');";
				String sql2 = "insert into gcm.user values('" + registerDataRequest.getUsername() + "','"
						+ registerDataRequest.getPassword() + "','" + "client','" + registerDataRequest.getId()
						+ "','0');";
				stmt.executeUpdate(sql1);
				stmt.executeUpdate(sql2);
				registerDataResponse = new RegisterDataResponse(true);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		arr.add(registerDataResponse);
		return arr;
	}

	/**
	 * this methods signal to the DB that the user in no longer connected.
	 * 
	 * @param msg: contains the user id.
	 * @return: a message whether the server logged-out successfully.
	 */
	public ArrayList<Object> logout(Object msg) {
		ArrayList<Object> arr = new ArrayList<Object>();
		arr.add("logout");
		try {
			String id = (String) msg;
			PreparedStatement ps = conn.prepareStatement("UPDATE gcm.user SET status='0' WHERE ID=?;");
			ps.setString(1, id);
			if (ps.executeUpdate() != 0)
				arr.add(true);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		arr.add(false);
		return arr;
	}

	/**
	 * gets from the DB all the catalogs.
	 * 
	 * @return: list of catalogs and the details that needed to be presented in the
	 *          table-view.
	 */
	public ArrayList<Object> BringCityCatalog() {
		Statement stmt = null;
		ResultSet rs = null;
		Statement stmt1 = null;
		ResultSet rs1 = null;
		Statement stmt2 = null;
		ResultSet rs2 = null;
		ArrayList<Object> overarr = new ArrayList<Object>();
		ArrayList<CityCatalogRespond> arr = new ArrayList<CityCatalogRespond>();
		String des, city;

		overarr.add("getCatalog");
		try {
			String query = "select M.city ,C.name,M.version,M.numberOfViews,C.numberOfMaps,C.numberOfTours,C.numberOfSites,M.price,C.description,M.ID from gcm.city C ,gcm.map_collection M where C.collectionid=M.ID;";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			while (rs.next()) {
				city = rs.getString("city");
				des = rs.getString("description") + ".";
				des += "\nList of maps in the collection: ";
				query = "SELECT distinct M.name FROM gcm.map M,gcm.map_collection MC WHERE MC.ID=M.CollectionID and MC.city='"
						+ city + "' and approve='1';";
				stmt2 = conn.createStatement();
				rs2 = stmt2.executeQuery(query);
				while (rs2.next()) {
					des += "," + rs2.getString("name");
				}
				des += "\nList of sites in the collection: ";
				query = "select siteName from gcm.site where city='" + city + "';";
				stmt1 = conn.createStatement();
				rs1 = stmt1.executeQuery(query);
				while (rs1.next()) {
					des += "," + rs1.getString("siteName");
				}
				des += "\nList of tours in the collection: ";
				query = "select name from gcm.tour where city='" + city + "';";
				rs1 = stmt1.executeQuery(query);
				while (rs1.next()) {
					des += "," + rs1.getString("name");
				}
				arr.add(new CityCatalogRespond(rs.getString("name"), rs.getString("version"), rs.getString("price"),
						rs.getString("numberOfViews"), rs.getString("numberOfMaps"), rs.getString("numberOfSites"),
						rs.getString("numberOfTours"), des, rs.getString("ID")));

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		overarr.add(arr);
		return overarr;
	}

	/**
	 * This method uploads the user credit card info
	 * @param creditCardInfo
	 * @return
	 */
	public ArrayList<Object> setCreditCardInfo(CreditCardInforRequest creditCardInfo) {
		Statement stmt = null;
		ResultSet rs = null;

		String query1 = "SELECT clientID FROM gcm.credit_card_info WHERE clientID='" + creditCardInfo.getClientID()
				+ "'";
		ArrayList<Object> arr = new ArrayList<Object>();
		CreditCardInfoResponse creditCardInfoResponse = null;
		arr.add("creditCard");
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query1);
			if (rs.first()) {
				creditCardInfoResponse = new CreditCardInfoResponse(false);
			} else {
				String sql1 = "insert into gcm.credit_card_info values('" + creditCardInfo.getClientID() + "','"
						+ creditCardInfo.getCreditCardCompany() + "','" + creditCardInfo.getCardNumber() + "','"
						+ creditCardInfo.getSecurityCode() + "','" + creditCardInfo.getCardExpritionDate() + "');";
				stmt.executeUpdate(sql1);
				creditCardInfoResponse = new CreditCardInfoResponse(true);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		arr.add(creditCardInfoResponse);
		return arr;
	}

	/**
	 * This method gets the user client card info from the data base
	 * @param ID
	 * @return
	 */
	public ArrayList<Object> clientCardInfo(String ID) {
		ArrayList<HistoryPurchaseResponse> HPR = new ArrayList<HistoryPurchaseResponse>();
		ArrayList<Object> arr = new ArrayList<Object>();

		Statement stmt = null;
		ResultSet rs = null;
		Statement stmt2 = null;
		ResultSet rsQ2 = null;
		ResultSet rsQ3 = null;

		String query = "SELECT full_name,p.ID,phone,sex,email,username FROM gcm.person p,gcm.user u WHERE p.ID=u.ID AND p.ID='"
				+ ID + "';";
		ClientCardResponse ClientCardResponse = null;
		HistoryPurchaseResponse historyPurchaseResponse = null;
		arr.add("clientCard");
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			System.out.println("rs: " + rs.first());
			if (!(rs.first())) {
				ClientCardResponse = new ClientCardResponse(false, "", "", "", "", "", "");
				System.out.println("nooooo");
				arr.add(ClientCardResponse);
				HPR.add(historyPurchaseResponse);
			} else {
				ClientCardResponse = new ClientCardResponse(true, rs.getString("full_name"), rs.getString("ID"),
						rs.getString("phone"), rs.getString("sex"), rs.getString("username"), rs.getString("email"));
				arr.add(ClientCardResponse);
				System.out.println("" + ClientCardResponse.getEmail() + "" + ClientCardResponse.getName() + ""
						+ ClientCardResponse.getSex());
				/**
				 * set from here to get all the purchase details
				 */
				query = "SELECT purchaseID FROM gcm.client_purchase WHERE clientID='" + rs.getString("ID") + "';";
				stmt2 = conn.createStatement();
				rsQ2 = stmt2.executeQuery(query);
				ArrayList<String> pid = new ArrayList<String>();
				while (rsQ2.next())
					pid.add(rsQ2.getString("purchaseID"));
				for (String purchaseid : pid) {
					query = "SELECT city, version, MP.price FROM gcm.purchase P,gcm.map_collection MP WHERE MP.ID=P.CollectionID and P.ID='"
							+ purchaseid + "';";
					rsQ3 = stmt2.executeQuery(query);
					if (rsQ3.first())
						HPR.add(new HistoryPurchaseResponse(purchaseid, rsQ3.getString("price"), rsQ3.getString("city"),
								rsQ3.getString("version")));
					else {
						query = "SELECT city, version, MP.price FROM gcm.subscription S,gcm.map_collection MP WHERE MP.ID=S.collectionID and S.ID='"
								+ purchaseid + "';";
						rsQ3 = stmt2.executeQuery(query);
						if (rsQ3.first())
							HPR.add(new HistoryPurchaseResponse(purchaseid, rsQ3.getString("price"),
									rsQ3.getString("city"), rsQ3.getString("version")));
					}
				}
			}
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		arr.add(HPR);
		return arr;
	}

	/**
	 * this methods checks if the client is allowed to purchase this item. it checks
	 * for record of payment method for any outcome it present a proper message.
	 **/
	public ArrayList<Object> BuyOneTime(String ClientID, String CollectionID) {
		ArrayList<Object> arr = new ArrayList<Object>();
		Statement stmt = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		Statement stmt1 = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		Statement stmt4 = null;
		Statement stmt6 = null;
		String price, PID = "";
		int maxID;

		arr.add("purchaseOneTimeResult");

		try {
			String query = "select clientID,expirationDate from gcm.credit_card_info where clientID='" + ClientID
					+ "';";
			stmt2 = conn.createStatement();
			rs = stmt2.executeQuery(query);
			if (!rs.first()) {
				arr.add("Nopaymentmethodsfound");
				return arr;
			}
			if (!(isExpired(rs.getString("expirationDate")))) {
				arr.add("Paymentmethodisexpired");
				return arr;
			}
			query = "select ID from gcm.purchase";
			stmt2 = conn.createStatement();
			rs = stmt2.executeQuery(query);
			if (!(rs.last()))
				maxID = 0;
			else {
				maxID = Integer.parseInt(rs.getString("ID"));
			}
			/****************************************************/
			query = "SELECT date from gcm.client_purchase CP,gcm.subscription S WHERE CP.clientID='" + ClientID
					+ "' AND S.ID=CP.purchaseID AND type='subscription' AND S.CollectionID='" + CollectionID + "';";
			stmt1 = conn.createStatement();
			rs1 = stmt1.executeQuery(query);
			while (rs1.next()) {
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				LocalDate Purchasedate = LocalDate.parse(rs1.getString("date"), formatter);
				LocalDate SixMounthAgo = LocalDate.now().minusDays(180);
				if (Purchasedate.isAfter(SixMounthAgo)) {
					arr.add("SubscriptionStillActive");
					return arr;
				}
			}
			/********************************************/
			query = "select ID from gcm.subscription";
			stmt6 = conn.createStatement();
			rs = stmt6.executeQuery(query);
			if (rs.last())
				if (maxID < rs.getInt("ID"))
					maxID = rs.getInt("ID");
			PID = String.valueOf(++maxID);
			query = "SELECT price FROM gcm.map_collection WHERE ID='" + CollectionID + "';";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			rs.first();
			price = rs.getString("price");
			rs.close();
			query = "insert into gcm.purchase values('" + PID + "','" + price + "','" + CollectionID + "');";
			int res = stmt.executeUpdate(query);
			if (res == 1) {
				stmt1 = conn.createStatement();
				String Currdate = LocalDate.now().toString();
				query = "insert into gcm.client_purchase values('" + ClientID + "','" + PID + "','" + Currdate
						+ "','one time');";
				res = stmt1.executeUpdate(query);
				if (res == 1) {
					query = "SELECT numberOfOneTimePurchases,numberOfDownloads FROM gcm.map_collection WHERE ID='"
							+ CollectionID + "';";
					stmt3 = conn.createStatement();
					rs1 = stmt3.executeQuery(query);
					rs1.first();
					String nop = rs1.getString("numberOfOneTimePurchases");
					String nod = rs1.getString("numberOfDownloads");
					int NOP = Integer.parseInt(nop);
					int NOD = Integer.parseInt(nod);
					nop = String.valueOf(++NOP);
					nod = String.valueOf(++NOD);
					query = "UPDATE gcm.map_collection SET numberOfOneTimePurchases='" + nop + "' , numberOfDownloads='"
							+ nod + "'  WHERE ID='" + CollectionID + "';";
					stmt4 = conn.createStatement();
					if (stmt4.executeUpdate(query) > 0) {
						arr.add("success");
						return arr;
					}
				}
			} else
				arr.add("somethinkworng");
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			rs.close();
			rs1.close();
			stmt.close();
			stmt1.close();
			stmt2.close();
			stmt3.close();
			stmt4.close();
		} catch (Exception e) {
			System.out.println("problem in closing rs,stmts");
		}
		return arr;
	}

	/**
     * a methods that helped to check if the date it gets is expired.
     * id=f it is sends true, else false.
     * @param date
     * @return
     */
	public boolean isExpired(String date) {
		LocalDate currDate = LocalDate.now();
		String month = date.substring(1, 2);
		String year = date.substring(3, 7);
		if (Integer.valueOf(year) < currDate.getYear())
			return false;
		if (Integer.valueOf(month) < currDate.getMonthValue() && Integer.valueOf(year) == currDate.getYear())
			return false;
		return true;
	}

	/**
	 * this methods checks if the client can purchase the item. first: it check if
	 * the client previously submitted a payment method. if there is such a record,
	 * it created a record of this purchase in two tables. in a diffrent case it
	 * sends the right message.
	 **/
	public ArrayList<Object> BuySubscription(String ClientID, String CollectionID, String length) {
		ArrayList<Object> arr = new ArrayList<Object>();
		Statement stmt = null;
		ResultSet rs = null;
		Statement stmt1 = null;
		ResultSet rs1 = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		ResultSet rs3 = null;
		Statement stmt4 = null;
		Statement stmt6 = null;
		String PID, query;
		int maxID;

		arr.add("BuySubscriptionRespond");
		try {
			query = "select clientID,expirationDate from gcm.credit_card_info where clientID='" + ClientID + "';";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			if (!rs.first()) {
				arr.add("ClientCardInfoNotInTheSystem");
				return arr;
			}
			if (!(isExpired(rs.getString("expirationDate")))) {
				arr.add("Paymentmethodisexpired");
				return arr;
			}
			query = "SELECT S.expirationDate from gcm.client_purchase CP,gcm.subscription S WHERE CP.clientID='"
					+ ClientID + "' AND S.ID=CP.purchaseID AND type='subscription' AND S.CollectionID='" + CollectionID
					+ "';";
			stmt1 = conn.createStatement();
			rs1 = stmt1.executeQuery(query);
			while (rs1.next()) {
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				LocalDate Purchasedate = LocalDate.parse(rs1.getString("expirationDate"), formatter);
				LocalDate now = LocalDate.parse(LocalDate.now().toString(), formatter);
				if (Purchasedate.isAfter(now)) {
					arr.add("SubscriptionStillActive");
					return arr;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			query = "select ID from gcm.purchase";
			stmt2 = conn.createStatement();
			rs = stmt2.executeQuery(query);
			if (!(rs.last()))
				maxID = 0;
			else {
				maxID = Integer.parseInt(rs.getString("ID"));
			}
			query = "select ID from gcm.subscription";
			stmt6 = conn.createStatement();
			rs = stmt6.executeQuery(query);
			if (rs.last())
				if (maxID < rs.getInt("ID"))
					maxID = rs.getInt("ID");
			PID = String.valueOf(++maxID);
			query = "SELECT price FROM gcm.map_collection WHERE ID='" + CollectionID + "';";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			rs.first();
			String price = rs.getString("price");
			String ExpDate = LocalDate.now().plusDays(30 * Integer.valueOf(length)).toString();
			query = "insert into gcm.subscription values('" + PID + "','" + price + "','" + CollectionID + "','"
					+ ExpDate + "');";
			int res = stmt.executeUpdate(query);
			if (res == 1) {
				stmt1 = conn.createStatement();
				String Currdate = LocalDate.now().toString();
				query = "insert into gcm.client_purchase values('" + ClientID + "','" + PID + "','" + Currdate
						+ "','subscription');";
				res = stmt1.executeUpdate(query);
				if (res == 1) {
					query = "SELECT numberOfSubscriptions,numberOfDownloads FROM gcm.map_collection WHERE ID='"
							+ CollectionID + "';";
					stmt3 = conn.createStatement();
					rs3 = stmt3.executeQuery(query);
					rs3.first();
					String nos = rs3.getString("numberOfSubscriptions");
					String nod = rs3.getString("numberOfDownloads");
					int NOS = Integer.parseInt(nos);
					int NOD = Integer.parseInt(nod);
					nos = String.valueOf(++NOS);
					nod = String.valueOf(++NOD);
					query = "UPDATE gcm.map_collection SET numberOfSubscriptions='" + nos + "' , numberOfDownloads='"
							+ nod + "' WHERE ID='" + CollectionID + "';";
					stmt4 = conn.createStatement();
					if (stmt4.executeUpdate(query) > 0) {
						arr.add("PurchaseSuccessfully");
						return arr;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			rs1.close();
			stmt2.close();
			stmt3.close();
			rs3.close();
			stmt.close();
			stmt1.close();
			rs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		arr.add("");
		return arr;
	}

	/**
     * extends an active subscription and increase to number of renewal of this city collection.
     * @param ClientID: client id
     * @param CollectionID: collection id
     * @param length: the length of the extension.
     * @return
     */
	public ArrayList<Object> RenewalSubscription(String ClientID, String CollectionID, String length) {
		ArrayList<Object> arr = new ArrayList<Object>();
		Statement stmt = null;
		ResultSet rs = null;
		Statement stmt1 = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		Statement stmt4 = null;

		arr.add("RenewalSubscriptionRespond");
		try {
			String query = "select clientID,expirationDate from gcm.credit_card_info where clientID='" + ClientID
					+ "';";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			if (!rs.first()) {
				arr.add("ClientCardInfoNotInTheSystem");
				return arr;
			}
			if (!(isExpired(rs.getString("expirationDate")))) {
				arr.add("Paymentmethodisexpired");
				return arr;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			String query = "SELECT ID,expirationDate FROM gcm.subscription,gcm.client_purchase WHERE purchaseID=ID and collectionID='"
					+ CollectionID + "' and clientID='" + ClientID + "' and type='subscription';";
			stmt1 = conn.createStatement();
			rs1 = stmt1.executeQuery(query);
			while (rs1.next()) {
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				LocalDate purchaseDate = LocalDate.parse(rs1.getString("expirationDate"), formatter);
				LocalDate TodayDate = LocalDate.parse(LocalDate.now().toString(), formatter);
				TodayDate = TodayDate.plusDays(3);
				if (TodayDate.isAfter(purchaseDate) || TodayDate.isEqual(purchaseDate)) {
					String SubIdToUpdate = rs1.getString("ID");
					LocalDate newExpDate = LocalDate.parse(LocalDate.now().toString(), formatter);
					int days = 30 * Integer.valueOf(length);
					newExpDate = newExpDate.plusDays(days);
					query = "update gcm.subscription set expirationDate='" + newExpDate + "' where ID='" + SubIdToUpdate
							+ "';";
					stmt2 = conn.createStatement();
					int result = stmt2.executeUpdate(query);
					if (result == 1) {
						query = "SELECT numberOfRenewals,numberOfDownloads FROM gcm.map_collection WHERE ID='"
								+ CollectionID + "';";
						stmt3 = conn.createStatement();
						rs2 = stmt3.executeQuery(query);
						rs2.first();
						String nor = rs2.getString("numberOfRenewals");
						String nod = rs2.getString("numberOfDownloads");
						int NOR = Integer.parseInt(nor);
						int NOD = Integer.parseInt(nod);
						nor = String.valueOf(++NOR);
						nod = String.valueOf(++NOD);
						query = "UPDATE gcm.map_collection SET numberOfRenewals='" + nor + "' , numberOfDownloads='"
								+ nod + "' WHERE ID='" + CollectionID + "';";
						stmt4 = conn.createStatement();
						if (stmt4.executeUpdate(query) == 1) {
							arr.add("Renewalworked");
							return arr;
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			stmt.close();
			rs.close();
			stmt1.close();
			rs1.close();
			rs2.close();
			stmt2.close();
			stmt3.close();
			stmt4.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		arr.add("");
		return arr;
	}

	/**
	 * this method returns a list of city's names that the search matched for. for
	 * any other respond a proper message appear.
	 **/
	public ArrayList<String> CitylistAfterSearch(ArrayList<String> SearchVal) {
		ArrayList<String> arr = new ArrayList<String>();
		Statement stmt = null;
		ResultSet rs = null;
		Statement stmt1 = null;
		ResultSet rs1 = null;
		Statement stmt2 = null;
		ResultSet rs2 = null;
		String query;
		arr.add("CityCatalogAfterSearch");
		if (!(SearchVal.get(0).equals(""))) {
			try {
				query = "select city from gcm.map_collection where city='" + SearchVal.get(0) + "';";
				stmt = conn.createStatement();
				rs = stmt.executeQuery(query);
				if (rs.first())
					arr.add(rs.getString("city").toLowerCase());
				rs.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (!(SearchVal.get(1).equals(""))) {
			try {
				query = "select city from gcm.tour where name='" + SearchVal.get(1) + "';";
				stmt1 = conn.createStatement();
				rs1 = stmt1.executeQuery(query);
				while (rs1.next())
					if (!(arr.contains(rs1.getString("city"))))
						arr.add(rs1.getString("city").toLowerCase());
				rs1.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (!(SearchVal.get(2).equals(""))) {
			try {
				query = "select city from gcm.site where siteName='" + SearchVal.get(2) + "';";
				stmt2 = conn.createStatement();
				rs2 = stmt2.executeQuery(query);
				while (rs2.next())
					if (!(arr.contains(rs2.getString("city"))))
						arr.add(rs2.getString("city").toLowerCase());
				rs2.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		try {
			stmt.close();
			rs.close();
			stmt1.close();
			rs1.close();
			stmt2.close();
			rs2.close();
		} catch (Exception e) {
		}
		System.out.println(arr.toString());
		return arr;
	}

	/**
	 * this method returns to the 'payment method page' with the client payment
	 * info.
	 ***/
	public ArrayList<String> getClientPaymentInfo(String id) {
		ArrayList<String> arr = new ArrayList<String>();
		Statement stmt = null;
		ResultSet rs = null;

		arr.add("ClientPaymentInfo");
		try {
			String query = "SELECT company,cardNumber,securityCode,expirationDate FROM gcm.credit_card_info WHERE clientID='"
					+ id + "';";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			if (rs.first()) {
				arr.add(rs.getString("company"));
				arr.add(rs.getString("cardNumber"));
				arr.add(rs.getString("securityCode"));
				arr.add(rs.getString("expirationDate"));
			}
			rs.close();
			stmt.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return arr;
	}

	/**
	 * this methods sets new user payment info that client wishes to change return
	 * 'true' in success,'false' otherwise.
	 **/
	public boolean setNewClientPaymentInfo(CreditCardInforRequest card) {
		Statement stmt = null;
		try {
			String query = "UPDATE gcm.credit_card_info SET company='" + card.getCreditCardCompany() + "',cardNumber='"
					+ card.getCardNumber() + "',securityCode='" + card.getSecurityCode() + "',expirationDate='"
					+ card.getCardExpritionDate() + "' WHERE clientID='" + card.getClientID() + "';";
			stmt = conn.createStatement();
			if (stmt.executeUpdate(query) == 1)
				return true;
			return false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	/** this method allowed managers alone to change any collection price **/
	public boolean SetNewCollectionPrice(String collectionID, String price) {
		Statement stmt = null;
		try {
			String query = "UPDATE gcm.map_collection SET price='" + price + "' WHERE ID='" + collectionID + "';";
			stmt = conn.createStatement();
			if (stmt.executeUpdate(query) == 1) {
				query = "UPDATE gcm.changepricerequest set status='1' where collectionID='" + collectionID
						+ "' and amount='" + price + "';";
				if (stmt.executeUpdate(query) > 0)
					return true;
			}
			return false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
     * return to the manager all the change map requests.
     * @return: list of requests.
     */
	public ArrayList<Object> GetChangePriceRequest() {
		ArrayList<Object> arr = new ArrayList<Object>();
		Statement stmt = null;
		ResultSet rs = null;
		arr.add("CollectionPriceUpdateRequest");
		try {
			String query = "SELECT * FROM gcm.changepricerequest C, gcm.map_collection M WHERE C.status!='1' AND C.collectionID=M.ID;";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			while (rs.next()) {
				arr.add(new UpdateRequest(rs.getString("date"), rs.getString("collectionID"), rs.getString("employee"),
						rs.getString("permission"), rs.getString("description"), rs.getString("amount"),
						rs.getString("id")));
			}
			rs.close();
			stmt.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(arr.toString());
		return arr;
	}

	/**
	 * this method gets cities info from the data base for each city counts the
	 * number of one time purchases, subscription and renewals
	 * 
	 * @return an arrayList of cities
	 */
	public ArrayList<Object> getBasicReportInfo(BasicReportRequest basicReportRequest) {
		Statement stmt1, stmt2;
		ResultSet rs1 = null, rs2 = null;
		ArrayList<Object> result = new ArrayList<Object>();
		LocalDate from = basicReportRequest.getFrom();
		LocalDate to = basicReportRequest.getTo();
		System.out.println("from date:" + from + "to date:" + to);
		String sql1 = "SELECT city,numberOfMaps,numberOfViews,numberOfDownloads FROM gcm.map_collection mc,gcm.city c WHERE mc.city=c.name;";
		System.out.println(sql1);
		result.add("BasicReport");
		int oneTimeDownload = 0, subscriptions = 0, renewals = 0;
		try {
			stmt1 = conn.createStatement();
			rs1 = stmt1.executeQuery(sql1);
			while (rs1.next()) {// for each city,
				String sql2 = "SELECT cp.date,cp.type,city FROM gcm.client_purchase cp,gcm.purchase p, gcm.map_collection mp WHERE cp.purchaseID=p.ID AND p.CollectionID=mp.ID;";
				String sql3 = "SELECT cp.date,cp.type,city FROM gcm.subscription s, gcm.client_purchase cp, gcm.map_collection mp WHERE s.collectionID=mp.ID AND cp.purchaseID=s.ID;";
				stmt2 = conn.createStatement();
				rs2=stmt2.executeQuery(sql2);
					while (rs2.next()) {// counts the number of one time purchases
						if (rs1.getString("city").compareTo(rs2.getString("city")) == 0) {
							DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
							LocalDate purchaseDate = LocalDate.parse(rs2.getString("date"), formatter);
							if ((purchaseDate.isAfter(from) || purchaseDate.isEqual(from))
									&& (purchaseDate.isBefore(to) || purchaseDate.isEqual(to))) {
								if (rs2.getString("type").compareTo("one time") == 0)
									oneTimeDownload++;
							}
						}
					}
					rs2= stmt2.executeQuery(sql3);
					while (rs2.next()) {// counts the number of downloads subscriptions and renewals
						if (rs1.getString("city").compareTo(rs2.getString("city")) == 0) {
							DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
							LocalDate purchaseDate = LocalDate.parse(rs2.getString("date"), formatter);
							if ((purchaseDate.isAfter(from) || purchaseDate.isEqual(from))
									&& (purchaseDate.isBefore(to) || purchaseDate.isEqual(to))) {
								if (rs2.getString("type").compareTo("subscription") == 0)
									subscriptions++;
								if (rs2.getString("type").compareTo("renewal") == 0)
									renewals++;
							}
						}
					}
				result.add(new BasicReportResponse(rs1.getString("city"), rs1.getString("numberOfMaps"),
						String.valueOf(oneTimeDownload), String.valueOf(subscriptions), String.valueOf(renewals),
						rs1.getString("numberOfViews"), rs1.getString("numberOfDownloads")));
				stmt2.close();
				rs2.close();
				oneTimeDownload = 0;
				subscriptions = 0;
				renewals = 0;
			}
			stmt1.close();
			rs1.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
     * checks for this user if there is any soon to be expiring subscriptions.
     * @param clienID: client id.
     * @return: a list of city names.
     */
	public ArrayList<Object> ReturnExpiringSubscription(String clienID) {
		ArrayList<Object> arr = new ArrayList<>();
		Statement stmt = null;
		ResultSet rs = null;
		Statement stmt1 = null;
		ResultSet rs1 = null;
		arr.add("ExpiringSubscription");
		try {
			String query = "select purchaseID,expirationDate from gcm.client_purchase CP,gcm.subscription S where "
					+ "CP.clientID='" + clienID + "' and CP.purchaseID=S.ID and CP.type='subscription';";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			while (rs.next()) {
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				LocalDate pdate = LocalDate.parse(rs.getString("expirationDate"), formatter);
				LocalDate currtime = LocalDate.parse(LocalDate.now().toString(), formatter);
				currtime = currtime.plusDays(3);
				if (pdate.isBefore(currtime) || pdate.isEqual(currtime)) {
					query = "SELECT city FROM gcm.subscription sub ,gcm.map_collection col WHERE sub.ID='"
							+ rs.getString("purchaseID") + "' and sub.collectionID=col.ID;";
					stmt1 = conn.createStatement();
					rs1 = stmt1.executeQuery(query);
					rs1.first();
					arr.add(rs1.getString("city"));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return arr;
	}

	/**
     * this methods denied the request.
     * @param ID: request id.
     * @return: boolean as an answer, true success, false failed.
     */
	public ArrayList<Object> DeniedRequest(String ID) {
		ArrayList<Object> arr = new ArrayList<>();
		Statement stmt = null;

		arr.add("DeniedRequest");
		try {
			String query = "UPDATE gcm.changepricerequest SET status='1' WHERE id='" + ID + "';";
			stmt = conn.createStatement();
			if (stmt.executeUpdate(query) == 1) {
				arr.add(true);
				return arr;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		arr.add(false);
		return arr;
	}

	/**
     * changes the price of the desired collections.
     * @param ID: client id
     * @param price: the new price.
     * @param user: the user's user name.
     * @return
     */
	public ArrayList<Object> SetNewPriceRequest(String ID, String price, String user) {
		ArrayList<Object> arr = new ArrayList<>();
		Statement stmt = null;
		ResultSet rs = null;
		Statement stmt1 = null;
		int id;

		arr.add("SetNewPriceRequest");
		try {
			String query = "select id from gcm.changepricerequest";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			if (rs.first()) {
				rs.last();
				id = Integer.valueOf(rs.getString("id"));
				id++;
			} else
				id = 1;
			String index = String.valueOf(id);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate currDate = LocalDate.parse(LocalDate.now().toString(), formatter);
			String des = "I am asking to changed the price of collection number " + ID + " to " + price + ".";
			query = "insert into gcm.changepricerequest values('" + index + "','" + ID + "','" + currDate + "','" + user
					+ "','content manager','" + des + "','" + price + "','0');";
			stmt1 = conn.createStatement();
			if (1 == stmt1.executeUpdate(query)) {
				arr.add(true);
				return arr;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		arr.add(false);
		return arr;
	}

	/**
	 * This method gets all the cities, sites, tours, maps, and clients info from
	 * the data base, in order to show it on the workers/managers work area
	 * 
	 * @return an array list with all the data needed for employee main area
	 */
	public ArrayList<Object> getData() {
		ArrayList<Object> arr = new ArrayList<>();
		ArrayList<String> maps = new ArrayList<>();
		ArrayList<ArrayList<String>> sites = new ArrayList<>();
		ArrayList<ArrayList<Object>> tours = new ArrayList<>();
		ArrayList<String> cities = new ArrayList<>();
		ArrayList<String> people = new ArrayList<>();
		Statement stmt = null;
		Statement stmt1 = null;
		ResultSet rs1, rs2, rs3, rs4, rs5;
		arr.add("getData");
		try {
			stmt = conn.createStatement();
			String query = "SELECT distinct name FROM gcm.map WHERE approve=1;";
			rs1 = stmt.executeQuery(query);
			while (rs1.next()) {// for each map that is approved
				stmt = conn.createStatement();
				query = "SELECT name,MAX(version) FROM gcm.map WHERE approve=1 AND name='" + rs1.getString("name")
						+ "';";
				rs2 = stmt.executeQuery(query);
				rs2.first();
				maps.add(rs2.getString("name"));// add the map with the highest version to maps array
			}
			arr.add(maps);
			query = "SELECT siteName,city,ID FROM gcm.site;";
			rs2 = stmt.executeQuery(query);
			while (rs2.next()) {// add all the sites to site array, for each site get its name its city and its
								// ID
				ArrayList<String> site = new ArrayList<>();
				site.add(rs2.getString("siteName") + " in " + rs2.getString("city"));
				site.add(rs2.getString("city"));
				site.add(rs2.getString("ID"));
				sites.add(site);
			}
			arr.add(sites);
			query = "SELECT * FROM gcm.tour;";
			rs3 = stmt.executeQuery(query);
			while (rs3.next()) {
				ArrayList<Object> tour = new ArrayList<>();
				tour.add(rs3.getInt("ID"));
				tour.add(rs3.getString("name"));
				tour.add(rs3.getString("description"));
				tour.add(rs3.getString("city"));
				tour.add(rs3.getString("recommended"));
				tour.add(rs3.getString("accessibility"));
				tours.add(tour);
			}
			arr.add(tours);
			query = "SELECT name FROM gcm.city;";
			stmt1 = conn.createStatement();
			rs4 = stmt1.executeQuery(query);
			while (rs4.next()) {
				cities.add(rs4.getString("name"));
			}
			arr.add(cities);
			query = "SELECT ID FROM gcm.person;";
			rs5 = stmt1.executeQuery(query);
			while (rs5.next()) {
				people.add(rs5.getString("ID"));
			}
			arr.add(people);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return arr;
	}

	/**
     * returns to the manager all the changes in the map requests.
     * @return
     */
	public ArrayList<Object> getEditMapRequests() {
		ArrayList<Object> arr = new ArrayList<>();
		Statement stmt = null;
		ResultSet rs = null;

		arr.add("EditMapRequests");
		try {
			String query = "SELECT mapname,description,version,mapEditImage FROM gcm.edit_map_request WHERE status='0';";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			while (rs.next()) {
				Blob blob = rs.getBlob("mapEditImage");
				byte[] bytes = blob.getBytes(1l, (int) blob.length());
				arr.add(new EditMapRequest(rs.getString("mapname"), rs.getString("version"),
						rs.getString("description"), bytes));
			}
			rs.close();
			stmt.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return arr;
	}

	/**
	 * This method returns an array with all the cities names in the data base
	 * in order to load them in a combo box in AddEditTour boundary 
	 * @return
	 */
	public ArrayList<Object> getCities() {
		ArrayList<Object> arr = new ArrayList<>();
		ResultSet rs = null;
		Statement stmt = null;
		arr.add("getCities");
		try {
			stmt = conn.createStatement();
			String query = "SELECT name FROM gcm.city;";
			rs = stmt.executeQuery(query);
			if (rs.first()) {
				arr.add(rs.getString("name"));
				while (rs.next()) {
					arr.add(rs.getString("name"));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return arr;
	}

	/**
	 * This method gets a city and a tour name, and returns an array including an
	 * array with the sites of the city and another array with the tour's sites
	 * thats already in the data base.
	 * 
	 * @param allSites  - an arrayList of all the sites in the city
	 * @param tourSites - an arrayList of all the sites currently in the tour
	 * @return
	 */
	public ArrayList<Object> getCitySites(String cityName, String tourName) {
		ArrayList<Object> arr = new ArrayList<>();
		ArrayList<ArrayList<Object>> allSites = new ArrayList<>();
		ArrayList<ArrayList<Object>> tourSites = new ArrayList<>();
		ResultSet rs = null;
		Statement stmt = null;
		arr.add("getCitySites");
		try {
			stmt = conn.createStatement();
			String query = "SELECT siteName,ID FROM site WHERE city='" + cityName + "';";
			rs = stmt.executeQuery(query);
			if (rs.first()) {
				ArrayList<Object> site = new ArrayList<>();
				site.add(rs.getString("siteName"));
				site.add(rs.getInt("ID"));
				allSites.add(site);
				while (rs.next()) {
					site = new ArrayList<>();
					site.add(rs.getString("siteName"));
					site.add(rs.getInt("ID"));
					allSites.add(site);
				}
			}
			query = "SELECT s.siteName,s.ID,t.ID AS tourID,t.name,st.recommendedTime FROM site s,tour t, site_in_tour st WHERE t.name='"
					+ tourName + "' AND s.ID=st.siteID and t.ID=st.tourID;";
			rs = stmt.executeQuery(query);
			if (rs.first()) {
				ArrayList<Object> siteInTour = new ArrayList<>();
				siteInTour.add(rs.getString("siteName"));
				siteInTour.add(rs.getInt("ID"));
				siteInTour.add(rs.getInt("tourID"));
				siteInTour.add(rs.getString("name"));
				siteInTour.add(rs.getString("recommendedTime"));
				tourSites.add(siteInTour);
				while (rs.next()) {
					siteInTour = new ArrayList<>();
					siteInTour.add(rs.getString("siteName"));
					siteInTour.add(rs.getInt("ID"));
					siteInTour.add(rs.getInt("tourID"));
					siteInTour.add(rs.getString("name"));
					siteInTour.add(rs.getString("recommendedTime"));
					tourSites.add(siteInTour);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		arr.add(allSites);
		arr.add(tourSites);
		return arr;
	}


	/**
	 * this method return all of the maps information
	 * @return
	 */
	public ArrayList<Object> mapsCollectioninfo() {
		Statement stmt = null;
		ResultSet rs = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		ResultSet rs2 = null;
		ResultSet rs3 = null;

		ArrayList<Object> arr = new ArrayList<Object>();
		ArrayList<EditMapEmployeeRequest> arrSiteDetails = new ArrayList<EditMapEmployeeRequest>();
		ArrayList<String> arrMapName = new ArrayList<String>();
		EditMapEmployeeRequest temp;
		String mapName = "";
		double version = 0;

		arr.add("mapCollectionnames");
		String query1 = "SELECT mapname FROM gcm.mapimages ";
		// String query2= "SELECT siteName,mapname,locationX,locationY from
		// gcm.site_in_map, gcm.site where mapname='"+mapName+"'and siteID=ID;";
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query1);
			// rs.first();
			while (rs.next()) {
				try {
					mapName = rs.getString("mapname");
					String query3 = "SELECT MAX(version) from gcm.site_in_map where mapname='" + mapName
							+ "' and approve='1';";

					stmt3 = conn.createStatement();
					rs3 = stmt3.executeQuery(query3);
					if (rs3.first()) {
						version = rs3.getDouble("MAX(version)");
					} else
						arrSiteDetails.add(null);

					rs3.close();
					arrMapName.add(mapName);

					stmt2 = conn.createStatement();
					String query2 = "SELECT siteID,siteName,mapname,locationX,locationY from gcm.site_in_map, gcm.site where mapname='"
							+ mapName + "'AND version=" + version + "AND siteID=ID;";
					rs2 = stmt2.executeQuery(query2);

					try {
						while (rs2.next()) {
							temp = new EditMapEmployeeRequest(mapName, rs2.getString("siteName"),
									rs2.getDouble("locationX"), rs2.getDouble("locationY"), rs2.getInt("siteID"));
							arrSiteDetails.add(temp);
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}
					rs2.close();
					stmt2.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		arr.add(arrMapName);
		arr.add(arrSiteDetails);
		return arr;
	}

	/**
	 * this function get name of map, and return the image (by bits) to the user and
	 * the sites that exist in this map
	 */
	public ArrayList<Object> getMapImage(Object mapname) throws SQLException, IOException {
		Statement stmt = null;
		Statement stmt3 = null;
		ResultSet rs = null;
		ResultSet rs2 = null;
		ResultSet rs3 = null;
		EditMapEmployeeRequest editMapEmployeeRequest = null;
		ArrayList<Object> arr = new ArrayList<Object>();
		ArrayList<Object> siteReturn = new ArrayList<Object>();
		double version = 0;
		arr.add("mapImage");
		String query1 = "SELECT cityname,map,status FROM gcm.mapimages WHERE mapname='" + (String) mapname + "'";
		String query2;
		try {
			String query3 = "select MAX(version) from gcm.map where name='" + (String) mapname + "' AND approve='0';";
			stmt3 = conn.createStatement();
			rs3 = stmt3.executeQuery(query3);
			rs3.first();
			version = rs3.getDouble("MAX(version)");
			rs3.close();
			stmt3.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query1);
			if (!(rs.first())) {
				siteReturn = null;
				arr.add(siteReturn);
			} else {

				Blob blob = rs.getBlob("map");
				byte[] bytes = blob.getBytes(1l, (int) blob.length());
				arr.add(bytes);
			}
//			stmt = conn.createStatement();
			query2 = "select siteID,siteName,locationX,locationY from gcm.site S,gcm.site_in_map SM where SM.siteID = S.ID and SM.mapname='"
					+ (String) mapname + "' AND approve='0' and SM.version=" + version + ";";
			rs2 = stmt.executeQuery(query2);
			if (!rs2.first()) {
				siteReturn = null;
				arr.add(siteReturn);
			} else {

				editMapEmployeeRequest = new EditMapEmployeeRequest((String) mapname, rs2.getString("siteName"),
						rs2.getDouble("locationX"), rs2.getDouble("locationY"), rs2.getInt("siteID"));
				siteReturn.add(editMapEmployeeRequest);
				// siteInfoarr.add(rs2.getString("siteName"));
				while (rs2.next()) {
					editMapEmployeeRequest = new EditMapEmployeeRequest((String) mapname, rs2.getString("siteName"),
							rs2.getDouble("locationX"), rs2.getDouble("locationY"), rs2.getInt("siteID"));
					siteReturn.add(editMapEmployeeRequest);
				}
				arr.add(siteReturn);
			}
			rs2.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		rs.close();

		try {
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return arr;
	}

    /**
     * get the asked image from the DB back to the server
     * @param mapname
     * @return
     * @throws SQLException
     * @throws IOException
     */
	public ArrayList<Object> getMapImageRegullar(Object mapname) throws SQLException, IOException {
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<Object> arr = new ArrayList<Object>();
		ArrayList<Object> siteReturn = new ArrayList<Object>();
		arr.add("mapImageRegullar");
		String query1 = "SELECT cityname,map,status FROM gcm.mapimages WHERE mapname='" + (String) mapname + "'";
		// String query2 = "select siteName,locationX,locationY from gcm.site
		// S,gcm.site_in_map SM where SM.siteID = S.ID and SM.isDeleted='0' and
		// SM.mapname='"+ (String)mapname + "'";

		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query1);

			if (!(rs.first())) {
				siteReturn = null;
				arr.add(siteReturn);
			} else {
				Blob blob = rs.getBlob("map");
				byte[] bytes = blob.getBytes(1l, (int) blob.length());
				arr.add(bytes);
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return arr;
	}

	/**
	 * this function get from the employee user all of his site edits on the map and
	 * update the table on DB by this information
	 * @param arr
	 * @throws SQLException
	 * @throws IOException
	 */
	public void setNewMapEditInfo(ArrayList<Object> arr) throws SQLException, IOException {
		Statement stmt = null;
		ResultSet rs = null;

		ArrayList<EditMapEmployeeRequest> siteReturn = new ArrayList<EditMapEmployeeRequest>();
		siteReturn = (ArrayList<EditMapEmployeeRequest>) arr.get(0);
		byte[] resArr = (byte[]) arr.get(2);
		String query;
		Double version = 0.1;
		DecimalFormat df = new DecimalFormat(".##");
		stmt = conn.createStatement();
		try {
			query = "select MAX(version) from gcm.site_in_map where mapname='" + siteReturn.get(0).getMapname() + "';";
			rs = stmt.executeQuery(query);
			if (rs.first()) {
				version = rs.getDouble("MAX(version)");
			} else
				return;
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			for (int i = 0; i < siteReturn.size(); i++) {
				query = "update gcm.site_in_map SET locationX='" + siteReturn.get(i).getLocationX() + "', locationY='"
						+ siteReturn.get(i).getLocationY() + "' WHERE siteID='" + siteReturn.get(i).getId()
						+ "' AND mapname='" + siteReturn.get(i).getMapname() + "' AND version='" + version + "';";
				stmt.executeUpdate(query);
			}
			String sql = "insert into gcm.edit_map_request VALUES(?,?,?,?,?)";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, siteReturn.get(0).getMapname());
			pstmt.setDouble(2, version);
			pstmt.setString(3, (String) arr.get(1));
			pstmt.setString(4, (String) "0");
			pstmt.setBytes(5, resArr);
			pstmt.executeUpdate();
			pstmt.close();
			
			query = "DELETE FROM gcm.site_in_map WHERE mapname = '"+siteReturn.get(0).getMapname()+"' AND version = '"+version+ "' AND locationX = -1 AND locationY = -1;";
			stmt.executeUpdate(query);
		} catch (Exception e) {
			e.printStackTrace();
		}
		stmt.close();
	}

	/**
	 * this method update the status when content start to edit the specific map
	 * @param mapName
	 */
	public void changeStatusMapforContentEmployee(String mapName) {
		Statement stmt;
		String sql = "update gcm.mapimages SET status='1' where mapname='" + mapName + "';";

		try {
			stmt = conn.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * This method getCityTourDet gets the relevant details of the city from city table and the
	 * suitable tours that belongs to the city
	 * @param str
	 * @return
	 * @throws SQLException
	 * @throws IOException
	 */
	public ArrayList<Object> getCityTourDet(String str) throws SQLException, IOException {//TODO
		Statement stmt = null,stmt2=null;
		ResultSet rs = null,rs2=null;
		ToursOfCitiesInfo toursOfCitiesInfo = null;
		ArrayList<ToursOfCitiesInfo> temp = new ArrayList<ToursOfCitiesInfo>();
		ArrayList<Object> arr = new ArrayList<Object>();
		String query1;
		String query2;
		String desc = null;
		query1 = "SELECT ID,name,recommended,city FROM gcm.tour WHERE city='" + str + "'";
		query2 = "SELECT description FROM gcm.city WHERE name='" + str + "'";
		arr.add("getTourNames");
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query1);
			
			
			if (rs.first()) {
				;
				toursOfCitiesInfo = new ToursOfCitiesInfo(rs.getInt("ID"), rs.getString("name"), rs.getString("city"),
						rs.getString("recommended"), desc);
				temp.add(toursOfCitiesInfo);

				while (rs.next()) {
					toursOfCitiesInfo = new ToursOfCitiesInfo(rs.getInt("ID"), rs.getString("name"),
							rs.getString("city"), rs.getString("recommended"), desc);
					temp.add(toursOfCitiesInfo);
				}
			}
			stmt2 = conn.createStatement();
			rs2 = stmt2.executeQuery(query2);
			rs2.first();
			desc = rs2.getString("description");
			

		} catch (SQLException e) {
			e.printStackTrace();
		}
		rs.close();
		try {
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		arr.add(temp);
		arr.add(desc);
		return arr;
	}

	/**
	 * This method setNewCitiesInfoRes sets the details of the new city in city table
	 * @param str
	 * @param str2
	 * @return
	 * @throws SQLException
	 * @throws IOException
	 */
	public ArrayList<Object> setNewCitiesInfoRes(String str, String str2) throws SQLException, IOException {
		Statement stmt = null;
		ResultSet rs = null;
		ResultSet rs2 = null;
		boolean res = false;
		// boolean temp;
		int collecID = 0;
		ArrayList<Object> arr = new ArrayList<Object>();
		arr.add("getNewCitiesInfoRes");
		try {
			String query = "SELECT name FROM gcm.city where name='" + str + "'";
			stmt = conn.createStatement();
			rs2 = stmt.executeQuery(query);
			if (!rs2.first()) {
				String query1 = "SELECT max(ID) FROM gcm.map_collection;";
				stmt = conn.createStatement();
				rs = stmt.executeQuery(query1);
				if (!rs.first()) {
					arr.add(res);
					return arr;
				} else {
					collecID = rs.getInt("max(ID)");
					collecID++;
					String query2 = "insert into gcm.city values('" + str + "','" + str2 + "','" + "0" + "','" + "0"
							+ "','" + "0" + "','" + collecID + "')";
					stmt = conn.createStatement();
					if (stmt.executeUpdate(query2) == 1) {
						query2 = "INSERT into gcm.map_collection VALUES('" + collecID + "','0.1','100','0','0','" + str + "', '0','0','0');";
						if (stmt.executeUpdate(query2) == 1) {
							res = true;
						}
					}				
					rs.close();
				}
			} else {
				res = false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		rs2.close();
		try {
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		arr.add(res);
		return arr;
	}

	/**
	 * This method setCitiesTourInfo sets all the new recommended tours that belongs to the city
	 * @param Arr
	 * @return
	 * @throws SQLException
	 * @throws IOException
	 */
	public ArrayList<Object> setCitiesTourInfo(ArrayList<ToursOfCitiesInfo> Arr) throws SQLException, IOException {
		Statement stmt = null;
		ResultSet rs = null;
		boolean res = false;
		ArrayList<String> tourName = new ArrayList<String>();
		ArrayList<Object> arr = new ArrayList<Object>();
		String query1 = "SELECT name FROM gcm.tour where city='" + Arr.get(0).getCityname() + "'";
		stmt = conn.createStatement();
		rs = stmt.executeQuery(query1);
		if (rs.first()) {
			tourName.add(rs.getString("name"));
			while (rs.next()) {
				tourName.add(rs.getString("name"));
			}
		}
		String query2;
		String query3;
		arr.add("getTourNamesBack");
		try {
			for (int i = 1; i < Arr.size(); i++) {
				query2 = "UPDATE gcm.tour SET recommended='1' where ID='" + Arr.get(i).getId() + "'";
				stmt = conn.createStatement();
				if (stmt.executeUpdate(query2) == 1)
					res = true;
			}
			for (int i = 0; i < tourName.size(); i++) {
				res = true;
				;
				for (int j = 1; j < Arr.size(); j++) {
					if (tourName.get(i).equals(Arr.get(j).getSitename())) {
						res = false;
						break;
					}
				}
				if (res == true) {
					query3 = "UPDATE gcm.tour SET recommended='0' where name='" + tourName.get(i) + "'";
					stmt = conn.createStatement();
					stmt.executeUpdate(query3);
				}
			}
			query3 = "UPDATE gcm.city SET description='" + Arr.get(0).getDescription() + "' WHERE name='"
					+ Arr.get(0).getCityname() + "';";
			stmt = conn.createStatement();
			stmt.executeUpdate(query3);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		rs.close();
		try {
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		res = true;
		arr.add(res);
		return arr;
	}


/**
 * This method getSiteInfoBackForEdit gets the details of the requested site that belong to the relevant city
 * @param cityname
 * @param id
 * @return
 * @throws SQLException
 * @throws IOException
 */
	public ArrayList<Object> getSiteInfoBackForEdit(String cityname, int id) throws SQLException, IOException {
		Statement stmt = null;
		ResultSet rs = null;
		SiteInfoForEditResponse siteInfoForEditResponse = null;
		ArrayList<SiteInfoForEditResponse> siteName = new ArrayList<SiteInfoForEditResponse>();
		ArrayList<Object> arr = new ArrayList<Object>();
		String query1 = "SELECT siteName,location,type,description,accesForDisabled FROM gcm.site where ID='" + id
				+ "'";
		stmt = conn.createStatement();
		rs = stmt.executeQuery(query1);
		arr.add("getSiteInfoBackForEdit");
		try {
			if (rs.first()) {
				siteInfoForEditResponse = new SiteInfoForEditResponse(rs.getString("siteName"),
						rs.getString("location"), rs.getString("type"), rs.getString("description"),
						rs.getString("accesForDisabled"));
				siteName.add(siteInfoForEditResponse);
				/*
				 * while(rs.next()) { siteInfoForEditResponse = new
				 * SiteInfoForEditResponse(rs.getString("siteName"),rs.getString("location"),rs.
				 * getString("type"),rs.getString("description"),rs.getString("accesForDisabled"
				 * )); siteName.add(siteInfoForEditResponse); }
				 */
			} else {
				arr.add("");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		rs.close();
		try {
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		arr.add(siteName);
		return arr;
	}

	/**
	 * This method setSiteInfoFowardForEdit sets the new updated details of the site in the site table
	 * in the right line of the site
	 * @param siteInfoForEditResponse
	 * @param siteID
	 * @return
	 * @throws SQLException
	 * @throws IOException
	 */
	public ArrayList<Object> setSiteInfoFowardForEdit(SiteInfoForEditResponse siteInfoForEditResponse, int siteID)
			throws SQLException, IOException {
		Statement stmt = null;
		boolean res = false;
		ArrayList<Object> arr = new ArrayList<Object>();
		arr.add("SiteInfoFowardForEditRes");

		try {
			String query1 = "UPDATE gcm.site SET siteName='" + siteInfoForEditResponse.getName() + "',location='"
					+ siteInfoForEditResponse.getLocation() + "',type='" + siteInfoForEditResponse.getType()
					+ "',description='" + siteInfoForEditResponse.getDescription() + "',accesForDisabled='"
					+ siteInfoForEditResponse.getDisabeled() + "' where ID='" + siteID + "'";
			stmt = conn.createStatement();
			if (stmt.executeUpdate(query1) == 1)
				res = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		arr.add(true);
		return arr;
	}

	/**
	 * This method setSiteInfoFowardForAdd sets the new detais of the new site in the site table in
	 * new line with new id
	 * @param siteInfoForEditResponse
	 * @param cityname
	 * @return
	 * @throws SQLException
	 * @throws IOException
	 */
	public ArrayList<Object> setSiteInfoFowardForAdd(SiteInfoForEditResponse siteInfoForEditResponse, String cityname) {
		Statement stmt = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		ResultSet rs = null;
		ResultSet rs2 = null;
		ResultSet rs3 = null;
		boolean res = false;
		// boolean temp;
		int ID = 0;
		ArrayList<Object> arr = new ArrayList<Object>();
		arr.add("setSiteInfoFowardForAddRes");
		try {
			String query = "SELECT siteName,city FROM gcm.site where siteName='" + siteInfoForEditResponse.getName()
					+ "'";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			if (!rs.first()) {
				String query1 = "SELECT MAX(ID) FROM gcm.site";
				stmt = conn.createStatement();
				rs2 = stmt.executeQuery(query1);
				if (!rs2.first()) {
					arr.add(res);
					return arr;
				} else {
					ID = rs2.getInt("MAX(ID)");
					ID++;
					String query2 = "insert into gcm.site values('" + ID + "','" + siteInfoForEditResponse.getName()
							+ "','" + siteInfoForEditResponse.getLocation() + "','" + siteInfoForEditResponse.getType()
							+ "','" + siteInfoForEditResponse.getDescription() + "','"
							+ siteInfoForEditResponse.getDisabeled() + "','" + cityname + "')";
					stmt = conn.createStatement();
					if (stmt.executeUpdate(query2) == 1) {
						res = true;
					}
					String query3 = "SELECT numberOfSites FROM gcm.city where name='" + cityname + "'";
					stmt2 = conn.createStatement();
					rs3 = stmt2.executeQuery(query3);
					rs3.first();
					int numberOfSites = rs3.getInt("numberOfSites");
					numberOfSites++;
					String sql = "Update gcm.city SET numberOfSites='" + numberOfSites + "' WHERE name='" + cityname
							+ "';";
					stmt3 = conn.createStatement();
					stmt3.executeUpdate(sql);
					rs2.close();
					rs3.close();
					stmt2.close();
					stmt3.close();
				}
			} else {
				res = false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		try {
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		arr.add(res);
		return arr;

	}

	/**
	 * this method change the request status to answered then approve all changes by
	 * placing '1' approve column then updated the collection version then send to
	 * all clients who purchase this a massage that new version is available
	 * 
	 * @param mapname
	 * @param mapversion
	 * @return
	 */
	public ArrayList<Object> SetNewMapVersion(String mapname, String mapversion) {
		ArrayList<Object> arr = new ArrayList<Object>();
		ArrayList<String> clients = new ArrayList<String>();
		Statement stmt = null;
		Statement stmt1 = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		Statement stmt4 = null;
		Statement stmt5 = null;
		Statement stmt6 = null;
		Statement stmt7 = null;
		ResultSet rs = null;
		String query, collectionID;
		double version;
		DecimalFormat df = new DecimalFormat(".#");

		arr.add("SetNewMapVersion");
		try {
			query = "UPDATE gcm.site_in_map SET approve='1' WHERE mapname='" + mapname + "' and version="
					+ Double.valueOf(mapversion) + ";";
			stmt = conn.createStatement();
			stmt.executeUpdate(query);
			query = "UPDATE gcm.map SET approve='1' WHERE name='" + mapname + "' AND version=" + mapversion + ";";
			stmt = conn.createStatement();
			if (stmt.executeUpdate(query) < 1)
				throw new Exception();
			query = "Update gcm.edit_map_request SET status='1' WHERE mapname='" + mapname + "' AND version="
					+ mapversion + ";";
			stmt1 = conn.createStatement();
			if (stmt1.executeUpdate(query) < 1) {
				arr.add("UpdateFailed");
				return arr;
			} else
				arr.add("UpdateWorked");
			query = "SELECT MC.city,MC.ID,MC.version FROM gcm.map_collection MC, gcm.map M WHERE M.name='" + mapname
					+ "' AND M.collectionID=MC.ID;";
			stmt2 = conn.createStatement();
			rs = stmt2.executeQuery(query);
			rs.next();
			String city = rs.getString("city");
			version = rs.getDouble("version") + 0.1;
			version = Double.valueOf(df.format(version));
			query = "Update gcm.map_collection SET version='" + version + "' WHERE ID='" + rs.getString("ID") + "';";
			collectionID = rs.getString("ID");
			stmt3 = conn.createStatement();
			if (stmt3.executeUpdate(query) < 1)
				throw new Exception();
			query = "select distinct clientID from gcm.client_purchase CP,gcm.purchase P,gcm.subscription S where CP.purchaseID=P.ID and P.CollectionID='"
					+ collectionID + "' or CP.purchaseID=S.ID and S.collectionID='" + collectionID + "';";
			stmt4 = conn.createStatement();
			rs = stmt4.executeQuery(query);
			while (rs.next())
				clients.add(rs.getString("clientID"));
			if (clients.size() != 0) {
				int id = 0;
				query = "select id from gcm.client_messages;";
				stmt5 = conn.createStatement();
				rs = stmt5.executeQuery(query);
				if (rs.last())
					id = rs.getInt("id");
				for (String client : clients) {
					id++;
					String mess = "New version(" + version + ") of collection: " + collectionID
							+ " has been issued, Check it out!!";
					query = "insert into gcm.client_messages values ('" + id + "','" + client + "','" + mess + "')";
					stmt6 = conn.createStatement();
					stmt6.executeUpdate(query);
				}
			}
			if (Double.valueOf(mapversion) == 0.1) {
				
				query = "select numberOfMaps from gcm.city where name='" + city + "';";
				stmt6 = conn.createStatement();
				rs = stmt6.executeQuery(query);
				rs.first();
				int NOM = rs.getInt("numberOfMaps");
				NOM++;
				query = "update gcm.city set numberOfMaps=" + NOM + " where name='" + city + "';";
				stmt7 = conn.createStatement();
				stmt7.executeUpdate(query);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return arr;
	}

	/**
     * denied the change map request so NO user will be able to purchase it.
     * @param mapname
     * @param version
     * @return
     */
	public ArrayList<Object> DeniedNewMapVersion(String mapname, String version) {
		ArrayList<Object> arr = new ArrayList<>();
		Statement stmt = null;
		String query;
		ResultSet rs = null;
		arr.add("DeniedNewMapVersion");
		try {
			stmt = conn.createStatement();
			// get map id
			query = "SELECT ID FROM gcm.map WHERE name = '" + mapname + "' AND version = '" + version + "'";
			rs = stmt.executeQuery(query);
			int mapID;
			// delete sites and tours related to the created map
			if (rs.first()) {
				mapID = rs.getInt("ID");
				this.deleteSitesAndToursByVersion(mapID, mapname, version);
			}
			// delete map
			query = "DELETE FROM gcm.map WHERE name = '" + mapname + "' AND version = '" + version + "';";
			stmt.executeUpdate(query);
			if (version.equals("0.1")) {
				query = "DELETE FROM gcm.mapimages WHERE mapname = '" + mapname + "';";
				stmt.executeUpdate(query);
			}
			query = "DELETE FROM gcm.edit_map_request WHERE mapname='" + mapname + "' AND version='" + version + "';";
			if (stmt.executeUpdate(query) > 0) {
				arr.add(true);
				return arr;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		arr.add(false);
		return arr;
	}

	/**
	 * This method gets a map ID,name and version and delete its sites and tours if the map by the map version
	 * @param mapID
	 * @param mapName
	 * @param version
	 */
	private void deleteSitesAndToursByVersion(int mapID, String mapName, String version) {
		Statement stmt1 = null, stmt2 = null;
		String query = "DELETE FROM gcm.site_in_map WHERE mapname='" + mapName + "' AND version = '" + version + "';";
		try {
			stmt1 = conn.createStatement();
			stmt1.executeUpdate(query);
			query = "DELETE FROM gcm.tour_in_map WHERE mapID=" + mapID + ";";
			stmt2 = conn.createStatement();
			stmt2.executeUpdate(query);
			stmt1.close();
			stmt2.close();
		} catch (SQLException e) {e.printStackTrace();}
	}

	/**
     * get from the DB all the client messages.
     * @param id: client id
     * @return: list of strings (messages)
     */
	public ArrayList<Object> GetClientMessages(String id) {
		ArrayList<Object> arr = new ArrayList<>();
		Statement stmt = null;
		ResultSet rs = null;

		arr.add("ClientMessages");
		try {
			String query = "select message from gcm.client_messages where clientID='" + id + "';";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			while (rs.next())
				arr.add(rs.getString("message"));
			rs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return arr;
	}

	/** this method get id collection and return the map images to the client */
	public ArrayList<Object> getMapImageCollectionClient(String IDcollection) {
		ArrayList<Object> arr = new ArrayList<Object>();
		ArrayList<mapCollectionImg> arrMap = new ArrayList<>();
		mapCollectionImg temp;
		ArrayList<String> mapsCollectionName = new ArrayList<String>();
		Statement stmt = null;
		ResultSet rs = null;
		ResultSet rs2 = null;
		Statement stmt2 = null;
		ResultSet rs3 = null;
		Statement stmt3 = null;
		double version = 0;
		String mapName;

		arr.add("getCollectionImgMapClient");
		try {
			String query1 = "SELECT name FROM gcm.map where CollectionID='" + IDcollection + "' and approve ='1';";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query1);
			while (rs.next()) {
				mapsCollectionName.add(rs.getString("name"));
			}
			rs.close();
			for (int i = 0; i < mapsCollectionName.size(); i++) {
				String query2 = "SELECT MAX(version) FROM gcm.map WHERE name='" + mapsCollectionName.get(i)
						+ "' AND approve='1';";
				try {
					stmt2 = conn.createStatement();
					rs2 = stmt2.executeQuery(query2);
					rs2.first();
					version = rs2.getDouble("MAX(version)");
					rs2.close();
					String query3 = "SELECT mapEditImage FROM gcm.edit_map_request WHERE version=" + version
							+ " AND mapname='" + mapsCollectionName.get(i) + "';";
					stmt3 = conn.createStatement();
					rs3 = stmt3.executeQuery(query3);
					rs3.first();
					Blob blob = rs3.getBlob("mapEditImage");
					byte[] bytes = blob.getBytes(1l, (int) blob.length());
					temp = new mapCollectionImg(bytes, mapsCollectionName.get(i), version, IDcollection);
					arrMap.add(temp);
					rs3.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			stmt3.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			stmt2.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		arr.add(arrMap);
		return arr;
	}




	/**
	 * This method adds a new tour to the data base updates site in tour table in
	 * the database
	 * 
	 * @param tour
	 */
	public void addTour(TourRequest tour) {
		int tourID = 0;
		ResultSet rs = null;
		Statement stmt = null;
		try {
			stmt = conn.createStatement();
			String query = "SELECT ID FROM gcm.tour;";
			rs = stmt.executeQuery(query);
			if (!rs.last())
				tourID = 1;
			else {
				int nextId = rs.getInt(1);
				tourID = ++nextId;
			}
			query = "INSERT into gcm.tour values(" + tourID + ",'" + tour.getTourName() + "','"
					+ tour.getTourDescription() + "','" + tour.getTourCity() + "'," + tour.getIsRecommended() + ","
					+ tour.getIsAccessible() + ");";
			System.out.println(query);
			stmt.executeUpdate(query);
			ArrayList<ArrayList<Object>> sites = tour.getSitesInTour();
			if (sites == null)
				return;
			for (ArrayList<Object> site : sites) {// adds for each site site id tour id and recommended time
				query = "INSERT into gcm.site_in_tour values(" + (int) site.get(2) + "," + String.valueOf(tourID) + ",'"
						+ (String) site.get(1) + "');";
				System.out.println(query);
				stmt.executeUpdate(query);
			}
			query = "select numberOfTours from gcm.city where name='" + tour.getTourCity() + "';";
			rs = stmt.executeQuery(query);
			rs.first();
			int NOM = rs.getInt("numberOfTours");
			NOM++;
			query = "update gcm.city set numberOfTours=" + NOM + " where name='" + tour.getTourCity() + "';";
			stmt.executeUpdate(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	/**
	 * This method gets tour info, and update the data base with the new details
	 * using addSitesInTour it adds sites the user added to the tour to the data
	 * base using removeSitesInTour it removes any site that the user chose to
	 * remove from the tour from the data base.
	 * 
	 * @param tour
	 */
	public void editTour(TourRequest tour) {

		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			String query = "UPDATE gcm.tour SET name='" + tour.getTourName() + "',description='"
					+ tour.getTourDescription() + "',city='" + tour.getTourCity() + "',recommended='"
					+ tour.getIsRecommended() + "',accessibility='" + tour.getIsAccessible() + "' WHERE ID="
					+ tour.getTourID() + ";";
			System.out.println(query);
			stmt.executeUpdate(query);// update tour table
			// update site_in_tour table - add new ones, delete old ones
			addSitesInTour(tour);
			removeSitesInTour(tour);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * This method gets tour info and adds any sites that isnt already in the data
	 * base
	 * 
	 * @param tour
	 */
	public void addSitesInTour(TourRequest tour) {//TODO
		String query = "SELECT siteID FROM gcm.site_in_tour WHERE tourID=" + tour.getTourID() + ";";
		System.out.println(query);
		ResultSet rs = null;
		Statement stmt = null;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			ArrayList<ArrayList<Object>> sites = tour.getSitesInTour();
			if (sites == null)
				return;
			for (ArrayList<Object> site : sites) {// adds for each site site id tour id and recommended time
				int isInTable = 0;
				if (rs.first()) {
					do {
						if (site.get(2).equals(rs.getInt("siteID"))) {
							isInTable = 1;
						}
					} while (rs.next());
				}
				if (isInTable == 0) {// site is not in the table - adds it
					query = "INSERT into gcm.site_in_tour values(" + (int) site.get(2) + "," + tour.getTourID() + ",'"
							+ (String) site.get(1) + "');";
					System.out.println(query);
					Statement stmt1=conn.createStatement();
					stmt1.executeUpdate(query);
				}
				else {
					query = "UPDATE gcm.site_in_tour SET recommendedTime='"+(String)site.get(1)+"' WHERE siteID="+(int) site.get(2)+" AND tourID='"+tour.getTourID()+"';";
					System.out.println(query);
					Statement stmt2=conn.createStatement();
					stmt2.executeUpdate(query);
				}
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	/**
	 * This method gets tour info and removes any sites that in the data base but
	 * the user chose to remove from the tour.
	 * 
	 * @param tour
	 */
	public void removeSitesInTour(TourRequest tour) {
		String query = "SELECT siteID,tourID FROM gcm.site_in_tour WHERE tourID=" + tour.getTourID() + ";";
		System.out.println(query);
		ResultSet rs = null;
		Statement stmt1 = null, stmt2 = null;
		int isInSites = 0;
		try {
			stmt1 = conn.createStatement();
			rs = stmt1.executeQuery(query);
			ArrayList<ArrayList<Object>> sites = tour.getSitesInTour();
			if (sites == null)
				return;
			if (rs.first()) {// go through rs, if there are sites in the rs that are not in the tour sites,
								// remove them
				do {
					for (int i = 0; i < sites.size(); i++) {
						if (rs.getInt("siteID") == (int) sites.get(i).get(2)) {
							isInSites = 1;
						}
					}
					if (isInSites == 0) {// removes site from table
						query = "DELETE FROM gcm.site_in_tour WHERE siteID=" + rs.getInt("siteID") + " AND tourID="
								+ rs.getInt("tourID") + ";";
						System.out.println(query);
						stmt2 = conn.createStatement();
						stmt2.executeUpdate(query);
						stmt2.close();
						isInSites = 0;
					}
				} while (rs.next());
				rs.close();
				stmt1.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
     * changes the client personal information.
     * @param registerDataRequest
     * @return
     * @throws SQLException
     */
	public ArrayList<Object> updateClientInfo(RegisterDataRequest registerDataRequest) throws SQLException {
		Statement stmt = null;
		Statement stmt2 = null;
		boolean res = false;

		ArrayList<Object> arr = new ArrayList<Object>();
		arr.add("updateClientInfoRes");
		String sql = "update gcm.person SET phone='" + registerDataRequest.getPhone() + "',address='"
				+ registerDataRequest.getAddress() + "',email='" + registerDataRequest.getEmail() + "' where ID='"
				+ registerDataRequest.getId() + "';";
		String sql2 = "update gcm.user SET password='" + registerDataRequest.getPassword() + "' where ID='"
				+ registerDataRequest.getId() + "';";

		try {
			stmt = conn.createStatement();
			if (stmt.executeUpdate(sql2) == 1) {
				res = true;
			}
			stmt2 = conn.createStatement();
			stmt2.executeUpdate(sql);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		stmt.close();
		stmt2.close();

		arr.add(res);
		return arr;
	}

	/**
     * return to the user his personal details.
     * @param id
     * @return
     * @throws SQLException
     */
	public ArrayList<Object> getUpdateClientInfo(String id) throws SQLException {
		Statement stmt1, stmt2 = null;
		ResultSet rs = null;
		ResultSet rs2 = null;
		ArrayList<Object> arr = new ArrayList<Object>();
		RegisterDataRequest registerDataRequest = null;
		arr.add("getUpdateClientInfoBack");
		String qurry = "SELECT full_name,phone,address,email,birthday FROM gcm.person where ID='" + id + "'";
		String qurry2 = "SELECT username,password FROM gcm.user where ID='" + id + "'";
		stmt1 = conn.createStatement();
		stmt2 = conn.createStatement();
		try {
			rs = stmt1.executeQuery(qurry);
			rs2 = stmt2.executeQuery(qurry2);
			if (rs.first() && rs2.first()) {

				registerDataRequest = new RegisterDataRequest(rs.getString("full_name"), id, rs.getString("phone"), "",
						rs.getString("email"), rs2.getString("username"), rs2.getString("password"), "",
						rs.getString("birthday"), rs.getString("address"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		stmt1.close();
		stmt2.close();
		rs.close();
		rs2.close();
		arr.add(registerDataRequest);
		return arr;
	}

	/**
	 * ArryList[commad for chatClient- getMapInfo , basicMapInfo, arrayList cities,
	 * sitesInMap, toursInMap]
	 * 
	 * @param mapName
	 * @return
	 */
	public ArrayList<Object> getMapInfo(String mapName) {
		ArrayList<Object> arr = new ArrayList<>();
		Statement stmt = null;
		ResultSet rs = null;
		String cityName = "";
		int mapID = 0;

		arr.add("getMapInfo"); // at arr(0)
		try {
			// get the basic information of a map
			stmt = conn.createStatement();
			String query;
			ArrayList<String> basicMapInfo = new ArrayList<>();
			if (mapName.equals("")) {
				basicMapInfo.add("");
			} else {
				// if map is already under edit
				query = "SELECT status FROM gcm.mapimages WHERE mapname='" + (String) mapName + "'";
				rs = stmt.executeQuery(query);
				if (!rs.first()) {
					basicMapInfo.add("error no map found");
					arr.add(basicMapInfo);
					return arr;
				}
				if (rs.getString("status").equals("1")) {
					basicMapInfo.add("under edit");
					arr.add(basicMapInfo);
					return arr;
				} else {
					// update status
					changeStatusMapforContentEmployee(mapName);
					// find max version
					query = "SELECT * FROM gcm.map WHERE name = '" + mapName + "' AND approve ='1';";
					rs = stmt.executeQuery(query);
					double version = 0;
					while (rs.next()) {
						if (rs.getDouble("version") > version)
							version = rs.getDouble("version");
					}
					rs.first();
					while (rs.getDouble("version") != version) {
						rs.next();
					}
					basicMapInfo.add(mapName); // basicMapInfo(0) map name
					basicMapInfo.add(rs.getString("description")); // at basicMapInfo(1) description
					basicMapInfo.add(rs.getString("CollectionID"));// at basicMapInfo(2)
					mapID = rs.getInt("ID");
					query = "SELECT city FROM gcm.map_collection WHERE ID = '" + rs.getString("CollectionID") + "';";
					rs = stmt.executeQuery(query);
					rs.first();
					cityName = rs.getString("city");
					basicMapInfo.add(cityName); // at basicMapInfo(3)
				}
			}
			arr.add(basicMapInfo); // at arr(1)
			// get cities and sites+tours that belong to them
			ArrayList<CityWithToursAndSitesNames> cities = new ArrayList<>();
			CityWithToursAndSitesNames city;
			ArrayList<String> cityNames = getCitiesNames();
			for (String name : cityNames) {
				city = new CityWithToursAndSitesNames(name, getSitesNamesInCity(name), getToursNamesInCity(name));
				cities.add(city);
			}
			arr.add(cities); // at arr(2)

			if (!mapName.equals("")) {
				//
				// send sites names that are already in map
				//
				query = "SELECT siteName FROM gcm.site_in_map sim , gcm.site s WHERE sim.siteID = s.ID AND version = (SELECT max(version) ver FROM gcm.site_in_map sim WHERE mapname ='"+mapName+"' AND approve = 1 );";
				rs = stmt.executeQuery(query);
				ArrayList<String> sitesInMap = new ArrayList<>();
				while (rs.next()) {
					sitesInMap.add(rs.getString("siteName"));
				}
				arr.add(sitesInMap); // at arr(3)

				//
				// tour sites names that are already in map
				//

				Statement stmt1 = conn.createStatement();
				query = "SELECT T.name FROM gcm.tour T, gcm.tour_in_map TinM WHERE T.ID = TinM.tourID AND mapID = '"
						+ mapID + "';";
				ResultSet rs1 = stmt1.executeQuery(query);
				ArrayList<String> toursInMap = new ArrayList<>();
				while (rs1.next()) {
					toursInMap.add(rs1.getString("name"));
				}
				arr.add(toursInMap); // at arr(4)
			}
			// rs.close();
			// stmt.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return arr;
	}

	/**
	 * This method gets all the cities names from the data base
	 * @return
	 * @throws SQLException
	 */
	public ArrayList<String> getCitiesNames() throws SQLException {
		Statement stmt = conn.createStatement();
		String query = "SELECT name FROM gcm.city;";
		ResultSet rs = stmt.executeQuery(query);
		ArrayList<String> cityNames = new ArrayList<>();
		while (rs.next()) {
			cityNames.add(rs.getString("name"));
		}
		return cityNames;
	}

	/**
	 * This method gets a city name and gets all the sites names of the city from the data base
	 * @param cityName
	 * @return
	 * @throws SQLException
	 */
	public ArrayList<String> getSitesNamesInCity(String cityName) throws SQLException {
		Statement stmt = conn.createStatement();
		String query = "SELECT siteName FROM gcm.site WHERE city = '" + cityName + "';";
		ResultSet rs = stmt.executeQuery(query);
		ArrayList<String> sitesInCity = new ArrayList<>();
		while (rs.next()) {
			sitesInCity.add(rs.getString("siteName"));
		}
		return sitesInCity;
	}

	/**
	 * This method gets a city name and gets all the tours names of the city from the data base
	 * @param cityName
	 * @return
	 * @throws SQLException
	 */
	public ArrayList<String> getToursNamesInCity(String cityName) throws SQLException {
		Statement stmt = conn.createStatement();
		String query = "SELECT name FROM gcm.tour WHERE city = '" + cityName + "';";
		ResultSet rs = stmt.executeQuery(query);
		ArrayList<String> toursInCity = new ArrayList<>();
		while (rs.next()) {
			toursInCity.add(rs.getString("name"));
		}
		return toursInCity;
	}

	/**
	 * data: command:saveNewMapInfoToDB map name description city name
	 * arrayList<String> sites ArrayList<String> tours
	 * 
	 * @return ArrayList<Object> arr
	 * @param info
	 */
	public ArrayList<Object> saveNewMapInfoToDB(ArrayList<Object> data) {
		ArrayList<Object> arr = new ArrayList<>();
		String mapName = (String) data.get(1);
		String originalMapName = (String) data.get(6);
		String description = (String) data.get(2);
		String cityName = (String) data.get(3);
		ArrayList<String> sites = (ArrayList<String>) data.get(4);
		ArrayList<String> tours = (ArrayList<String>) data.get(5);
		Statement stmt = null;
		ResultSet rs = null;
		int index = 0;
		DecimalFormat df = new DecimalFormat(".#");

		arr.add("saveNewMapInfoToDB");
		try {
			String quary = "SELECT ID FROM gcm.map";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(quary);
			if (rs.last()) {
				index = rs.getInt("ID");
			}
			index++;
			quary = "SELECT max(version), collectionID FROM gcm.map WHERE name = '" + originalMapName + "';";
			rs = stmt.executeQuery(quary);
			rs.first();
			double version = rs.getDouble("max(version)") + 0.1;
			version = Double.valueOf(df.format(version));
			String collectionID = rs.getString("collectionID");
			// insert map info
			quary = "INSERT into gcm.map VALUES( '" + index + "', '" + mapName + "' , '" + description + "' , '"
					+ collectionID + "', '" + version + "', '0');";
			if ((stmt.executeUpdate(quary)) == 0) {
				System.out.println("could not add map version");
				arr.add("");
				return arr;
			}
			// insert all tours in map
			for (String tourName : tours) {
				quary = "select ID from gcm.tour where name='" + tourName + "';";
				rs = stmt.executeQuery(quary);
				rs.first();
				int ID = rs.getInt("ID");
				quary = "INSERT into gcm.tour_in_map VALUES('" + index + "', '" + ID + "');";
				if ((stmt.executeUpdate(quary)) == 0) {
					System.out.println("could not add tour in map");
					arr.add("");
					return arr;
				}

			}
			// insert all sites in map
			for (String siteName : sites) {
				quary = "select ID from gcm.site where siteName='" + siteName + "';";
				rs = stmt.executeQuery(quary);
				rs.first();
				int ID = rs.getInt("ID");
				quary = "INSERT into gcm.site_in_map VALUES('" + ID + "', '" + mapName + "', '-1','-1','" + version
						+ "','0');";
				if ((stmt.executeUpdate(quary)) == 0) {
					System.out.println("could not add site in map");
					arr.add("");
					return arr;
				}
			}
			if (!mapName.equals(originalMapName)) {
				quary = "select map from gcm.mapimages where city name '" + cityName + "'mapname='" + originalMapName
						+ "';";
				rs = stmt.executeQuery(quary);
				rs.first();
				quary = "INSERT into gcm.mapimages VALUES(?, ?, ?);";
				PreparedStatement pstmt = conn.prepareStatement(quary);
				pstmt.setString(1, cityName);
				pstmt.setString(2, mapName);
				Blob blob = (Blob) rs.getBlob("map");
				byte[] bytes = blob.getBytes(1l, (int) blob.length());
				pstmt.setBytes(3, bytes);
				if ((stmt.executeUpdate(quary)) == 0) {
					System.out.println("could not add map picture");
					arr.add("");
					return arr;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			arr.add("could not add site in map");
			return arr;
		}
		arr.add("info inserted in DB");
		return arr;
	}

	/**
	 * This method gets all the map info and inserts it to the data base
	 * @param data
	 * @return
	 */
	public ArrayList<Object> insertNewMap(ArrayList<Object> data) {
		ArrayList<Object> arr = new ArrayList<>();
		String mapName = (String) data.get(1);
		String description = (String) data.get(2);
		String cityName = (String) data.get(3);
		ArrayList<String> sites = (ArrayList<String>) data.get(4);
		ArrayList<String> tours = (ArrayList<String>) data.get(5);
		String mapPic = (String) data.get(6);
		Statement stmt = null;
		ResultSet rs = null;
		int index = 0;

		arr.add("insertNewMap");
		try {
			// check map name
			String quary = "SELECT name FROM gcm.map";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(quary);
			while (rs.next()) {
				if (mapName.equals(rs.getString("name"))) {
					arr.add("map already exists");
					return arr;
				}
			}
			// find new MAP id
			quary = "SELECT ID FROM gcm.map";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(quary);
			if (rs.last()) {
				index = rs.getInt("ID") + 1;
			}

			quary = "SELECT ID FROM gcm.map_collection WHERE city= '" + cityName + "';";
			rs = stmt.executeQuery(quary);
			rs.first();
			int collectionID = rs.getInt("ID");

			// insert map info
			quary = "INSERT into gcm.map VALUES( '" + index + "', '" + mapName + "' , '" + description + "' , '"
					+ collectionID + "', '0.1', '0');";
			if ((stmt.executeUpdate(quary)) == 0) {
				System.out.println("could not add map version");
				arr.add("");
				return arr;
			}
			// insert all tours in map
			for (String tourName : tours) {
				quary = "select ID from gcm.tour where name='" + tourName + "';";
				rs = stmt.executeQuery(quary);
				rs.first();
				int ID = rs.getInt("ID");
				quary = "INSERT into gcm.tour_in_map VALUES('" + index + "', '" + ID + "');";
				if ((stmt.executeUpdate(quary)) == 0) {
					System.out.println("could not add tour in map");
					arr.add("");
					return arr;
				}
			}
			// insert all sites in map
			for (String siteName : sites) {
				quary = "select ID from gcm.site where siteName='" + siteName + "';";
				rs = stmt.executeQuery(quary);
				rs.first();
				int ID = rs.getInt("ID");
				quary = "INSERT into gcm.site_in_map VALUES('" + ID + "', '" + mapName + "', '-1','-1','0.1','0');";
				if ((stmt.executeUpdate(quary)) == 0) {
					System.out.println("could not add site in map");
					arr.add("");
					return arr;
				}
			}
			quary = "SELECT map FROM gcm.mapimages WHERE mapname='" + mapPic + "';";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(quary);
			Statement stmt2 = conn.createStatement();
			rs.first();
			Blob blob = rs.getBlob("map");
			byte[] bytes = blob.getBytes(1l, (int) blob.length());
			String sql = "insert into gcm.mapimages VALUES(?,?,?,?);";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, cityName);
			pstmt.setString(2, mapName);
			pstmt.setBytes(3, bytes);
			pstmt.setString(4, "0");
			pstmt.executeUpdate();
			pstmt.close();
			sql = "insert into gcm.edit_map_request VALUES(?,?,?,?,?);";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mapName);
			pstmt.setString(2, "0.1");
			pstmt.setString(3, description);
			pstmt.setString(4, "0");
			pstmt.setBytes(5, bytes);
			pstmt.executeUpdate();
			pstmt.close();

		} catch (Exception e) {
			e.printStackTrace();
			arr.add("Error in adding map");
			return arr;
		}
		arr.add("new map awaiting picture from outside source");
		return arr;
	}

	/**
	 * This method gets a city name and updates its map collection views
	 * @param city
	 */
	public void UpdateColectionViews(String city) {
		Statement stmt = null;
		ResultSet rs = null;
		String query;
		int amount = 0;
		try {
			query = "select numberOfViews from gcm.map_collection where city='" + city + "';";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			rs.first();
			amount = rs.getInt("numberOfViews");
			amount++;
			query = "update gcm.map_collection set numberOfViews='" + amount + "' where city='" + city + "';";
			if (stmt.executeUpdate(query) < 1)
				throw new Exception();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * This method gets a map name and edit its status to 0 when the user finished editting the map
	 * @param mapName
	 */
	public void changeStatusMapforContentEmployeeExit(String mapName) {
		Statement stmt;
		String sql = "update gcm.mapimages SET status='0' where mapname='" + mapName + "';";
		try {
			stmt = conn.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * gets a map ID and name deletes all the sites that belonged to the map deletes
	 * all the tours that belonged to the map
	 * 
	 * @param mapId
	 * @param mapName
	 * @throws SQLException
	 */
	public void deleteMapToursSites(int mapId, String mapName) throws SQLException {
		Statement stmt1 = null, stmt2 = null;
		String query = "DELETE FROM gcm.site_in_map WHERE mapname='" + mapName + "';";
		stmt1 = conn.createStatement();
		stmt1.executeUpdate(query);
		query = "DELETE FROM gcm.tour_in_map WHERE mapID=" + mapId + ";";
		stmt2 = conn.createStatement();
		stmt2.executeUpdate(query);
		stmt1.close();
		stmt2.close();
	}

	/**
	 * Gets a table to delete from and a criteria to delete by deletes a row in the
	 * database and all its relates
	 * 
	 * @param table
	 * @param toDel
	 * @throws SQLException
	 */
	public void deleteRow(String table, Object toDel) throws SQLException {
		int tourId = 0 ;
		Statement stmt1 = null, stmt2 = null, stmt3 = null, stmt4 = null;
		if (table.equals("city")) {
			String query = "";
			query = "DELETE FROM gcm.city WHERE name='" + (String) toDel + "';";
			try {
				stmt1 = conn.createStatement();
				stmt1.executeUpdate(query);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			query = "SELECT ID FROM gcm.map_collection WHERE city='" + (String) toDel + "';";// gets the map collection
																								// ID
			stmt2 = conn.createStatement();
			ResultSet rs = stmt2.executeQuery(query);
			rs.first();
			String id = rs.getString("ID");
			int collectionID = Integer.valueOf(id);
			query = "SELECT ID,name from gcm.map WHERE CollectionID=" + collectionID + ";";// gets map collection map's
																							// names and IDs
			stmt3 = conn.createStatement();
			ResultSet rs1 = stmt3.executeQuery(query);
			if (rs1.first()) {
				do {
					deleteMapToursSites(rs1.getInt("ID"), rs1.getString("name"));// for each map thats in the map
																					// collection, delete tours and
																					// sites of the map.
				} while (rs1.next());
			}
			query = "DELETE FROM gcm.map WHERE CollectionID=" + collectionID + ";";// delete maps of map collection
			try {
				stmt2 = conn.createStatement();
				stmt2.executeUpdate(query);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			query = "DELETE FROM gcm.mapimages WHERE cityname=" + (String)toDel + ";";// delete maps of map collection
			try {
				stmt2 = conn.createStatement();
				stmt2.executeUpdate(query);
			} catch (SQLException e) {
				e.printStackTrace();
			}

			query = "SELECT ID FROM gcm.tour WHERE city='" + (String) toDel + "';";// gets tours ID
			Statement stmt8 = conn.createStatement();
			ResultSet rs9 = stmt8.executeQuery(query);
			if(rs9.first())
				tourId = rs9.getInt("ID");

			query = "DELETE FROM gcm.site_in_tour WHERE tourID=" + tourId + ";";// delete sites of tour.
			Statement stmt6 = conn.createStatement();
			stmt6.executeUpdate(query);

			query = "DELETE FROM gcm.tour WHERE city='" + (String) toDel + "';";// delete tours of map collection
			try {
				stmt2 = conn.createStatement();
				stmt2.executeUpdate(query);
			} catch (SQLException e) {
				e.printStackTrace();
			}

			query = "DELETE FROM gcm.site WHERE city='" + (String) toDel + "';";// delete sites of map collection
			try {
				stmt2 = conn.createStatement();
				stmt2.executeUpdate(query);
			} catch (SQLException e) {
				e.printStackTrace();
			}

			query = "DELETE FROM gcm.map_collection WHERE city='" + (String) toDel + "';";// delete map collection
			try {
				stmt3 = conn.createStatement();
				stmt3.executeUpdate(query);
			} catch (SQLException e) {
				e.printStackTrace();
			}

		} else if (table.equals("map")) {
			String cityName = "";
			String query = "SELECT MC.city FROM gcm.map_collection MC,gcm.map M WHERE M.CollectionID=MC.ID AND M.name='"
					+ (String) toDel + "';";// find map's city name
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			if (rs.first()) {
				cityName = rs.getString("city");
			}
			query = "SELECT ID,name FROM gcm.map WHERE name='" + (String) toDel + "';";// get map name and ID
			stmt1 = conn.createStatement();
			ResultSet rs2 = stmt1.executeQuery(query);
			if (rs2.first()) {
				deleteMapToursSites(rs2.getInt("ID"), rs2.getString("name"));// deletes map sites and tours
			}
			query = "DELETE FROM gcm.mapimages WHERE mapname='" + (String) toDel + "';";// delete the map
			stmt2 = conn.createStatement();
			stmt2.executeUpdate(query);
			
			query = "DELETE FROM gcm.map WHERE name='" + (String) toDel + "';";// delete the map
			stmt2 = conn.createStatement();
			stmt2.executeUpdate(query);
			
			

			String query3 = "SELECT numberOfMaps FROM gcm.city where name='" + cityName + "'";
			stmt3 = conn.createStatement();
			ResultSet rs3 = stmt3.executeQuery(query3);
			rs3.first();
			int numberOfMaps = rs3.getInt("numberOfMaps");
			numberOfMaps--; // reduce map number in city
			String sql = "Update gcm.city SET numberOfMaps='" + numberOfMaps + "' WHERE name='" + cityName + "';";
			;
			stmt3 = conn.createStatement();
			stmt3.executeUpdate(sql);
			rs2.close();
			rs3.close();
		} else if (table.equals("tour")) {
			String cityName = "";
			int numberOfTours = 0;
			String query = "SELECT city FROM gcm.tour WHERE ID='" + (int) toDel + "';";// find tour's city name
			Statement stmt5 = conn.createStatement();
			ResultSet rs = stmt5.executeQuery(query);
			if (rs.first()) {
				cityName = rs.getString("city");
			}
			query = "DELETE FROM site_in_tour WHERE tourID=" + (int) toDel + ";";// delete sites of tour in site in tour
																					// table
			Statement stmt6 = conn.createStatement();
			stmt6.executeUpdate(query);
			query = "DELETE FROM gcm.tour WHERE ID=" + (int) toDel + ";";// delete tour from tour table
			Statement stmt7 = conn.createStatement();
			stmt7.executeUpdate(query);

			query = "DELETE FROM gcm.tour_in_map WHERE tourID=" + (int) toDel + ";";// delete tour from the tour_in_map
																					// table
			Statement stmt8 = conn.createStatement();
			stmt8.executeUpdate(query);

			query = "SELECT numberOfTours FROM gcm.city where name='" + cityName + "'";
			stmt3 = conn.createStatement();
			ResultSet rs3 = stmt3.executeQuery(query);
			if (rs3.first()) {
				numberOfTours = rs3.getInt("numberOfTours");
			}
			numberOfTours--;
			String sql = "Update gcm.city SET numberOfTours='" + numberOfTours + "' WHERE name='" + cityName + "';";
			;
			stmt3 = conn.createStatement();
			stmt3.executeUpdate(sql);
			// reduce city's tour count
		} else if (table.equals("site")) {
			String cityName = "";
			int numberOfSites = 0;
			String query = "SELECT city FROM gcm.site WHERE ID='" + (int) toDel + "';";// find site's city name
			Statement stmt8 = conn.createStatement();
			ResultSet rs = stmt8.executeQuery(query);
			if (rs.first()) {
				cityName = rs.getString("city");
			}

			query = "DELETE FROM gcm.site_in_tour WHERE siteID=" + (int) toDel + ";";// delete sites of tour in site in
																						// tour table
			Statement stmt6 = conn.createStatement();
			stmt6.executeUpdate(query);

			query = "DELETE FROM gcm.site_in_map WHERE siteID=" + (int) toDel + ";";// delete sites of map in site in
																					// map table
			Statement stmt7 = conn.createStatement();
			stmt7.executeUpdate(query);

			query = "SELECT numberOfSites FROM gcm.city where name='" + cityName + "'";
			stmt3 = conn.createStatement();
			ResultSet rs3 = stmt3.executeQuery(query);
			if (rs3.first()) {
				numberOfSites = rs3.getInt("numberOfSites");
			}
			numberOfSites--;
			String sql = "Update gcm.city SET numberOfSites='" + numberOfSites + "' WHERE name='" + cityName + "';";
			;
			stmt3 = conn.createStatement();
			stmt3.executeUpdate(sql);

			query = "DELETE FROM gcm.site WHERE ID=" + (int) toDel + ";";
			stmt3 = conn.createStatement();
			stmt3.executeUpdate(query);
			// reduce number of sites from map collection
		}
	}

	/**
	 * This method disconnects all clients when the server is disconnecting 
	 * sets all the maps that was under edit to status 0 so they can be edited again next time the server is up
	 */
	public void exitAllClients() {
		Statement stmt1 = null;
		String query;

		try {
			query = "update gcm.user set status='0' where status='1';";
			stmt1 = conn.createStatement();
			stmt1.executeUpdate(query);

			query = "update gcm.mapimages set status='0' where status='1';";
			stmt1.executeUpdate(query);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * This method returns all the maps names
	 * @return
	 */
	public ArrayList<Object> getMapsNames() {
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<Object> arr = new ArrayList<>();
		ArrayList<String> mapnames = new ArrayList<>();
		String query = "SELECT mapname FROM gcm.mapimages;";
		arr.add("IgotMapsName");
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			while (rs.next()) {
				mapnames.add(rs.getString("mapname"));
			}
			arr.add(mapnames);
			rs.close();
			stmt.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return arr;

	}

	/**
	 * This method gets a city name and gets all the sites of the map's city
	 * @param cityName
	 * @return
	 */
	public ArrayList<Object> getSiteNameForAddEditMap(String cityName) {
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<Object> arr = new ArrayList<>();
		ArrayList<String> siteNames = new ArrayList<>();
		String query = "SELECT siteName FROM gcm.site WHERE city='" + cityName + "';";
		arr.add("IgotSiteName");
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			while (rs.next()) {
				siteNames.add(rs.getString("siteName"));
			}
			arr.add(siteNames);
			rs.close();
			stmt.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return arr;
	}

	/**
	 * This method gets a city name and gets all the tours of the map's city
	 * @param cityName
	 * @return
	 */
	public ArrayList<Object> getTourNameForAddEditMap(String cityName) {
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<Object> arr = new ArrayList<>();
		ArrayList<String> toursNames = new ArrayList<>();
		String query = "SELECT name FROM gcm.tour WHERE city='" + cityName + "';";
		arr.add("IgotTourName");
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			while (rs.next()) {
				toursNames.add(rs.getString("name"));
			}
			arr.add(toursNames);
			rs.close();
			stmt.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return arr;
	}
	
	
	/**
	 * remove a temporary update in a map by map name.
	 * @param mapName
	 */
	public void removeUpdate(String mapName) {
		String query;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			query = "SELECT max(version), ID FROM gcm.map WHERE name = '" + mapName + "' AND approve = '0';";
			rs = stmt.executeQuery(query);
			rs.first();
			String version = rs.getString("max(version)");
			int ID = rs.getInt("ID");
			
			//remove irrelevant map
			query = "DELETE FROM gcm.map WHERE name = '" + mapName + "' AND version = '"+version+"';";
			stmt.executeUpdate(query);
			if(version.equals("0.1")) {
				query = "DELETE FROM gcm.mapimages WHERE name = '" + mapName + "' ;";
				stmt.executeUpdate(query);
			}
			//remove irrelevant sites
			query = "DELETE FROM gcm.site_in_map WHERE mapname = '" + mapName + "' AND version = '"+version+"';";
			stmt.executeUpdate(query);
			//remove irrelevant tours
			query = "DELETE FROM gcm.tour_in_map WHERE mapID = '" + ID + "';";
			stmt.executeUpdate(query);
			rs.close();
			stmt.close();
		}
		catch (Exception e) {
			
		}
		
	}



}